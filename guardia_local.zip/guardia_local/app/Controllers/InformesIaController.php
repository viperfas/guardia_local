<?php
declare(strict_types=1);

class InformesIaController extends Controller
{
    /**
     * Muestra el formulario principal de informes IA
     */
    public function index(): void
    {
        $db = Database::connection();
        
        // Obtener datos básicos para los filtros
        $categorias = $db->query("SELECT id, nombre FROM categorias_incidentes WHERE activo=1 ORDER BY nombre")->fetchAll();
        $barrios = $db->query("SELECT id, nombre FROM barrios WHERE activo=1 ORDER BY nombre")->fetchAll();
        
        // Estado de la IA
        $iaDisponible = AiService::isAvailable();
        $iaInfo = $iaDisponible ? AiService::getInfo() : 'IA no configurada';
        
        $this->view('informes_ia/index', [
            'categorias' => $categorias,
            'barrios' => $barrios,
            'ia_disponible' => $iaDisponible,
            'ia_info' => $iaInfo
        ]);
    }
    
    /**
     * Genera un informe basado en los datos seleccionados
     */
    public function generate(): void
    {
        $this->requirePost();
        
        $db = Database::connection();
        
        // Parámetros del filtro
        $desde = $_POST['desde'] ?? date('Y-m-01', strtotime('-1 month'));
        $hasta = $_POST['hasta'] ?? date('Y-m-d');
        $tipo = $_POST['tipo'] ?? 'general';
        $categoria = (int)($_POST['id_categoria'] ?? 0);
        $barrio = (int)($_POST['id_barrio'] ?? 0);
        
        // Construir consulta base
        $where = "i.fecha BETWEEN ? AND ?";
        $params = [$desde, $hasta];
        
        if ($categoria > 0) {
            $where .= " AND i.id_categoria = ?";
            $params[] = $categoria;
        }
        if ($barrio > 0) {
            $where .= " AND i.id_barrio = ?";
            $params[] = $barrio;
        }
        
        // 1. Recopilar datos estadísticos
        $datos = $this->recopilarDatos($db, $where, $params);
        
        // 2. Anonimizar datos (requisito 21.B)
        $datosAnonimizados = $this->anonimizarDatos($datos);
        
        // 3. Generar informe (IA o fallback local)
        if (AiService::isAvailable()) {
            $prompt = $this->construirPrompt($tipo, $datosAnonimizados);
            $informe = AiService::consultarDatos($prompt, []);
            
            if (empty(trim($informe))) {
                // Fallback si la IA no responde
                $informe = AiService::analisisLocal($datos);
                $informe .= "\n\n---\n_Nota: La IA no devolvió respuesta. Se muestra análisis estadístico local._";
            }
            
            $usadoIA = true;
        } else {
            $informe = AiService::analisisLocal($datos);
            $usadoIA = false;
        }
        
        // 4. Registrar en auditoría
        if (class_exists('Audit')) {
            Audit::log('generar_informe_ia', 'informes_ia', "Tipo: $tipo, Período: $desde a $hasta");
        }
        
        // 5. Mostrar resultado
        $this->view('informes_ia/resultado', [
            'informe' => $informe,
            'usado_ia' => $usadoIA,
            'tipo' => $tipo,
            'desde' => $desde,
            'hasta' => $hasta,
            'datos' => $datos
        ]);
    }
    
    /**
     * Chat conversacional con la IA
     */
    public function chat(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requirePost();
            
            $mensaje = trim($_POST['mensaje'] ?? '');
            $historial = json_decode($_POST['historial'] ?? '[]', true);
            
            if (!is_array($historial)) {
                $historial = [];
            }
            
            if (empty($mensaje)) {
                echo json_encode(['error' => 'Mensaje vacío']);
                return;
            }
            
            // Anonimizar el mensaje del usuario
            $mensajeAnonimo = AiService::anonimizar($mensaje);
            
            // Agregar al historial
            $historial[] = ['role' => 'user', 'content' => $mensajeAnonimo];
            
            // Consultar a la IA
            if (AiService::isAvailable()) {
                $respuesta = AiService::conversar($historial);
                
                if (empty(trim($respuesta))) {
                    $respuesta = "Lo siento, no pude procesar tu consulta en este momento. Por favor, intenta reformularla o verifica que la IA esté correctamente configurada.";
                }
            } else {
                $respuesta = "La IA no está disponible en este momento. Solo puedo ofrecer análisis estadísticos locales. Por favor, contacta al administrador para habilitar la IA.";
            }
            
            $historial[] = ['role' => 'assistant', 'content' => $respuesta];
            
            header('Content-Type: application/json');
            echo json_encode([
                'respuesta' => $respuesta,
                'historial' => $historial
            ]);
            exit;
        }
        
        // Mostrar vista del chat
        $iaDisponible = AiService::isAvailable();
        $this->view('informes_ia/chat', [
            'ia_disponible' => $iaDisponible
        ]);
    }
    
    /**
     * Recopila datos estadísticos de la BD
     */
    private function recopilarDatos($db, string $where, array $params): array
    {
        $datos = [];
        
        // Total de incidentes
        $stmt = $db->prepare("SELECT COUNT(*) FROM incidentes i WHERE $where");
        $stmt->execute($params);
        $datos['total'] = (int)$stmt->fetchColumn();
        
        // Incidentes críticos
        $stmt = $db->prepare("SELECT COUNT(*) FROM incidentes i WHERE $where AND i.prioridad = 'Crítica'");
        $stmt->execute($params);
        $datos['criticos'] = (int)$stmt->fetchColumn();
        
        // Por barrio
        $sql = "SELECT b.nombre, COUNT(*) as total 
                FROM incidentes i 
                LEFT JOIN barrios b ON b.id = i.id_barrio 
                WHERE $where 
                GROUP BY b.id, b.nombre 
                ORDER BY total DESC 
                LIMIT 10";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $datos['por_barrio'] = $stmt->fetchAll();
        
        // Barrio con más incidentes
        if (!empty($datos['por_barrio'])) {
            $datos['barrio_top'] = $datos['por_barrio'][0]['nombre'] ?? 'No determinado';
        } else {
            $datos['barrio_top'] = 'No determinado';
        }
        
        // Por categoría
        $sql = "SELECT c.nombre, COUNT(*) as total 
                FROM incidentes i 
                LEFT JOIN categorias_incidentes c ON c.id = i.id_categoria 
                WHERE $where 
                GROUP BY c.id, c.nombre 
                ORDER BY total DESC 
                LIMIT 10";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $datos['por_categoria'] = $stmt->fetchAll();
        
        // Por prioridad
        $sql = "SELECT i.prioridad, COUNT(*) as total 
                FROM incidentes i 
                WHERE $where 
                GROUP BY i.prioridad 
                ORDER BY FIELD(i.prioridad, 'Crítica', 'Alta', 'Media', 'Baja')";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $datos['por_prioridad'] = $stmt->fetchAll();
        
        // Por día de la semana
        $sql = "SELECT DAYNAME(i.fecha) as dia, COUNT(*) as total 
                FROM incidentes i 
                WHERE $where 
                GROUP BY DAYNAME(i.fecha), DAYOFWEEK(i.fecha)
                ORDER BY DAYOFWEEK(i.fecha)";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $datos['por_dia'] = $stmt->fetchAll();
        
        // Por hora
        $sql = "SELECT HOUR(i.hora) as hora, COUNT(*) as total 
                FROM incidentes i 
                WHERE $where 
                GROUP BY HOUR(i.hora) 
                ORDER BY hora";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $datos['por_hora'] = $stmt->fetchAll();
        
        // Estado de incidentes
        $sql = "SELECT i.estado, COUNT(*) as total 
                FROM incidentes i 
                WHERE $where 
                GROUP BY i.estado";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $datos['por_estado'] = $stmt->fetchAll();
        
        return $datos;
    }
    
    /**
     * Anonimiza los datos antes de enviarlos a la IA
     */
    private function anonimizarDatos(array $datos): array
    {
        // Los datos estadísticos ya son anónimos (solo números y nombres de barrios/categorías)
        // Pero por seguridad, aplicamos anonimización a cualquier texto
        $anonimizados = [];
        foreach ($datos as $key => $value) {
            if (is_string($value)) {
                $anonimizados[$key] = AiService::anonimizar($value);
            } elseif (is_array($value)) {
                $anonimizados[$key] = $value; // Los arrays de stats ya son seguros
            } else {
                $anonimizados[$key] = $value;
            }
        }
        return $anonimizados;
    }
    
    /**
     * Construye el prompt según el tipo de análisis solicitado
     */
    private function construirPrompt(string $tipo, array $datos): string
    {
        $datosJson = json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        
        $prompts = [
            'general' => "Genera un informe ejecutivo completo basado en los siguientes datos estadísticos de incidentes de seguridad pública. Incluye:\n" .
                        "1. Resumen ejecutivo\n" .
                        "2. Hallazgos principales\n" .
                        "3. Análisis por zonas (barrios)\n" .
                        "4. Análisis por tipología (categorías)\n" .
                        "5. Patrones temporales\n" .
                        "6. Recomendaciones operativas\n\n" .
                        "DATOS:\n$datosJson",
            
            'barrios' => "Analiza en profundidad la distribución geográfica de los incidentes. Identifica:\n" .
                        "1. Barrios más críticos y por qué\n" .
                        "2. Patrones espaciales\n" .
                        "3. Zonas con tendencias preocupantes\n" .
                        "4. Recomendaciones de asignación de recursos por zona\n\n" .
                        "DATOS:\n$datosJson",
            
            'temporal' => "Analiza la evolución temporal de los incidentes. Identifica:\n" .
                         "1. Días y horas de mayor actividad\n" .
                         "2. Patrones cíclicos o estacionales\n" .
                         "3. Tendencias de crecimiento o decrecimiento\n" .
                         "4. Recomendaciones de turnos y horarios\n\n" .
                         "DATOS:\n$datosJson",
            
            'categorias' => "Analiza la distribución por categorías de incidentes. Identifica:\n" .
                           "1. Categorías más frecuentes\n" .
                           "2. Relaciones entre categorías\n" .
                           "3. Categorías con mayor gravedad\n" .
                           "4. Recomendaciones de prevención\n\n" .
                           "DATOS:\n$datosJson",
            
            'predictivo' => "Basándote en los datos históricos, genera un análisis predictivo:\n" .
                           "1. Tendencias esperadas para el próximo período\n" .
                           "2. Zonas de riesgo potencial\n" .
                           "3. Categorías que podrían aumentar\n" .
                           "4. Recomendaciones preventivas\n\n" .
                           "DATOS:\n$datosJson"
        ];
        
        return $prompts[$tipo] ?? $prompts['general'];
    }
}