<h3><?= $equipo && isset($equipo["id"]) ? "Editar equipo" : "Nuevo equipo" ?></h3>
<form method="post" action="<?= APP_URL ?>equipos/<?= $equipo && isset($equipo["id"]) ? "actualizar" : "guardar" ?>" class="bg-white p-3 rounded">
  <?= Csrf::field() ?>
  <?php if ($equipo && isset($equipo["id"])): ?><input type="hidden" name="id" value="<?= $equipo["id"] ?>"><?php endif; ?>
  <div class="row g-2">
    <div class="col-md-4"><label>Nombre del equipo</label><input name="nombre" class="form-control" required value="<?= View::e($equipo["nombre"]??"") ?>"></div>
    <div class="col-md-4"><label>Responsable</label>
      <select name="id_responsable" class="form-select">
        <option value="">-</option>
        <?php foreach ($personal as $p): ?><option value="<?= $p["id"] ?>" <?= ($equipo["id_responsable"]??"")==$p["id"]?"selected":"" ?>><?= View::e($p["nombre_completo"]) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4"><label>Móvil asignado</label>
      <select name="id_movil" class="form-select">
        <option value="">-</option>
        <?php foreach ($moviles as $m): ?><option value="<?= $m["id"] ?>" <?= ($equipo["id_movil"]??"")==$m["id"]?"selected":"" ?>><?= View::e($m["numero_interno"]) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4"><label>Turno</label>
      <select name="turno" class="form-select">
        <option value="">-</option>
        <?php foreach (["Mañana","Tarde","Noche","Rotativo"] as $t): ?>
          <option <?= ($equipo["turno"]??"")==$t?"selected":"" ?>><?= $t ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4"><label>Estado</label>
      <select name="estado" class="form-select">
        <?php foreach (["Activo","Inactivo","En descanso"] as $e): ?>
          <option <?= ($equipo["estado"]??"Activo")==$e?"selected":"" ?>><?= $e ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-12">
      <label>Integrantes</label>
      <div class="row">
        <?php foreach ($personal as $p): ?>
          <div class="col-md-3">
            <div class="form-check">
              <input type="checkbox" name="integrantes[]" class="form-check-input" value="<?= $p["id"] ?>" <?= in_array($p["id"],$integrantes)?"checked":"" ?>>
              <label class="form-check-label"><?= View::e($p["nombre_completo"]) ?></label>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
  <button class="btn btn-primary mt-3">Guardar</button>
  <a href="<?= APP_URL ?>equipos" class="btn btn-secondary mt-3">Cancelar</a>
</form>
