<?php
declare(strict_types=1);
class VecinosController extends Controller {
    public function index(): void {
        $db = Database::connection();
        $q = trim($_GET['q']??'');
        $barrio = (int)($_GET['barrio']??0);
        $sql = "SELECT v.*, b.nombre AS barrio_nombre FROM vecinos v
                LEFT JOIN barrios b ON b.id=v.id_barrio WHERE v.activo=1";
        $params = [];
        if ($q !== '') {
            $sql .= " AND (v.nombre LIKE ? OR v.apellido LIKE ? OR v.dni LIKE ? OR v.telefono LIKE ?)";
            $like = "%$q%"; $params = array_merge($params, [$like,$like,$like,$like]);
        }
        if ($barrio > 0) { $sql .= " AND v.id_barrio=?"; $params[] = $barrio; }
        $sql .= " ORDER BY v.apellido, v.nombre";
        $vecinos = $db->prepare($sql); $vecinos->execute($params);
        $barrios = $db->query("SELECT id, nombre FROM barrios ORDER BY nombre")->fetchAll();
        $this->view('vecinos/index', ['vecinos'=>$vecinos->fetchAll(),'barrios'=>$barrios,'q'=>$q,'barrio'=>$barrio]);
    }
    
    public function create(): void {
        $db = Database::connection();
        $barrios = $db->query("SELECT id, nombre FROM barrios ORDER BY nombre")->fetchAll();
        $this->view('vecinos/form', ['barrios'=>$barrios,'vecino'=>null]);
    }
    
    public function store(): void {
        $this->requirePost();
        $d = $_POST;
        $errors = [];
        if (!Validator::dniArgentino($d['dni']??'')) $errors[] = 'DNI inválido';
        if (!Validator::telefono($d['telefono']??'')) $errors[] = 'Teléfono inválido';

        $db = Database::connection();
        $exists = $db->prepare("SELECT id FROM vecinos WHERE dni=? AND activo=1");
        $exists->execute([$d['dni']??'']);
        if ($exists->fetch()) $errors[] = 'Ya existe un vecino con ese DNI';

        if ($errors) {
            $barrios = $db->query("SELECT id, nombre FROM barrios ORDER BY nombre")->fetchAll();
            $this->view('vecinos/form', ['barrios'=>$barrios,'vecino'=>$d,'errors'=>$errors]); return;
        }

        $stmt = $db->prepare("INSERT INTO vecinos
            (nombre, apellido, dni, telefono, fecha_nacimiento, direccion, numero, id_barrio,
             contacto_emergencia, telefono_emergencia, observaciones, id_operador_alta)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([
            $d['nombre'],$d['apellido'],$d['dni'],$d['telefono'],
            $d['fecha_nacimiento']?:null,$d['direccion'],$d['numero'],
            (int)($d['id_barrio']?:null),$d['contacto_emergencia']??null,
            $d['telefono_emergencia']??null,$d['observaciones']??null,
            $_SESSION['user_id']
        ]);
        Audit::log('alta_vecino','vecinos',(string)$db->lastInsertId());
        $this->redirect('vecinos');
    }
    
    public function edit(): void {
        $id = (int)($_GET['id']??0);
        $db = Database::connection();
        $stmt = $db->prepare("SELECT * FROM vecinos WHERE id=? AND activo=1");
        $stmt->execute([$id]);
        $vecino = $stmt->fetch();
        if (!$vecino) {
            $_SESSION['error'] = "Vecino no encontrado";
            $this->redirect('vecinos');
            return;
        }
        $barrios = $db->query("SELECT id, nombre FROM barrios ORDER BY nombre")->fetchAll();
        $this->view('vecinos/form', ['barrios'=>$barrios,'vecino'=>$vecino]);
    }
    
    public function update(): void {
        $this->requirePost();
        $d = $_POST;
        $id = (int)$d['id'];
        $errors = [];
        
        if (!Validator::dniArgentino($d['dni']??'')) $errors[] = 'DNI inválido';
        if (!Validator::telefono($d['telefono']??'')) $errors[] = 'Teléfono inválido';

        $db = Database::connection();
        
        // Verificar DNI duplicado (excluyendo el vecino actual)
        $exists = $db->prepare("SELECT id FROM vecinos WHERE dni=? AND activo=1 AND id != ?");
        $exists->execute([$d['dni']??'', $id]);
        if ($exists->fetch()) $errors[] = 'Ya existe otro vecino con ese DNI';

        if ($errors) {
            $barrios = $db->query("SELECT id, nombre FROM barrios ORDER BY nombre")->fetchAll();
            $this->view('vecinos/form', ['barrios'=>$barrios,'vecino'=>$d,'errors'=>$errors]); return;
        }

        $stmt = $db->prepare("UPDATE vecinos SET
            nombre=?, apellido=?, dni=?, telefono=?, fecha_nacimiento=?,
            direccion=?, numero=?, id_barrio=?, contacto_emergencia=?,
            telefono_emergencia=?, observaciones=?
            WHERE id=?");
        $stmt->execute([
            $d['nombre'],$d['apellido'],$d['dni'],$d['telefono'],
            $d['fecha_nacimiento']?:null,$d['direccion'],$d['numero'],
            (int)($d['id_barrio']?:null),$d['contacto_emergencia']??null,
            $d['telefono_emergencia']??null,$d['observaciones']??null,
            $id
        ]);
        Audit::log('edit_vecino','vecinos',(string)$id);
        $this->redirect('vecinos');
    }
    
    public function delete(): void {
        $this->requirePost();
        $id = (int)($_POST['id']??0);
        $db = Database::connection();
        $db->prepare("UPDATE vecinos SET activo=0 WHERE id=?")->execute([$id]);
        Audit::log('baja_vecino','vecinos',(string)$id);
        $this->redirect('vecinos');
    }
}