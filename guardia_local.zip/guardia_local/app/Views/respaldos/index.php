<h3 class="mb-4">💾 Copias de seguridad</h3>
<?php if (!empty($_SESSION["backup_ok"])): ?><div class="alert alert-success"><?= View::e($_SESSION["backup_ok"]) ?></div><?php unset($_SESSION["backup_ok"]); endif; ?>
<?php if (!empty($_SESSION["backup_err"])): ?><div class="alert alert-danger"><?= View::e($_SESSION["backup_err"]) ?></div><?php unset($_SESSION["backup_err"]); endif; ?>

<div class="row g-3 mb-4">
  <div class="col-md-6">
    <div class="card bg-white p-3">
      <h5>🆕 Crear backup manual</h5>
      <p>Genera una copia completa de la base de datos ahora.</p>
      <form method="post" action="<?= APP_URL ?>respaldos/crear"><?= Csrf::field() ?><button class="btn btn-primary">💾 Crear backup ahora</button></form>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card bg-white p-3">
      <h5>⚠️ Restaurar desde backup</h5>
      <p class="text-danger"><strong>Atención:</strong> Restaurar sobrescribirá TODA la base de datos actual.</p>
    </div>
  </div>
</div>

<div class="card bg-white p-3">
  <h5>Historial de respaldos</h5>
  <table class="table table-striped">
    <thead><tr><th>Fecha</th><th>Archivo</th><th>Tamaño</th><th>Tipo</th><th>Estado</th><th>Acciones</th></tr></thead>
    <tbody>
    <?php foreach ($respaldos as $r): ?>
      <tr>
        <td><?= View::e($r["fecha"]) ?></td>
        <td><code><?= View::e($r["nombre_archivo"]) ?></code></td>
        <td><?= $r["tamano_bytes"] ? round($r["tamano_bytes"]/1024,2)." KB" : "-" ?></td>
        <td><span class="badge bg-<?= $r["tipo"]=="automatico"?"info":"secondary" ?>"><?= View::e($r["tipo"]) ?></span></td>
        <td><span class="badge bg-<?= $r["estado"]=="ok"?"success":"danger" ?>"><?= View::e($r["estado"]) ?></span></td>
        <td>
          <?php if ($r["estado"] == "ok"): ?>
            <a href="<?= APP_URL ?>respaldos/descargar?id=<?= $r["id"] ?>" class="btn btn-sm btn-outline-primary">⬇️</a>
            <form method="post" action="<?= APP_URL ?>respaldos/restaurar" style="display:inline" onsubmit="return confirm('¿Restaurar este backup? Se sobrescribirá la BD actual.')">
              <?= Csrf::field() ?><input type="hidden" name="id" value="<?= $r["id"] ?>"><button class="btn btn-sm btn-outline-warning">🔄</button>
            </form>
            <form method="post" action="<?= APP_URL ?>respaldos/eliminar" style="display:inline" onsubmit="return confirm('¿Eliminar?')">
              <?= Csrf::field() ?><input type="hidden" name="id" value="<?= $r["id"] ?>"><button class="btn btn-sm btn-outline-danger">🗑️</button>
            </form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$respaldos): ?><tr><td colspan="6" class="text-muted text-center">No hay respaldos</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>