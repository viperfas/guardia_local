<?php
declare(strict_types=1);
Router::add("",                    "HomeController@index",      ["auth"=>true]);
Router::add("dashboard",           "HomeController@dashboard",  ["auth"=>true]);
Router::add("login",               "AuthController@login",      ["auth"=>false]);
Router::add("login/process",       "AuthController@process",    ["auth"=>false,"method"=>"POST"]);
Router::add("logout",              "AuthController@logout",     ["auth"=>true]);
Router::add("vecinos",             "VecinosController@index",   ["auth"=>true]);
Router::add("vecinos/crear",       "VecinosController@create",  ["auth"=>true]);
Router::add("vecinos/guardar",     "VecinosController@store",   ["auth"=>true,"method"=>"POST"]);
Router::add("incidentes",          "IncidentesController@index",["auth"=>true]);
Router::add("incidentes/crear",    "IncidentesController@create",["auth"=>true]);
Router::add("incidentes/guardar",  "IncidentesController@store", ["auth"=>true,"method"=>"POST"]);
Router::add("mapa",                "MapaController@index",      ["auth"=>true]);
Router::add("mapa/barrios",        "MapaController@barrios",    ["auth"=>true]);
Router::add("auditoria",           "AuditoriaController@index", ["auth"=>true]);
Router::add("api/incidentes",      "ApiController@incidentes",  ["auth"=>true]);

// === ETAPA 2: USUARIOS Y PERMISOS ===
Router::add("usuarios",               "UsuariosController@index",     ["auth"=>true,"perm"=>"usuarios.gestionar"]);
Router::add("usuarios/crear",         "UsuariosController@create",    ["auth"=>true,"perm"=>"usuarios.gestionar"]);
Router::add("usuarios/guardar",       "UsuariosController@store",     ["auth"=>true,"perm"=>"usuarios.gestionar","method"=>"POST"]);
Router::add("usuarios/editar",        "UsuariosController@edit",      ["auth"=>true,"perm"=>"usuarios.gestionar"]);
Router::add("usuarios/actualizar",    "UsuariosController@update",    ["auth"=>true,"perm"=>"usuarios.gestionar","method"=>"POST"]);
Router::add("usuarios/eliminar",      "UsuariosController@delete",    ["auth"=>true,"perm"=>"usuarios.gestionar","method"=>"POST"]);
Router::add("usuarios/permisos",      "UsuariosController@permisos",  ["auth"=>true,"perm"=>"usuarios.gestionar"]);
Router::add("usuarios/guardar_permisos","UsuariosController@savePerms",["auth"=>true,"perm"=>"usuarios.gestionar","method"=>"POST"]);
Router::add("perfil",                 "PerfilController@index",       ["auth"=>true]);
Router::add("perfil/cambiar_clave",   "PerfilController@changePass",  ["auth"=>true,"method"=>"POST"]);

// === ETAPA 6: MÓVILES Y DESPACHO ===
Router::add("moviles",                "MovilesController@index",      ["auth"=>true]);
Router::add("moviles/crear",          "MovilesController@create",     ["auth"=>true,"perm"=>"moviles.gestionar"]);
Router::add("moviles/guardar",        "MovilesController@store",      ["auth"=>true,"perm"=>"moviles.gestionar","method"=>"POST"]);
Router::add("moviles/editar",         "MovilesController@edit",       ["auth"=>true,"perm"=>"moviles.gestionar"]);
Router::add("moviles/actualizar",     "MovilesController@update",     ["auth"=>true,"perm"=>"moviles.gestionar","method"=>"POST"]);
Router::add("moviles/cambiar_estado", "MovilesController@changeState",["auth"=>true,"method"=>"POST"]);

Router::add("personal",               "PersonalController@index",     ["auth"=>true]);
Router::add("personal/crear",         "PersonalController@create",    ["auth"=>true,"perm"=>"personal.gestionar"]);
Router::add("personal/guardar",       "PersonalController@store",     ["auth"=>true,"perm"=>"personal.gestionar","method"=>"POST"]);
Router::add("personal/editar",        "PersonalController@edit",      ["auth"=>true,"perm"=>"personal.gestionar"]);
Router::add("personal/actualizar",    "PersonalController@update",    ["auth"=>true,"perm"=>"personal.gestionar","method"=>"POST"]);

Router::add("equipos",                "EquiposController@index",      ["auth"=>true]);
Router::add("equipos/crear",          "EquiposController@create",     ["auth"=>true,"perm"=>"equipos.gestionar"]);
Router::add("equipos/guardar",        "EquiposController@store",      ["auth"=>true,"perm"=>"equipos.gestionar","method"=>"POST"]);
Router::add("equipos/editar",         "EquiposController@edit",       ["auth"=>true,"perm"=>"equipos.gestionar"]);
Router::add("equipos/actualizar",     "EquiposController@update",     ["auth"=>true,"perm"=>"equipos.gestionar","method"=>"POST"]);

Router::add("intervenciones",              "IntervencionesController@index",    ["auth"=>true]);
Router::add("intervenciones/despachar",    "IntervencionesController@dispatch", ["auth"=>true,"perm"=>"intervenciones.despachar"]);
Router::add("intervenciones/guardar_despacho","IntervencionesController@saveDispatch",["auth"=>true,"perm"=>"intervenciones.despachar","method"=>"POST"]);
Router::add("intervenciones/ver",          "IntervencionesController@show",     ["auth"=>true]);
Router::add("intervenciones/novedad",      "IntervencionesController@addNov",   ["auth"=>true,"method"=>"POST"]);
Router::add("intervenciones/marcar_salida","IntervencionesController@markOut",  ["auth"=>true,"method"=>"POST"]);
Router::add("intervenciones/marcar_llegada","IntervencionesController@markArrival",["auth"=>true,"method"=>"POST"]);
Router::add("intervenciones/cerrar",       "IntervencionesController@close",    ["auth"=>true,"method"=>"POST"]);
Router::add("panel_operativo",             "PanelOperativoController@index",    ["auth"=>true]);

Router::add("api/intervenciones_activas",  "ApiController@intervencionesActivas",["auth"=>true]);
Router::add("api/moviles_estado",          "ApiController@movilesEstado",       ["auth"=>true]);

// === ETAPA 8: ESTADÍSTICAS ===
Router::add("estadisticas",             "EstadisticasController@index",        ["auth"=>true,"perm"=>"estadisticas.ver"]);
Router::add("estadisticas/barrios",     "EstadisticasController@barrios",      ["auth"=>true,"perm"=>"estadisticas.ver"]);
Router::add("estadisticas/categorias",  "EstadisticasController@categorias",   ["auth"=>true,"perm"=>"estadisticas.ver"]);
Router::add("estadisticas/temporal",    "EstadisticasController@temporal",     ["auth"=>true,"perm"=>"estadisticas.ver"]);
Router::add("estadisticas/horaria",     "EstadisticasController@horaria",      ["auth"=>true,"perm"=>"estadisticas.ver"]);
Router::add("estadisticas/tiempos",     "EstadisticasController@tiempos",      ["auth"=>true,"perm"=>"estadisticas.ver"]);
Router::add("estadisticas/comparar",    "EstadisticasController@comparar",     ["auth"=>true,"perm"=>"estadisticas.ver"]);

Router::add("api/stats/barrios",        "ApiStatsController@barrios",          ["auth"=>true]);
Router::add("api/stats/categorias",     "ApiStatsController@categorias",       ["auth"=>true]);
Router::add("api/stats/temporal",       "ApiStatsController@temporal",         ["auth"=>true]);
Router::add("api/stats/horaria",        "ApiStatsController@horaria",          ["auth"=>true]);
Router::add("api/stats/tiempos",        "ApiStatsController@tiempos",          ["auth"=>true]);
Router::add("informes_ia", "InformesIaController@index", ["auth"=>true,"perm"=>"ia.generar"]);
Router::add("informes_ia/generar", "InformesIaController@generate", ["auth"=>true,"perm"=>"ia.generar","method"=>"POST"]);
Router::add("informes_ia/conversar", "InformesIaController@chat", ["auth"=>true,"perm"=>"ia.generar","method"=>"POST"]);
Router::add("informes_ia/historial", "InformesIaController@history", ["auth"=>true,"perm"=>"ia.generar"]);
Router::add("reportes", "ReportesController@index", ["auth"=>true,"perm"=>"reportes.generar"]);
Router::add("reportes/incidente", "ReportesController@incidente", ["auth"=>true,"perm"=>"reportes.generar"]);
Router::add("reportes/intervencion", "ReportesController@intervencion", ["auth"=>true,"perm"=>"reportes.generar"]);
Router::add("reportes/periodo", "ReportesController@periodo", ["auth"=>true,"perm"=>"reportes.generar"]);
Router::add("reportes/barrio", "ReportesController@barrio", ["auth"=>true,"perm"=>"reportes.generar"]);
Router::add("reportes/csv", "ReportesController@csv", ["auth"=>true,"perm"=>"reportes.generar"]);
Router::add("respaldos", "BackupController@index", ["auth"=>true,"perm"=>"respaldos.gestionar"]);
Router::add("respaldos/crear", "BackupController@create", ["auth"=>true,"perm"=>"respaldos.gestionar","method"=>"POST"]);
Router::add("respaldos/descargar", "BackupController@download", ["auth"=>true,"perm"=>"respaldos.gestionar"]);
Router::add("respaldos/restaurar", "BackupController@restore", ["auth"=>true,"perm"=>"respaldos.gestionar","method"=>"POST"]);
Router::add("respaldos/eliminar", "BackupController@delete", ["auth"=>true,"perm"=>"respaldos.gestionar","method"=>"POST"]);
Router::add("configuracion", "ConfiguracionController@index", ["auth"=>true,"perm"=>"configuracion.editar"]);
Router::add("configuracion/guardar", "ConfiguracionController@save", ["auth"=>true,"perm"=>"configuracion.editar","method"=>"POST"]);
Router::add("usuarios/sincronizar", "UsuariosController@sincronizar", ["auth"=>true,"perm"=>"usuarios.gestionar"]);
Router::add("vecinos/editar", "VecinosController@edit", ["auth"=>true,"perm"=>"vecinos.editar"]);
Router::add("vecinos/actualizar", "VecinosController@update", ["auth"=>true,"perm"=>"vecinos.editar","method"=>"POST"]);
Router::add("vecinos/eliminar", "VecinosController@delete", ["auth"=>true,"perm"=>"vecinos.eliminar","method"=>"POST"]);
Router::add("incidentes/editar", "IncidentesController@edit", ["auth"=>true,"perm"=>"incidentes.editar"]);
Router::add("incidentes/actualizar", "IncidentesController@update", ["auth"=>true,"perm"=>"incidentes.editar","method"=>"POST"]);
Router::add("incidentes/eliminar", "IncidentesController@delete", ["auth"=>true,"perm"=>"incidentes.editar","method"=>"POST"]);
Router::add("personal/eliminar", "PersonalController@delete", ["auth"=>true,"perm"=>"personal.gestionar","method"=>"POST"]);
Router::add("equipos/eliminar", "EquiposController@delete", ["auth"=>true,"perm"=>"equipos.gestionar","method"=>"POST"]);
Router::add("intervenciones/editar", "IntervencionesController@edit", ["auth"=>true,"perm"=>"intervenciones.despachar"]);
Router::add("intervenciones/actualizar", "IntervencionesController@update", ["auth"=>true,"perm"=>"intervenciones.despachar","method"=>"POST"]);
Router::add("intervenciones/eliminar", "IntervencionesController@delete", ["auth"=>true,"perm"=>"intervenciones.despachar","method"=>"POST"]);
Router::add("moviles/eliminar", "MovilesController@delete", ["auth"=>true,"perm"=>"moviles.gestionar","method"=>"POST"]);
Router::add("barrios", "BarriosController@index", ["auth"=>true,"perm"=>"barrios.ver"]);
Router::add("barrios/crear", "BarriosController@create", ["auth"=>true,"perm"=>"barrios.gestionar"]);
Router::add("barrios/guardar", "BarriosController@store", ["auth"=>true,"perm"=>"barrios.gestionar","method"=>"POST"]);
Router::add("barrios/editar", "BarriosController@edit", ["auth"=>true,"perm"=>"barrios.gestionar"]);
Router::add("barrios/actualizar", "BarriosController@update", ["auth"=>true,"perm"=>"barrios.gestionar","method"=>"POST"]);
Router::add("barrios/eliminar", "BarriosController@delete", ["auth"=>true,"perm"=>"barrios.gestionar","method"=>"POST"]);
Router::add("barrios/ver", "BarriosController@ver", ["auth"=>true,"perm"=>"barrios.ver"]);
Router::add("barrios/upload_geojson", "BarriosController@uploadGeojson", ["auth"=>true,"perm"=>"barrios.gestionar","method"=>"POST"]);
Router::add("barrios/reasignar", "BarriosController@reasignarIncidentes", ["auth"=>true,"perm"=>"barrios.gestionar","method"=>"POST"]);
Router::add("mapa/incidentes", "MapaController@incidentes", ["auth"=>true]);
Router::add("mapa/asignar_barrio", "MapaController@asignarBarrio", ["auth"=>true,"method"=>"POST"]);
Router::add("barrios/editor_visual", "BarrioEditorController@index", ["auth"=>true,"perm"=>"barrios.gestionar"]);
Router::add("barrios/guardar_poligono_visual", "BarrioEditorController@save", ["auth"=>true,"perm"=>"barrios.gestionar","method"=>"POST"]);
Router::add("informes_ia/chat", "InformesIaController@chat", ["auth"=>true,"perm"=>"ia.generar"]);
Router::add("reportes/generar_pdf", "ReportesController@generarPdf", ["auth"=>true,"perm"=>"reportes.generar","method"=>"POST"]);
Router::add("reportes/datos_pdf", "ReportesController@datosPdf", ["auth"=>true,"perm"=>"reportes.generar"]);
Router::add("reportes/generar_pdf_form", "ReportesController@formPdf", ["auth"=>true,"perm"=>"reportes.generar"]);
Router::add("reportes/categoria", "ReportesController@categoria", ["auth"=>true,"perm"=>"reportes.generar"]);
Router::add("reportes/barrio", "ReportesController@barrio", ["auth"=>true,"perm"=>"reportes.ver"]);
