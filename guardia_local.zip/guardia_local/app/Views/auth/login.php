<!DOCTYPE html><html lang="es"><head><meta charset="utf-8">
<title>Ingreso — Guardia Local</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-light"><div class="container py-5"><div class="row justify-content-center"><div class="col-md-5">
<div class="card shadow">
  <div class="card-header bg-primary text-white"><h5 class="mb-0">Guardia Local — Villa Giardino</h5></div>
  <div class="card-body">
    <?php if (!empty($error)): ?><div class="alert alert-danger"><?= View::e($error) ?></div><?php endif; ?>
    <?php if (!empty($expired)): ?><div class="alert alert-warning">Sesión cerrada por inactividad.</div><?php endif; ?>
    <form method="post" action="<?= APP_URL ?>login/process">
      <?= Csrf::field() ?>
      <div class="mb-3"><label class="form-label">Usuario</label><input name="usuario" class="form-control" required autofocus></div>
      <div class="mb-3"><label class="form-label">Contraseña</label><input type="password" name="password" class="form-control" required></div>
      <button class="btn btn-primary w-100">Ingresar</button>
    </form>
  </div>
</div></div></div></div></body></html>
