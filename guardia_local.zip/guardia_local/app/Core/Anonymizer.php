<?php
declare(strict_types=1);
class Anonymizer {
    public static function anonimizarIncidentes(array $incidentes): ?array {
        if (count($incidentes) < AI_MIN_AGGREGATION) return null;
        $anon = [];
        foreach ($incidentes as $i) {
            $anon[] = [
                "categoria"  => $i["categoria"] ?? null,
                "barrio"     => $i["barrio"] ?? null,
                "prioridad"  => $i["prioridad"] ?? null,
                "estado"     => $i["estado"] ?? null,
                "fecha"      => $i["fecha"] ?? null,
            ];
        }
        return $anon;
    }
    public static function verificarPayload(string $json): bool {
        if (preg_match("/\b\d{7,8}\b/", $json)) return false;
        if (preg_match("/\b\+?\d{10,}\b/", $json)) return false;
        return true;
    }
}
