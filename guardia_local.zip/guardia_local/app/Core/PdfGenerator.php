<?php
declare(strict_types=1);
class PdfGenerator {
    public static function render(string $titulo, string $subtitulo, string $html): void {
        $cfg = self::getConfigMunicipio();
        header("Content-Type: text/html; charset=utf-8");
        echo '<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><title>'.htmlspecialchars($titulo).'</title>';
        echo '<style>';
        echo 'body{font-family:Arial,sans-serif;margin:20px;color:#222}';
        echo '.header{text-align:center;border-bottom:3px solid #1f2d3d;padding-bottom:15px;margin-bottom:20px}';
        echo '.header h1{margin:0;color:#1f2d3d;font-size:22px}';
        echo '.header h2{margin:5px 0 0;color:#555;font-size:14px;font-weight:normal}';
        echo '.header .fecha{margin-top:10px;font-size:12px;color:#777}';
        echo 'h3{color:#1f2d3d;border-bottom:1px solid #ddd;padding-bottom:5px}';
        echo 'table{width:100%;border-collapse:collapse;margin:15px 0;font-size:13px}';
        echo 'th{background:#1f2d3d;color:white;padding:8px;text-align:left}';
        echo 'td{padding:6px 8px;border-bottom:1px solid #eee}';
        echo 'tr:nth-child(even){background:#f9f9f9}';
        echo '.stat{display:inline-block;background:#f0f4f8;padding:15px 20px;margin:5px;border-radius:5px;text-align:center;min-width:120px}';
        echo '.stat .val{font-size:24px;font-weight:bold;color:#1f2d3d}';
        echo '.stat .lbl{font-size:11px;color:#666;text-transform:uppercase}';
        echo '.footer{margin-top:30px;padding-top:10px;border-top:1px solid #ddd;font-size:10px;color:#999;text-align:center}';
        echo '@media print{.no-print{display:none}body{margin:10mm}}';
        echo '</style></head><body>';
        echo '<div class="header">';
        echo '<h1>'.htmlspecialchars($cfg["municipio_nombre"] ?? "Municipalidad").'</h1>';
        echo '<h2>'.htmlspecialchars($subtitulo).'</h2>';
        echo '<div class="fecha">Generado: '.date("d/m/Y H:i").' hs</div>';
        echo '</div>';
        echo '<h3>'.htmlspecialchars($titulo).'</h3>';
        echo $html;
        echo '<div class="footer">Sistema Integral de Guardia Local — '.htmlspecialchars($cfg["municipio_nombre"] ?? "").' — '.htmlspecialchars($cfg["municipio_provincia"] ?? "").', '.htmlspecialchars($cfg["municipio_pais"] ?? "").'</div>';
        echo '<div class="no-print" style="margin-top:20px;text-align:center">';
        echo '<button onclick="window.print()" style="padding:10px 30px;background:#1f2d3d;color:white;border:none;border-radius:4px;cursor:pointer;font-size:14px">🖨️ Imprimir / Guardar PDF</button> ';
        echo '<button onclick="window.close()" style="padding:10px 30px;background:#6c757d;color:white;border:none;border-radius:4px;cursor:pointer;font-size:14px">Cerrar</button>';
        echo '</div>';
        echo '<script>window.onload=function(){setTimeout(function(){window.print()},500)};</script>';
        echo '</body></html>';
    }
    private static function getConfigMunicipio(): array {
        try {
            $db = Database::connection();
            $rows = $db->query("SELECT clave, valor FROM configuracion")->fetchAll();
            $cfg = [];
            foreach ($rows as $r) $cfg[$r["clave"]] = $r["valor"];
            return $cfg;
        } catch (Throwable $e) { return []; }
    }
}