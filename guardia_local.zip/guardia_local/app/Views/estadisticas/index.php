<h3 class="mb-4">📊 Estadísticas y Análisis</h3>

<div class="card bg-white p-3 mb-4">
  <h5>Filtros</h5>
  <form method="get" class="row g-2">
    <div class="col-md-2">
      <label>Desde</label>
      <input type="date" name="desde" class="form-control" value="<?= View::e($desde) ?>">
    </div>
    <div class="col-md-2">
      <label>Hasta</label>
      <input type="date" name="hasta" class="form-control" value="<?= View::e($hasta) ?>">
    </div>
    <div class="col-md-3">
      <label>Barrio</label>
      <select name="barrio" class="form-select">
        <option value="0">Todos los barrios</option>
        <?php foreach ($barrios as $b): ?>
          <option value="<?= $b["id"] ?>" <?= $barrio==$b["id"]?"selected":"" ?>><?= View::e($b["nombre"]) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label>Categoría</label>
      <select name="categoria" class="form-select">
        <option value="0">Todas las categorías</option>
        <?php foreach ($categorias as $c): ?>
          <option value="<?= $c["id"] ?>" <?= $categoria==$c["id"]?"selected":"" ?>><?= View::e($c["nombre"]) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-2 d-flex align-items-end">
      <button class="btn btn-primary w-100">Aplicar filtros</button>
    </div>
  </form>
</div>

<div class="row g-3 mb-4">
  <div class="col-md-3">
    <div class="card text-bg-primary p-3">
      <h6>Total incidentes</h6>
      <h2><?= number_format($total) ?></h2>
      <small>Período seleccionado</small>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card text-bg-danger p-3">
      <h6>Críticos</h6>
      <h2><?= number_format($criticos) ?></h2>
      <small><?= $total > 0 ? number_format(($criticos/$total)*100, 1) : 0 ?>% del total</small>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card text-bg-success p-3">
      <h6>Resueltos</h6>
      <h2><?= number_format($resueltos) ?></h2>
      <small><?= $total > 0 ? number_format(($resueltos/$total)*100, 1) : 0 ?>% resueltos</small>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card text-bg-warning p-3">
      <h6>Pendientes</h6>
      <h2><?= number_format($total - $resueltos) ?></h2>
      <small>En proceso</small>
    </div>
  </div>
</div>

<div class="row g-3 mb-4">
  <div class="col-md-6">
    <div class="card bg-white p-3">
      <h5>📍 Incidentes por barrio</h5>
      <canvas id="chartBarrios" height="300"></canvas>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card bg-white p-3">
      <h5>📋 Incidentes por categoría</h5>
      <canvas id="chartCategorias" height="300"></canvas>
    </div>
  </div>
</div>

<div class="row g-3 mb-4">
  <div class="col-md-12">
    <div class="card bg-white p-3">
      <h5>📈 Evolución temporal</h5>
      <canvas id="chartTemporal" height="100"></canvas>
    </div>
  </div>
</div>

<div class="row g-3 mb-4">
  <div class="col-md-6">
    <div class="card bg-white p-3">
      <h5>🕐 Distribución horaria</h5>
      <canvas id="chartHoraria" height="250"></canvas>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card bg-white p-3">
      <h5>⏱️ Tiempos promedio de respuesta</h5>
      <canvas id="chartTiempos" height="250"></canvas>
    </div>
  </div>
</div>

<script>
const filtros = "desde=<?= urlencode($desde) ?>&hasta=<?= urlencode($hasta) ?>&barrio=<?= $barrio ?>&categoria=<?= $categoria ?>";

// Gráfico de barras por barrio
fetch("<?= APP_URL ?>api/stats/barrios?" + filtros)
  .then(r => r.json())
  .then(data => {
    const ctx = document.getElementById("chartBarrios");
    new Chart(ctx, {
      type: "bar",
      data: {
        labels: data.map(d => d.nombre),
        datasets: [{
          label: "Total incidentes",
          data: data.map(d => d.total),
          backgroundColor: "rgba(54, 162, 235, 0.6)",
          borderColor: "rgba(54, 162, 235, 1)",
          borderWidth: 1
        }, {
          label: "Críticos",
          data: data.map(d => d.criticos),
          backgroundColor: "rgba(255, 99, 132, 0.6)",
          borderColor: "rgba(255, 99, 132, 1)",
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: "top" } },
        scales: { y: { beginAtZero: true } }
      }
    });
  });

// Gráfico de torta por categoría
fetch("<?= APP_URL ?>api/stats/categorias?" + filtros)
  .then(r => r.json())
  .then(data => {
    const ctx = document.getElementById("chartCategorias");
    new Chart(ctx, {
      type: "doughnut",
      data: {
        labels: data.map(d => d.nombre),
        datasets: [{
          data: data.map(d => d.total),
          backgroundColor: data.map(d => d.color || "#6c757d"),
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: "right" } }
      }
    });
  });

// Gráfico de línea temporal
fetch("<?= APP_URL ?>api/stats/temporal?" + filtros)
  .then(r => r.json())
  .then(data => {
    const ctx = document.getElementById("chartTemporal");
    new Chart(ctx, {
      type: "line",
      data: {
        labels: data.map(d => d.fecha),
        datasets: [{
          label: "Incidentes por día",
          data: data.map(d => d.total),
          borderColor: "rgba(75, 192, 192, 1)",
          backgroundColor: "rgba(75, 192, 192, 0.2)",
          tension: 0.3,
          fill: true
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: "top" } },
        scales: { y: { beginAtZero: true } }
      }
    });
  });

// Gráfico de barras horarias
fetch("<?= APP_URL ?>api/stats/horaria?" + filtros)
  .then(r => r.json())
  .then(data => {
    const ctx = document.getElementById("chartHoraria");
    const labels = Array.from({length: 24}, (_, i) => i + ":00");
    new Chart(ctx, {
      type: "bar",
      data: {
        labels: labels,
        datasets: [{
          label: "Incidentes por hora",
          data: data,
          backgroundColor: "rgba(153, 102, 255, 0.6)",
          borderColor: "rgba(153, 102, 255, 1)",
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: "top" } },
        scales: { y: { beginAtZero: true } }
      }
    });
  });

// Gráfico de tiempos
fetch("<?= APP_URL ?>api/stats/tiempos?" + filtros)
  .then(r => r.json())
  .then(data => {
    const ctx = document.getElementById("chartTiempos");
    new Chart(ctx, {
      type: "bar",
      data: {
        labels: ["Despacho", "Traslado", "Intervención", "Total"],
        datasets: [{
          label: "Minutos promedio",
          data: [
            Math.round(data.tiempo_despacho || 0),
            Math.round(data.tiempo_traslado || 0),
            Math.round(data.tiempo_intervencion || 0),
            Math.round(data.tiempo_total || 0)
          ],
          backgroundColor: [
            "rgba(255, 159, 64, 0.6)",
            "rgba(255, 205, 86, 0.6)",
            "rgba(75, 192, 192, 0.6)",
            "rgba(54, 162, 235, 0.6)"
          ],
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
      }
    });
  });
</script>
