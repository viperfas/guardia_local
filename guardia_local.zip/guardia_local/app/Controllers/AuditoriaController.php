<?php
declare(strict_types=1);
class AuditoriaController extends Controller {
    public function index(): void {
        $db = Database::connection();
        $tipo = $_GET["tipo"] ?? "";
        $modulo = $_GET["modulo"] ?? "";
        $usuario = $_GET["usuario"] ?? "";
        $desde = $_GET["desde"] ?? date("Y-m-d", strtotime("-7 days"));
        $hasta = $_GET["hasta"] ?? date("Y-m-d");
        $where = ["a.fecha_hora BETWEEN ? AND ?"];
        $params = [$desde." 00:00:00",$hasta." 23:59:59"];
        if ($tipo) { $where[] = "a.tipo_operacion = ?"; $params[] = $tipo; }
        if ($modulo) { $where[] = "a.modulo = ?"; $params[] = $modulo; }
        if ($usuario) { $where[] = "u.usuario = ?"; $params[] = $usuario; }
        $sql = "SELECT a.*, u.usuario FROM auditoria a LEFT JOIN usuarios u ON u.id=a.id_usuario WHERE ".implode(" AND ", $where)." ORDER BY a.fecha_hora DESC LIMIT 1000";
        $stmt = $db->prepare($sql); $stmt->execute($params);
        $logs = $stmt->fetchAll();
        $tipos = $db->query("SELECT DISTINCT tipo_operacion FROM auditoria ORDER BY tipo_operacion")->fetchAll(PDO::FETCH_COLUMN);
        $modulos = $db->query("SELECT DISTINCT modulo FROM auditoria ORDER BY modulo")->fetchAll(PDO::FETCH_COLUMN);
        $usuarios = $db->query("SELECT DISTINCT usuario FROM usuarios ORDER BY usuario")->fetchAll(PDO::FETCH_COLUMN);
        $this->view("auditoria/index", ["logs"=>$logs,"tipos"=>$tipos,"modulos"=>$modulos,"usuarios"=>$usuarios,"tipo"=>$tipo,"modulo"=>$modulo,"usuario"=>$usuario,"desde"=>$desde,"hasta"=>$hasta]);
    }
}