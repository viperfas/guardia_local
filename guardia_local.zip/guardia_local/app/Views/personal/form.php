<h3><?= $p && isset($p["id"]) ? "Editar personal" : "Nuevo personal" ?></h3>
<form method="post" action="<?= APP_URL ?>personal/<?= $p && isset($p["id"]) ? "actualizar" : "guardar" ?>" class="bg-white p-3 rounded">
  <?= Csrf::field() ?>
  <?php if ($p && isset($p["id"])): ?><input type="hidden" name="id" value="<?= $p["id"] ?>"><?php endif; ?>
  <div class="row g-2">
    <div class="col-md-6"><label>Nombre completo</label><input name="nombre_completo" class="form-control" required value="<?= View::e($p["nombre_completo"]??"") ?>"></div>
    <div class="col-md-3"><label>Legajo</label><input name="legajo" class="form-control" value="<?= View::e($p["legajo"]??"") ?>"></div>
    <div class="col-md-3"><label>Cargo</label><input name="cargo" class="form-control" value="<?= View::e($p["cargo"]??"") ?>"></div>
    <div class="col-md-4"><label>Turno</label>
      <select name="turno" class="form-select">
        <option value="">-</option>
        <?php foreach (["Mañana","Tarde","Noche","Rotativo"] as $t): ?>
          <option <?= ($p["turno"]??"")==$t?"selected":"" ?>><?= $t ?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>
  <button class="btn btn-primary mt-3">Guardar</button>
  <a href="<?= APP_URL ?>personal" class="btn btn-secondary mt-3">Cancelar</a>
</form>
