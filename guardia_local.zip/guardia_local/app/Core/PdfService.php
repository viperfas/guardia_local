<?php
declare(strict_types=1);

class PdfService
{
    /**
     * Genera un PDF con datos y gráficos
     */
    public static function generar(string $titulo, array $datos, array $graficosBase64 = []): string
    {
        // Verificar que Dompdf esté disponible
        $autoloadPath = ROOT_PATH . 'vendor/autoload.php';
        if (file_exists($autoloadPath)) {
            require_once $autoloadPath;
        } else {
            throw new Exception("Dompdf no está instalado. Ejecutá: composer require dompdf/dompdf");
        }
        
        // Generar HTML del PDF
        $html = self::generarHtml($titulo, $datos, $graficosBase64);
        
        // Crear instancia de Dompdf
        $dompdf = new \Dompdf\Dompdf([
            'isRemoteEnabled' => true,
            'defaultFont' => 'sans-serif'
        ]);
        
        $dompdf->loadHtml($html, ['isRemoteEnabled' => true]);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        
        return $dompdf->output();
    }
    
    /**
     * Genera el HTML para el PDF
     */
    private static function generarHtml(string $titulo, array $datos, array $graficosBase64): string
    {
        $fecha = date('d/m/Y H:i');
        $municipio = $datos['municipio'] ?? 'Guardia Local';
        
        $html = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 11px;
            line-height: 1.4;
            color: #333;
        }
        .header {
            text-align: center;
            border-bottom: 3px solid #1f2d3d;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }
        .header h1 {
            color: #1f2d3d;
            margin: 0;
            font-size: 24px;
        }
        .header p {
            margin: 5px 0;
            color: #666;
        }
        .section {
            margin-bottom: 25px;
            page-break-inside: avoid;
        }
        .section h2 {
            color: #1f2d3d;
            border-left: 4px solid #0d6efd;
            padding-left: 10px;
            font-size: 16px;
            margin-bottom: 10px;
        }
        .stats-grid {
            display: table;
            width: 100%;
            margin-bottom: 15px;
        }
        .stat-box {
            display: table-cell;
            width: 25%;
            text-align: center;
            padding: 15px;
            border: 1px solid #ddd;
            background: #f8f9fa;
        }
        .stat-box h3 {
            margin: 0;
            font-size: 28px;
            color: #0d6efd;
        }
        .stat-box p {
            margin: 5px 0 0 0;
            font-size: 10px;
            color: #666;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
        }
        table th {
            background: #1f2d3d;
            color: white;
            padding: 8px;
            text-align: left;
            font-size: 10px;
        }
        table td {
            padding: 6px 8px;
            border-bottom: 1px solid #ddd;
            font-size: 10px;
        }
        table tr:nth-child(even) {
            background: #f8f9fa;
        }
        .grafico {
            text-align: center;
            margin: 15px 0;
            page-break-inside: avoid;
        }
        .grafico img {
            max-width: 100%;
            height: auto;
            border: 1px solid #ddd;
        }
        .grafico h3 {
            color: #1f2d3d;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .footer {
            margin-top: 30px;
            padding-top: 15px;
            border-top: 1px solid #ddd;
            text-align: center;
            font-size: 9px;
            color: #999;
        }
        .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 9px;
            color: white;
        }
        .badge-danger { background: #dc3545; }
        .badge-warning { background: #ffc107; color: #333; }
        .badge-success { background: #198754; }
        .badge-info { background: #0dcaf0; color: #333; }
    </style>
</head>
<body>
    <div class="header">
        <h1>' . htmlspecialchars($titulo) . '</h1>
        <p><strong>' . htmlspecialchars($municipio) . '</strong></p>
        <p>Generado el: ' . $fecha . '</p>
    </div>';
        
        // Estadísticas resumen
        if (!empty($datos['total']) || !empty($datos['criticos'])) {
            $html .= '<div class="section">
                <h2>📊 Resumen Estadístico</h2>
                <div class="stats-grid">';
            
            if (isset($datos['total'])) {
                $html .= '<div class="stat-box">
                    <h3>' . (int)$datos['total'] . '</h3>
                    <p>Total Incidentes</p>
                </div>';
            }
            if (isset($datos['criticos'])) {
                $html .= '<div class="stat-box">
                    <h3 style="color:#dc3545">' . (int)$datos['criticos'] . '</h3>
                    <p>Críticos</p>
                </div>';
            }
            if (isset($datos['resueltos'])) {
                $html .= '<div class="stat-box">
                    <h3 style="color:#198754">' . (int)$datos['resueltos'] . '</h3>
                    <p>Resueltos</p>
                </div>';
            }
            if (isset($datos['barrio_top'])) {
                $html .= '<div class="stat-box">
                    <h3 style="font-size:16px;color:#1f2d3d">' . htmlspecialchars($datos['barrio_top']) . '</h3>
                    <p>Zona Más Crítica</p>
                </div>';
            }
            
            $html .= '</div></div>';
        }
        
        // Tablas de datos
        $tablas = [
            'por_barrio' => 'Incidentes por Barrio',
            'por_categoria' => 'Incidentes por Categoría',
            'por_prioridad' => 'Incidentes por Prioridad',
            'por_estado' => 'Incidentes por Estado',
            'por_dia' => 'Incidentes por Día de la Semana',
            'por_hora' => 'Incidentes por Hora'
        ];
        
        foreach ($tablas as $key => $titulo_tabla) {
            if (!empty($datos[$key]) && is_array($datos[$key])) {
                $html .= '<div class="section">
                    <h2>' . $titulo_tabla . '</h2>
                    <table>
                        <thead><tr>';
                
                $primer = reset($datos[$key]);
                foreach (array_keys($primer) as $col) {
                    $html .= '<th>' . htmlspecialchars(ucfirst(str_replace('_', ' ', $col))) . '</th>';
                }
                
                $html .= '</tr></thead><tbody>';
                
                foreach ($datos[$key] as $fila) {
                    $html .= '<tr>';
                    foreach ($fila as $valor) {
                        $html .= '<td>' . htmlspecialchars((string)$valor) . '</td>';
                    }
                    $html .= '</tr>';
                }
                
                $html .= '</tbody></table></div>';
            }
        }
        
        // Gráficos como imágenes
        if (!empty($graficosBase64)) {
            $html .= '<div class="section">
                <h2>📈 Gráficos Estadísticos</h2>';
            
            foreach ($graficosBase64 as $grafico) {
                if (!empty($grafico['imagen']) && !empty($grafico['titulo'])) {
                    $html .= '<div class="grafico">
                        <h3>' . htmlspecialchars($grafico['titulo']) . '</h3>
                        <img src="' . $grafico['imagen'] . '" alt="' . htmlspecialchars($grafico['titulo']) . '">
                    </div>';
                }
            }
            
            $html .= '</div>';
        }
        
        // Informe de IA (si existe)
        if (!empty($datos['informe_ia'])) {
            $html .= '<div class="section">
                <h2>🤖 Análisis de Inteligencia Artificial</h2>
                <div style="background:#f8f9fa;padding:15px;border-left:4px solid #0d6efd">
                    ' . nl2br(htmlspecialchars($datos['informe_ia'])) . '
                </div>
            </div>';
        }
        
        $html .= '<div class="footer">
            <p>Documento generado automáticamente por el Sistema de Guardia Local</p>
            <p>Los datos han sido anonimizados conforme al requisito 21.B de privacidad</p>
        </div>
    </body>
</html>';
        
        return $html;
    }
}