<h3 class="mb-4">📊 Generar PDF con Gráficos Estadísticos</h3>

<?php if (!empty($_SESSION['error'])): ?>
<div class="alert alert-danger"><?= View::e($_SESSION['error']) ?></div>
<?php unset($_SESSION['error']); endif; ?>

<div class="card bg-white p-4">
  <form method="post" action="<?= APP_URL ?>reportes/generar_pdf" id="formPdf" >
    <?= Csrf::field() ?>
    <input type="hidden" name="graficos" id="graficosData" value="">
    
    <div class="row g-3 mb-3">
      <div class="col-md-6">
        <label>Título del informe</label>
        <input type="text" name="titulo" class="form-control" value="Informe Estadístico de Incidentes" required>
      </div>
      <div class="col-md-3">
        <label>Fecha desde</label>
        <input type="date" name="desde" class="form-control" value="<?= date('Y-m-01', strtotime('-1 month')) ?>" required>
      </div>
      <div class="col-md-3">
        <label>Fecha hasta</label>
        <input type="date" name="hasta" class="form-control" value="<?= date('Y-m-d') ?>" required>
      </div>
    </div>
    
    <div class="row g-3 mb-3">
      <div class="col-md-6">
        <div class="form-check">
          <input type="checkbox" name="incluir_graficos" value="1" class="form-check-input" id="chkGraficos" checked>
          <label class="form-check-label" for="chkGraficos">
            <strong>Incluir gráficos estadísticos</strong><br>
            <small class="text-muted">Genera gráficos de barras, tortas y líneas</small>
          </label>
        </div>
      </div>
      <div class="col-md-6">
        <div class="form-check">
          <input type="checkbox" name="incluir_ia" value="1" class="form-check-input" id="chkIa">
          <label class="form-check-label" for="chkIa">
            <strong>Incluir análisis de IA</strong><br>
            <small class="text-muted">Genera un análisis ejecutivo con IA</small>
          </label>
        </div>
      </div>
    </div>
    
    <div id="previewGraficos" class="mb-3" style="display:none">
      <h5>Vista previa de gráficos:</h5>
      <div class="row g-3" id="graficosContainer"></div>
    </div>
    
    <button type="button" class="btn btn-outline-primary" id="btnPreview">
      👁️ Vista previa de gráficos
    </button>
    <button type="submit" class="btn btn-primary btn-lg">
      📄 Generar PDF
    </button>
  </form>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<script>
const btnPreview = document.getElementById('btnPreview');
const previewDiv = document.getElementById('previewGraficos');
const container = document.getElementById('graficosContainer');
const graficosData = document.getElementById('graficosData');
let charts = [];

btnPreview.addEventListener('click', async () => {
  const desde = document.querySelector('[name="desde"]').value;
  const hasta = document.querySelector('[name="hasta"]').value;
  
  btnPreview.disabled = true;
  btnPreview.textContent = '⏳ Generando gráficos...';
  
  try {
    // Obtener datos
    const response = await fetch(`<?= APP_URL ?>reportes/datos_pdf?desde=${desde}&hasta=${hasta}`);
    const datos = await response.json();
    
    container.innerHTML = '';
    charts.forEach(c => c.destroy());
    charts = [];
    
    // Gráfico 1: Por barrio
    if (datos.por_barrio && datos.por_barrio.length > 0) {
      const div = document.createElement('div');
      div.className = 'col-md-6';
      div.innerHTML = '<canvas id="chart1"></canvas>';
      container.appendChild(div);
      
      const ctx = document.getElementById('chart1').getContext('2d');
      const chart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: datos.por_barrio.map(d => d.nombre),
          datasets: [{
            label: 'Incidentes',
            data: datos.por_barrio.map(d => d.total),
            backgroundColor: '#0d6efd'
          }]
        },
        options: {
          responsive: true,
          plugins: { title: { display: true, text: 'Incidentes por Barrio' } }
        }
      });
      charts.push(chart);
    }
    
    // Gráfico 2: Por prioridad (torta)
    if (datos.por_prioridad && datos.por_prioridad.length > 0) {
      const div = document.createElement('div');
      div.className = 'col-md-6';
      div.innerHTML = '<canvas id="chart2"></canvas>';
      container.appendChild(div);
      
      const ctx = document.getElementById('chart2').getContext('2d');
      const chart = new Chart(ctx, {
        type: 'pie',
        data: {
          labels: datos.por_prioridad.map(d => d.prioridad),
          datasets: [{
            data: datos.por_prioridad.map(d => d.total),
            backgroundColor: ['#dc3545', '#fd7e14', '#ffc107', '#198754']
          }]
        },
        options: {
          responsive: true,
          plugins: { title: { display: true, text: 'Distribución por Prioridad' } }
        }
      });
      charts.push(chart);
    }
    
    // Gráfico 3: Por hora (línea)
    if (datos.por_hora && datos.por_hora.length > 0) {
      const div = document.createElement('div');
      div.className = 'col-md-12';
      div.innerHTML = '<canvas id="chart3"></canvas>';
      container.appendChild(div);
      
      const ctx = document.getElementById('chart3').getContext('2d');
      const chart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: datos.por_hora.map(d => d.hora + 'h'),
          datasets: [{
            label: 'Incidentes',
            data: datos.por_hora.map(d => d.total),
            borderColor: '#0d6efd',
            backgroundColor: 'rgba(13,110,253,0.1)',
            fill: true
          }]
        },
        options: {
          responsive: true,
          plugins: { title: { display: true, text: 'Incidentes por Hora del Día' } }
        }
      });
      charts.push(chart);
    }
    
    previewDiv.style.display = 'block';
    
  } catch (err) {
    alert('Error al generar vista previa: ' + err.message);
  }
  
  btnPreview.disabled = false;
  btnPreview.textContent = '👁️ Vista previa de gráficos';
});

// Al enviar el formulario, capturar gráficos como imágenes
document.getElementById('formPdf').addEventListener('submit', (e) => {
  if (document.getElementById('chkGraficos').checked && charts.length > 0) {
    const graficos = charts.map((chart, i) => ({
      titulo: chart.options.plugins.title.text,
      imagen: chart.toBase64Image('image/png', 1.0)
    }));
    graficosData.value = JSON.stringify(graficos);
  }
});
</script>