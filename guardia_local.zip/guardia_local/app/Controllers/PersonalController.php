<?php
declare(strict_types=1);
class PersonalController extends Controller {
    public function index(): void {
        $db = Database::connection();
        $personal = $db->query("SELECT * FROM personal WHERE activo=1 ORDER BY nombre_completo")->fetchAll();
        $this->view("personal/index", ["personal"=>$personal]);
    }
    public function create(): void {
        $this->view("personal/form", ["p"=>null]);
    }
    public function store(): void {
        $this->requirePost();
        $d = $_POST;
        $db = Database::connection();
        $stmt = $db->prepare("INSERT INTO personal (nombre_completo, legajo, cargo, turno, activo) VALUES (?,?,?,?,1)");
        $stmt->execute([$d["nombre_completo"],$d["legajo"]??null,$d["cargo"]??null,$d["turno"]??null]);
        Audit::log("alta_personal","personal",(string)$db->lastInsertId());
        $this->redirect("personal");
    }
    public function edit(): void {
        $id = (int)($_GET["id"]??0);
        $db = Database::connection();
        $stmt = $db->prepare("SELECT * FROM personal WHERE id=?");
        $stmt->execute([$id]);
        $p = $stmt->fetch();
        if (!$p) { $this->redirect("personal"); return; }
        $this->view("personal/form", ["p"=>$p]);
    }
    public function update(): void {
        $this->requirePost();
        $d = $_POST;
        $db = Database::connection();
        $stmt = $db->prepare("UPDATE personal SET nombre_completo=?, legajo=?, cargo=?, turno=? WHERE id=?");
        $stmt->execute([$d["nombre_completo"],$d["legajo"]??null,$d["cargo"]??null,$d["turno"]??null,(int)$d["id"]]);
        Audit::log("edit_personal","personal",$d["id"]);
        $this->redirect("personal");
    }
    public function delete(): void {
        $this->requirePost();
        $id = (int)($_POST["id"]??0);
        $db = Database::connection();
        // Verificar si está en equipos o intervenciones
        $enEquipos = $db->prepare("SELECT COUNT(*) FROM equipos_integrantes WHERE id_personal=?");
        $enEquipos->execute([$id]);
        if ($enEquipos->fetchColumn() > 0) {
            $_SESSION['error'] = "No se puede eliminar: pertenece a un equipo";
            $this->redirect("personal");
            return;
        }
        $db->prepare("UPDATE personal SET activo=0 WHERE id=?")->execute([$id]);
        Audit::log("baja_personal","personal",(string)$id);
        $this->redirect("personal");
    }
}