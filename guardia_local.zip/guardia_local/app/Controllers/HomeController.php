<?php
declare(strict_types=1);
class HomeController extends Controller {
    public function index(): void { $this->dashboard(); }
    public function dashboard(): void {
        $db = Database::connection();
        $stats = [
            "vecinos"       => (int)$db->query("SELECT COUNT(*) FROM vecinos WHERE activo=1")->fetchColumn(),
            "incidentes"    => (int)$db->query("SELECT COUNT(*) FROM incidentes")->fetchColumn(),
            "pendientes"    => (int)$db->query("SELECT COUNT(*) FROM incidentes WHERE estado IN ('Recibido','Pendiente de evaluación')")->fetchColumn(),
            "criticos"      => (int)$db->query("SELECT COUNT(*) FROM incidentes WHERE prioridad='Crítica' AND estado NOT IN ('Resuelto','Cerrado')")->fetchColumn(),
            "intervenciones"=> (int)$db->query("SELECT COUNT(*) FROM intervenciones WHERE estado='En intervención'")->fetchColumn(),
            "moviles_disp"  => (int)$db->query("SELECT COUNT(*) FROM moviles WHERE estado='Disponible'")->fetchColumn(),
        ];
        $this->view("dashboard/index", ["stats"=>$stats]);
    }
}
