<?php
declare(strict_types=1);
date_default_timezone_set("America/Argentina/Cordoba");

define("ROOT_PATH", dirname(__DIR__) . DIRECTORY_SEPARATOR);
define("PUBLIC_PATH", __DIR__ . DIRECTORY_SEPARATOR);
define("APP_PATH", ROOT_PATH . "app" . DIRECTORY_SEPARATOR);
define("CONFIG_PATH", ROOT_PATH . "config" . DIRECTORY_SEPARATOR);
define("STORAGE_PATH", ROOT_PATH . "storage" . DIRECTORY_SEPARATOR);

$dbConfigFile = CONFIG_PATH . "database.php";
if (!file_exists($dbConfigFile) || filesize($dbConfigFile) < 20) {
    header("Location: install.php");
    exit;
}

require_once CONFIG_PATH . "config.php";
require_once APP_PATH . "Core/Database.php";
require_once APP_PATH . "Core/Session.php";
require_once APP_PATH . "Core/Csrf.php";
require_once APP_PATH . "Core/Permission.php";
require_once APP_PATH . 'Helpers/permissions.php';
require_once APP_PATH . "Core/Router.php";
require_once APP_PATH . "Core/Controller.php";
require_once APP_PATH . "Core/Model.php";
require_once APP_PATH . "Core/View.php";
require_once APP_PATH . "Core/Audit.php";
require_once APP_PATH . "Core/Validator.php";
require_once APP_PATH . "Core/Anonymizer.php";
require_once APP_PATH . 'Core/Permission.php';
require_once APP_PATH . 'Core/AiService.php';
require_once APP_PATH . 'Core/PdfService.php';
require_once APP_PATH . 'Core/PdfGenerator.php';
require_once APP_PATH . 'Core/Export.php';
require_once APP_PATH . 'Core/Backup.php';
require_once CONFIG_PATH . "routes.php";

Session::start();

if (APP_DEBUG) {
    ini_set("display_errors", "1");
    error_reporting(E_ALL);
} else {
    ini_set("display_errors", "0");
    error_reporting(0);
    set_exception_handler(function(Throwable $e){
        http_response_code(500);
        echo "<h1>Error interno</h1><p>Consulte al administrador.</p>";
        error_log($e->getMessage());
    });
}

$url = $_GET["url"] ?? "";
$url = trim($url, "/");
Router::dispatch($url);

// Permission se carga automáticamente desde Router
