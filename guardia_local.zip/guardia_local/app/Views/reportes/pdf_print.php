<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($titulo) ?></title>
<style>
@page { 
    size: A4; 
    margin: 15mm;
}
* { box-sizing: border-box; }
body {
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 11pt;
    line-height: 1.5;
    color: #222;
    margin: 0;
    padding: 20px;
    background: #fff;
}
.no-print {
    background: #fff3cd;
    border: 2px solid #ffc107;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    text-align: center;
}
.no-print button {
    background: #0d6efd;
    color: white;
    border: none;
    padding: 10px 25px;
    border-radius: 5px;
    font-size: 14px;
    cursor: pointer;
    margin: 5px;
}
.no-print button:hover { background: #0b5ed7; }
.no-print button.cancel { background: #6c757d; }

.header {
    text-align: center;
    border-bottom: 3px solid #1f2d3d;
    padding-bottom: 15px;
    margin-bottom: 25px;
}
.header h1 {
    color: #1f2d3d;
    margin: 0 0 10px 0;
    font-size: 24pt;
}
.header .meta {
    color: #666;
    font-size: 10pt;
    margin: 3px 0;
}

.section {
    margin-bottom: 25px;
    page-break-inside: avoid;
}
.section h2 {
    color: #1f2d3d;
    border-left: 5px solid #0d6efd;
    padding-left: 12px;
    font-size: 14pt;
    margin: 0 0 12px 0;
}

.stats-grid {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
}
.stat-box {
    flex: 1;
    text-align: center;
    padding: 15px 10px;
    border: 1px solid #ddd;
    background: #f8f9fa;
    border-radius: 6px;
}
.stat-box h3 {
    margin: 0;
    font-size: 28pt;
    color: #0d6efd;
    font-weight: bold;
}
.stat-box.critical h3 { color: #dc3545; }
.stat-box.success h3 { color: #198754; }
.stat-box.info h3 { color: #1f2d3d; font-size: 14pt; }
.stat-box p {
    margin: 5px 0 0 0;
    font-size: 9pt;
    color: #666;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 15px;
    font-size: 10pt;
}
table th {
    background: #1f2d3d;
    color: white;
    padding: 8px 10px;
    text-align: left;
    font-weight: 600;
}
table td {
    padding: 6px 10px;
    border-bottom: 1px solid #e0e0e0;
}
table tr:nth-child(even) { background: #f8f9fa; }
table tr:hover { background: #e7f1ff; }
table td.num { text-align: right; font-weight: 600; }

.grafico {
    text-align: center;
    margin: 20px 0;
    page-break-inside: avoid;
}
.grafico img {
    max-width: 100%;
    height: auto;
    border: 1px solid #ddd;
    border-radius: 4px;
}
.grafico h3 {
    color: #1f2d3d;
    font-size: 12pt;
    margin: 0 0 10px 0;
}

.ia-analysis {
    background: linear-gradient(135deg, #f8f9fa 0%, #e7f1ff 100%);
    padding: 20px;
    border-left: 5px solid #0d6efd;
    border-radius: 4px;
    margin-top: 10px;
    line-height: 1.7;
}

.footer {
    margin-top: 40px;
    padding-top: 15px;
    border-top: 2px solid #ddd;
    text-align: center;
    font-size: 8pt;
    color: #999;
}

@media print {
    .no-print { display: none !important; }
    body { padding: 0; font-size: 10pt; }
    .section { page-break-inside: avoid; }
    .grafico { page-break-inside: avoid; }
    table { page-break-inside: auto; }
    tr { page-break-inside: avoid; }
    h2 { page-break-after: avoid; }
}
</style>
</head>
<body>

<div class="no-print">
    <h3 style="margin:0 0 10px 0">📄 Vista previa del PDF</h3>
    <p style="margin:0 0 15px 0">Hacé clic en <strong>"Imprimir / Guardar PDF"</strong> y en el diálogo de impresión seleccioná <strong>"Guardar como PDF"</strong> como destino.</p>
    <button onclick="window.print()">🖨️ Imprimir / Guardar PDF</button>
    <button class="cancel" onclick="history.back()">← Volver</button>
</div>

<div class="header">
    <h1><?= htmlspecialchars($titulo) ?></h1>
    <div class="meta"><strong><?= htmlspecialchars($datos['municipio']) ?></strong></div>
    <div class="meta">Período: <?= htmlspecialchars($desde) ?> al <?= htmlspecialchars($hasta) ?></div>
    <div class="meta">Generado el: <?= date('d/m/Y H:i') ?></div>
</div>

<div class="section">
    <h2>📊 Resumen Estadístico</h2>
    <div class="stats-grid">
        <div class="stat-box">
            <h3><?= (int)$datos['total'] ?></h3>
            <p>Total Incidentes</p>
        </div>
        <div class="stat-box critical">
            <h3><?= (int)$datos['criticos'] ?></h3>
            <p>Críticos</p>
        </div>
        <div class="stat-box success">
            <h3><?= (int)$datos['resueltos'] ?></h3>
            <p>Resueltos</p>
        </div>
        <div class="stat-box info">
            <h3><?= htmlspecialchars($datos['barrio_top'] ?? 'N/A') ?></h3>
            <p>Zona Más Crítica</p>
        </div>
    </div>
</div>

<?php
$tablas = [
    'por_barrio' => '🏘️ Incidentes por Barrio',
    'por_categoria' => '📂 Incidentes por Categoría',
    'por_prioridad' => '⚠️ Incidentes por Prioridad',
    'por_estado' => '📌 Incidentes por Estado',
    'por_dia' => '📅 Incidentes por Día de la Semana',
    'por_hora' => '🕐 Incidentes por Hora del Día'
];

foreach ($tablas as $key => $tituloTabla):
    if (!empty($datos[$key]) && is_array($datos[$key])):
?>
<div class="section">
    <h2><?= $tituloTabla ?></h2>
    <table>
        <thead>
            <tr>
                <?php foreach (array_keys($datos[$key][0]) as $col): ?>
                    <th><?= htmlspecialchars(ucfirst(str_replace('_', ' ', $col))) ?></th>
                <?php endforeach; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($datos[$key] as $fila): ?>
                <tr>
                    <?php foreach ($fila as $i => $valor): ?>
                        <td<?= $i > 0 ? ' class="num"' : '' ?>><?= htmlspecialchars((string)$valor) ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php 
    endif;
endforeach; 
?>

<?php if (!empty($graficos) && is_array($graficos)): ?>
<div class="section">
    <h2>📈 Gráficos Estadísticos</h2>
    <?php foreach ($graficos as $grafico): ?>
        <?php if (!empty($grafico['imagen']) && !empty($grafico['titulo'])): ?>
        <div class="grafico">
            <h3><?= htmlspecialchars($grafico['titulo']) ?></h3>
            <img src="<?= $grafico['imagen'] ?>" alt="<?= htmlspecialchars($grafico['titulo']) ?>">
        </div>
        <?php endif; ?>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if (!empty($datos['informe_ia'])): ?>
<div class="section">
    <h2>🤖 Análisis de Inteligencia Artificial</h2>
    <div class="ia-analysis">
        <?= nl2br(htmlspecialchars($datos['informe_ia'])) ?>
    </div>
</div>
<?php endif; ?>

<div class="footer">
    <p>Documento generado automáticamente por el Sistema Integral de Guardia Local</p>
    <p>Los datos han sido anonimizados conforme al requisito 21.B de privacidad</p>
    <p>© <?= date('Y') ?> - Municipalidad de Villa Giardino</p>
</div>

<script>
// Auto-imprimir al cargar (opcional, descomentar si se desea)
// window.addEventListener('load', () => setTimeout(() => window.print(), 500));
</script>

</body>
</html>