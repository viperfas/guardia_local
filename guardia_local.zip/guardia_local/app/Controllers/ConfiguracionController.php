<?php
declare(strict_types=1);

class ConfiguracionController extends Controller
{
    public function index(): void
    {
        $db = Database::connection();
        $configs = $db->query("SELECT clave, valor, descripcion FROM configuracion ORDER BY clave")->fetchAll();
        $this->view("configuracion/index", ["configs" => $configs]);
    }
    
    public function save(): void
    {
        $this->requirePost();
        $db = Database::connection();
        
        $guardadas = 0;
        
        if (!empty($_POST["config"]) && is_array($_POST["config"])) {
            foreach ($_POST["config"] as $clave => $valor) {
                $stmt = $db->prepare("SELECT COUNT(*) FROM configuracion WHERE clave = ?");
                $stmt->execute([$clave]);
                $existe = $stmt->fetchColumn() > 0;
                
                if ($existe) {
                    $db->prepare("UPDATE configuracion SET valor = ? WHERE clave = ?")->execute([$valor, $clave]);
                } else {
                    $db->prepare("INSERT INTO configuracion (clave, valor) VALUES (?, ?)")->execute([$clave, $valor]);
                }
                $guardadas++;
            }
        }
        
        if (class_exists('Audit')) {
            Audit::log("configuracion_editada", "configuracion", "Guardadas: $guardadas");
        }
        
        $_SESSION["config_ok"] = "Configuración guardada correctamente ($guardadas valores)";
        $this->redirect("configuracion");
    }
}