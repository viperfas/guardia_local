<?php
declare(strict_types=1);
class BackupController extends Controller {
    public function index(): void {
        $this->view("respaldos/index", ["respaldos"=>Backup::list()]);
    }
    public function create(): void {
        $this->requirePost();
        $r = Backup::create("manual");
        if ($r["ok"]) { Audit::log("backup_creado","respaldos",$r["archivo"]); $_SESSION["backup_ok"] = "Backup creado: ".$r["archivo"]." (".round($r["tamano"]/1024,2)." KB)"; }
        else $_SESSION["backup_err"] = "Error: ".($r["error"]??"desconocido");
        $this->redirect("respaldos");
    }
    public function download(): void {
        $id = (int)($_GET["id"] ?? 0);
        $db = Database::connection();
        $stmt = $db->prepare("SELECT nombre_archivo FROM respaldos WHERE id=?"); $stmt->execute([$id]);
        $r = $stmt->fetch(); if (!$r) { $this->redirect("respaldos"); return; }
        $file = Backup::getBackupDir().DIRECTORY_SEPARATOR.$r["nombre_archivo"];
        if (!file_exists($file)) { $this->redirect("respaldos"); return; }
        Audit::log("backup_descargado","respaldos",(string)$id);
        header('Content-Type: application/sql');
        header('Content-Disposition: attachment; filename="'.$r["nombre_archivo"].'"');
        readfile($file); exit;
    }
    public function restore(): void {
        $this->requirePost();
        $id = (int)($_POST["id"] ?? 0);
        $r = Backup::restore($id);
        if ($r["ok"]) $_SESSION["backup_ok"] = "BD restaurada correctamente";
        else $_SESSION["backup_err"] = "Error: ".($r["error"]??"desconocido");
        $this->redirect("respaldos");
    }
    public function delete(): void {
        $this->requirePost();
        Backup::delete((int)($_POST["id"] ?? 0));
        $this->redirect("respaldos");
    }
}