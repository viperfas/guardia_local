<?php
declare(strict_types=1);

class GeoJsonValidator {
    public static function validar(string $geojson): array {
        $data = json_decode($geojson, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return ["valido" => false, "error" => "JSON inválido: " . json_last_error_msg()];
        }
        
        if (!isset($data["type"])) {
            return ["valido" => false, "error" => "Falta el campo 'type'"];
        }
        
        $tipo = $data["type"];
        
        if ($tipo === "FeatureCollection") {
            if (empty($data["features"]) || !is_array($data["features"])) {
                return ["valido" => false, "error" => "FeatureCollection sin features"];
            }
            foreach ($data["features"] as $i => $feat) {
                $r = self::validarFeature($feat);
                if (!$r["valido"]) return ["valido" => false, "error" => "Feature $i: " . $r["error"]];
            }
            return ["valido" => true, "tipo" => "FeatureCollection", "features" => count($data["features"])];
        }
        
        if ($tipo === "Feature") {
            return self::validarFeature($data);
        }
        
        if (in_array($tipo, ["Polygon", "MultiPolygon"])) {
            return self::validarGeometria($data);
        }
        
        return ["valido" => false, "error" => "Tipo no soportado: $tipo (se requiere Polygon, MultiPolygon, Feature o FeatureCollection)"];
    }
    
    private static function validarFeature(array $feat): array {
        if (!isset($feat["type"]) || $feat["type"] !== "Feature") {
            return ["valido" => false, "error" => "No es un Feature"];
        }
        if (!isset($feat["geometry"])) {
            return ["valido" => false, "error" => "Falta geometry"];
        }
        return self::validarGeometria($feat["geometry"]);
    }
    
    private static function validarGeometria(array $geom): array {
        $tipo = $geom["type"] ?? "";
        if (!in_array($tipo, ["Polygon", "MultiPolygon"])) {
            return ["valido" => false, "error" => "Geometría debe ser Polygon o MultiPolygon, recibido: $tipo"];
        }
        if (!isset($geom["coordinates"]) || !is_array($geom["coordinates"])) {
            return ["valido" => false, "error" => "Falta coordinates"];
        }
        return ["valido" => true, "tipo" => $tipo];
    }
    
    public static function normalizar(string $geojson): string {
        $data = json_decode($geojson, true);
        if (!$data) return $geojson;
        
        if ($data["type"] === "FeatureCollection" && !empty($data["features"])) {
            $first = $data["features"][0];
            if (isset($first["geometry"])) {
                return json_encode($first["geometry"], JSON_UNESCAPED_UNICODE);
            }
        }
        
        if ($data["type"] === "Feature" && isset($data["geometry"])) {
            return json_encode($data["geometry"], JSON_UNESCAPED_UNICODE);
        }
        
        return json_encode($data, JSON_UNESCAPED_UNICODE);
    }
    
    public static function extraerNombre(array $geojson): ?string {
        $data = json_decode($geojson, true);
        if (!$data) return null;
        
        if ($data["type"] === "FeatureCollection" && !empty($data["features"])) {
            return $data["features"][0]["properties"]["name"] 
                ?? $data["features"][0]["properties"]["NAME"]
                ?? $data["features"][0]["properties"]["nombre"]
                ?? null;
        }
        
        if ($data["type"] === "Feature") {
            return $data["properties"]["name"]
                ?? $data["properties"]["NAME"]
                ?? $data["properties"]["nombre"]
                ?? null;
        }
        
        return null;
    }
}