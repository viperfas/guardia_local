<!DOCTYPE html><html lang="es"><head><meta charset="utf-8">
<title><?= View::e(APP_NAME) ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<!--link rel="stylesheet" href="/guardia_local/public/assets/vendor/leaflet/leaflet.css">
<script src="/guardia_local/public/assets/vendor/leaflet/leaflet.js"></script-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.js"></script>

<!--link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin=""/-->
<style>
  body{background:#f4f6f9}
  .sidebar{min-height:100vh;background:#1f2d3d;color:#fff}
  .sidebar a{color:#cfd8e3;text-decoration:none;padding:10px 16px;display:block}
  .sidebar a:hover{background:#2c3e50;color:#fff}
  .sidebar .menu-section{padding:8px 16px;font-size:11px;text-transform:uppercase;color:#7a8a9e;margin-top:10px;border-top:1px solid #2c3e50}
  .sidebar a.submenu{padding-left:32px;font-size:13px}
  .topbar{background:#fff;border-bottom:1px solid #dee2e6}
  @media print { .sidebar, .topbar, .no-print { display: none !important; } main.col-md-10 { width: 100% !important; } body { background: white !important; } }
</style></head><body>
<div class="container-fluid"><div class="row">
<nav class="col-md-2 sidebar p-0">
  <div class="p-3 border-bottom border-secondary">
    <strong>Guardia Local</strong><br>
    <small>Villa Giardino</small>
  </div>

  <?php if (hasPerm('dashboard.ver') || true): ?>
  <a href="<?= APP_URL ?>dashboard">🏠 Dashboard</a>
  <?php endif; ?>

  <?php if (hasAnyPerm(['vecinos.ver','vecinos.crear'])): ?>
  <div class="menu-section">Vecinos</div>
  <?php if (hasPerm('vecinos.ver')): ?>
  <a href="<?= APP_URL ?>vecinos">👥 Ver vecinos</a>
  <?php endif; ?>
  <?php if (hasPerm('vecinos.crear')): ?>
  <a href="<?= APP_URL ?>vecinos/crear" class="submenu">➕ Nuevo vecino</a>
  <?php endif; ?>
  <?php endif; ?>

  <?php if (hasAnyPerm(['incidentes.ver','incidentes.crear'])): ?>
  <div class="menu-section">Incidentes</div>
  <?php if (hasPerm('incidentes.ver')): ?>
  <a href="<?= APP_URL ?>incidentes">🚨 Ver incidentes</a>
  <?php endif; ?>
  <?php if (hasPerm('incidentes.crear')): ?>
  <a href="<?= APP_URL ?>incidentes/crear" class="submenu">➕ Nuevo incidente</a>
  <?php endif; ?>
  <?php endif; ?>

  <?php if (hasAnyPerm(['intervenciones.ver','intervenciones.despachar','panel_operativo.ver'])): ?>
  <div class="menu-section">Operativo</div>
  <?php if (hasPerm('intervenciones.ver')): ?>
  <a href="<?= APP_URL ?>intervenciones">🚓 Intervenciones</a>
  <?php endif; ?>
  <?php if (hasPerm('panel_operativo.ver')): ?>
  <a href="<?= APP_URL ?>panel_operativo" class="submenu">📡 Panel operativo</a>
  <?php endif; ?>
  <?php endif; ?>

  <?php if (hasAnyPerm(['moviles.ver','personal.ver','equipos.ver'])): ?>
  <div class="menu-section">Recursos</div>
  <?php if (hasPerm('moviles.ver')): ?>
  <a href="<?= APP_URL ?>moviles">🚘 Móviles</a>
  <?php endif; ?>
  <?php if (hasPerm('personal.ver')): ?>
  <a href="<?= APP_URL ?>personal">👮 Personal</a>
  <?php endif; ?>
  <?php if (hasPerm('equipos.ver')): ?>
  <a href="<?= APP_URL ?>equipos">🎖️ Equipos</a>
  <?php endif; ?>
  <?php endif; ?>

  <?php if (hasAnyPerm(['mapa.ver','estadisticas.ver','ia.generar'])): ?>
  <div class="menu-section">Análisis</div>
  <?php if (hasPerm('mapa.ver')): ?>
  <a href="<?= APP_URL ?>barrios">🏘️ Barrios</a>
  <a href="<?= APP_URL ?>barrios/editor_visual" class="ps-4">🗺️ Editor visual</a>
  <a href="<?= APP_URL ?>mapa">🗺️ Mapa territorial</a>
  <?php endif; ?>
  <?php if (hasPerm('estadisticas.ver')): ?>
  <a href="<?= APP_URL ?>estadisticas">📊 Estadísticas</a>
  <?php endif; ?>
  <?php if (hasPerm('ia.generar')): ?>
  <a href="<?= APP_URL ?>informes_ia">🤖 Informes IA</a>
  <?php endif; ?>
  <?php endif; ?>

  <?php if (hasAnyPerm(['reportes.generar','auditoria.ver','respaldos.gestionar'])): ?>
  <div class="menu-section">Sistema</div>
  <?php if (hasPerm('reportes.generar')): ?>
  <a href="<?= APP_URL ?>reportes">📄 Reportes PDF</a>
  <?php endif; ?>
  <?php if (hasPerm('auditoria.ver')): ?>
  <a href="<?= APP_URL ?>auditoria">📜 Auditoría</a>
  <?php endif; ?>
  <?php if (hasPerm('respaldos.gestionar')): ?>
  <a href="<?= APP_URL ?>respaldos">💾 Copias de seguridad</a>
  <?php endif; ?>
  <?php endif; ?>

  <?php if (hasAnyPerm(['usuarios.gestionar','configuracion.editar'])): ?>
  <div class="menu-section">Administración</div>
  <?php if (hasPerm('usuarios.gestionar')): ?>
  <a href="<?= APP_URL ?>usuarios">🔐 Usuarios y permisos</a>
  <?php endif; ?>
  <?php if (hasPerm('configuracion.editar')): ?>
  <a href="<?= APP_URL ?>configuracion">⚙️ Configuración</a>
  <?php endif; ?>
  <?php endif; ?>

  <div class="menu-section">Mi cuenta</div>
  <a href="<?= APP_URL ?>perfil">👤 Mi perfil</a>
</nav>

<main class="col-md-10 p-0">
  <div class="topbar d-flex justify-content-between align-items-center p-2 px-3">
    <h5 class="mb-0"><?= View::e(APP_NAME) ?></h5>
    <div>
      <span class="me-3"><?= View::e($_SESSION['user_name'] ?? '') ?> — <em><?= View::e($_SESSION['user_role'] ?? '') ?></em></span>
      <a href="<?= APP_URL ?>logout" class="btn btn-sm btn-outline-danger">Salir</a>
    </div>
  </div>
  <div class="p-4"><?= $content ?></div>
</main></div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</body></html>