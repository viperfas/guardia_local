<?php
declare(strict_types=1);
class View {
    public static function e(?string $v): string { return htmlspecialchars((string)$v, ENT_QUOTES, "UTF-8"); }
}
