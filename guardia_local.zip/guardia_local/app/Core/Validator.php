<?php
declare(strict_types=1);
class Validator {
    public static function dniArgentino(string $v): bool {
        $v = preg_replace("/\D/","",$v);
        return strlen($v) === 7 || strlen($v) === 8;
    }
    public static function telefono(string $v): bool {
        $v = preg_replace("/\D/","",$v);
        return strlen($v) >= 6 && strlen($v) <= 20;
    }
}
