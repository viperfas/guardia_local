INSERT INTO `roles` (`id`,`nombre`,`descripcion`) VALUES
(1,'Administrador','Acceso total al sistema'),
(2,'Operador','Operador de guardia');

INSERT INTO `usuarios` (`usuario`,`password`,`nombre_completo`,`id_rol`,`activo`) VALUES
('admin','TEMPORAL','Administrador inicial',1,1);

INSERT INTO `permisos` (`codigo`,`descripcion`) VALUES
('vecinos.ver','Ver vecinos'),
('vecinos.crear','Crear vecinos'),
('vecinos.editar','Editar vecinos'),
('incidentes.ver','Ver incidentes'),
('incidentes.crear','Crear incidentes'),
('intervenciones.despachar','Despachar intervenciones'),
('mapa.ver','Ver mapa territorial'),
('estadisticas.ver','Ver estadísticas'),
('ia.generar','Generar informes IA'),
('reportes.generar','Generar reportes'),
('auditoria.ver','Ver auditoría'),
('usuarios.gestionar','Gestionar usuarios'),
('configuracion.editar','Editar configuración'),
('respaldos.gestionar','Gestionar copias de seguridad');

INSERT INTO `barrios` (`nombre`,`descripcion`) VALUES
('Centro','Casco céntrico de Villa Giardino'),
('Barrio San Martín','Sector oeste'),
('Barrio Parque','Sector residencial'),
('Barrio Los Aromos','Sector norte'),
('Barrio Las Flores','Sector sur'),
('Barrio Intiyaco','Sector periurbano'),
('Barrio La Estación','Zona cercana a la estación'),
('Barrio El Dique','Zona próxima al dique');

INSERT INTO `categorias_incidentes` (`nombre`,`color`) VALUES
('Robo','#dc3545'),('Hurto','#fd7e14'),('Vandalismo','#ffc107'),
('Persona sospechosa','#6f42c1'),('Vehículo sospechoso','#20c997'),
('Violencia familiar','#d63384'),('Violencia en vía pública','#e35d6a'),
('Accidente de tránsito','#0dcaf0'),('Incendio','#dc3545'),
('Emergencia médica','#198754'),('Ruidos molestos','#6c757d'),
('Animales sueltos','#adb5bd'),('Animales peligrosos','#dc3545'),
('Conflictos vecinales','#fd7e14'),('Daños en espacios públicos','#0d6efd'),
('Situaciones sospechosas generales','#6f42c1'),('Emergencias generales','#dc3545'),
('Otros','#6c757d');

INSERT INTO `configuracion` (`clave`,`valor`,`descripcion`) VALUES
('municipio_nombre','Municipalidad de Villa Giardino','Nombre oficial'),
('municipio_provincia','Córdoba','Provincia'),
('municipio_pais','Argentina','País'),
('ia_proveedor','','Proveedor de IA'),
('ia_habilitada','0','0 = deshabilitada'),
('mapa_center_lat','-31.1470','Latitud central'),
('mapa_center_lng','-64.4010','Longitud central'),
('mapa_zoom','14','Zoom inicial');
