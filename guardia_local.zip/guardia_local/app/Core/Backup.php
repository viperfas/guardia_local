<?php
declare(strict_types=1);
class Backup {
    public static function getBackupDir(): string {
        $dir = STORAGE_PATH . "backups";
        if (!is_dir($dir)) mkdir($dir, 0775, true);
        return $dir;
    }
    public static function create(string $tipo = "manual"): array {
        $cfg = require CONFIG_PATH . "database.php";
        $filename = "backup_" . date("Ymd_His") . ".sql";
        $filepath = self::getBackupDir() . DIRECTORY_SEPARATOR . $filename;
        $mysqldump = self::findMysqldump();
        if ($mysqldump) {
            $pass = $cfg["password"] ? "-p".escapeshellarg($cfg["password"]) : "";
            $cmd = '"'.$mysqldump.'" -h'.escapeshellarg($cfg["host"]).' -P'.escapeshellarg($cfg["port"]).' -u'.escapeshellarg($cfg["username"]).' '.$pass.' '.escapeshellarg($cfg["dbname"]).' > "'.$filepath.'" 2>&1';
            exec($cmd, $output, $return);
            if ($return === 0 && file_exists($filepath) && filesize($filepath) > 100) {
                self::registrar($filename, $tipo, "ok");
                return ["ok"=>true,"archivo"=>$filename,"tamano"=>filesize($filepath)];
            }
        }
        return self::backupPhp($filepath, $cfg, $tipo);
    }
    private static function backupPhp(string $filepath, array $cfg, string $tipo): array {
        try {
            $db = Database::connection();
            $out = "-- Backup: ".date("Y-m-d H:i:s")."\n-- BD: ".$cfg["dbname"]."\n\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n\n";
            $tables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
            foreach ($tables as $table) {
                $out .= "-- Tabla: $table\n";
                $create = $db->query("SHOW CREATE TABLE `$table`")->fetch();
                $out .= "DROP TABLE IF EXISTS `$table`;\n".$create[1].";\n\n";
                $rows = $db->query("SELECT * FROM `$table`")->fetchAll();
                foreach ($rows as $row) {
                    $values = [];
                    foreach ($row as $v) $values[] = $v === null ? "NULL" : $db->quote($v);
                    $out .= "INSERT INTO `$table` VALUES (".implode(",", $values).");\n";
                }
                $out .= "\n";
            }
            $out .= "SET FOREIGN_KEY_CHECKS = 1;\n";
            file_put_contents($filepath, $out);
            self::registrar(basename($filepath), $tipo, "ok");
            return ["ok"=>true,"archivo"=>basename($filepath),"tamano"=>filesize($filepath)];
        } catch (Throwable $e) {
            self::registrar(basename($filepath), $tipo, "error");
            return ["ok"=>false,"error"=>$e->getMessage()];
        }
    }
    private static function findMysqldump(): ?string {
        $paths = ["C:\\xampp\\mysql\\bin\\mysqldump.exe","/usr/bin/mysqldump","/usr/local/bin/mysqldump"];
        foreach ($paths as $p) if (file_exists($p)) return $p;
        $cmd = strtoupper(substr(PHP_OS, 0, 3)) === "WIN" ? "where mysqldump 2>NUL" : "which mysqldump 2>/dev/null";
        $out = []; exec($cmd, $out);
        if (!empty($out[0]) && file_exists(trim($out[0]))) return trim($out[0]);
        return null;
    }
    private static function registrar(string $archivo, string $tipo, string $estado): void {
        try {
            $db = Database::connection();
            $stmt = $db->prepare("INSERT INTO respaldos (nombre_archivo, tamano_bytes, tipo, estado, id_usuario) VALUES (?,?,?,?,?)");
            $f = self::getBackupDir().DIRECTORY_SEPARATOR.$archivo;
            $stmt->execute([$archivo, file_exists($f)?filesize($f):0, $tipo, $estado, $_SESSION["user_id"]??null]);
        } catch (Throwable $e) { error_log("Backup: ".$e->getMessage()); }
    }
    public static function list(): array {
        try { $db = Database::connection(); return $db->query("SELECT * FROM respaldos ORDER BY fecha DESC LIMIT 100")->fetchAll(); }
        catch (Throwable $e) { return []; }
    }
    public static function delete(int $id): bool {
        try {
            $db = Database::connection();
            $r = $db->prepare("SELECT nombre_archivo FROM respaldos WHERE id=?"); $r->execute([$id]);
            $row = $r->fetch(); if (!$row) return false;
            $file = self::getBackupDir().DIRECTORY_SEPARATOR.$row["nombre_archivo"];
            if (file_exists($file)) unlink($file);
            $db->prepare("DELETE FROM respaldos WHERE id=?")->execute([$id]);
            Audit::log("backup_eliminado","respaldos",(string)$id);
            return true;
        } catch (Throwable $e) { return false; }
    }
    public static function restore(int $id): array {
        try {
            $db = Database::connection();
            $r = $db->prepare("SELECT nombre_archivo FROM respaldos WHERE id=? AND estado='ok'"); $r->execute([$id]);
            $row = $r->fetch(); if (!$row) return ["ok"=>false,"error"=>"No encontrado"];
            $file = self::getBackupDir().DIRECTORY_SEPARATOR.$row["nombre_archivo"];
            if (!file_exists($file)) return ["ok"=>false,"error"=>"Archivo no existe"];
            $db->exec(file_get_contents($file));
            Audit::log("backup_restaurado","respaldos",(string)$id);
            return ["ok"=>true];
        } catch (Throwable $e) { return ["ok"=>false,"error"=>$e->getMessage()]; }
    }
}