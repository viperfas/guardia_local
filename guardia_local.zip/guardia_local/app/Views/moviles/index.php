<div class="d-flex justify-content-between mb-3">
  <h3>Móviles</h3>
  <a href="<?= APP_URL ?>moviles/crear" class="btn btn-primary">➕ Nuevo móvil</a>
</div>
<?php if (!empty($_SESSION['error'])): ?><div class="alert alert-warning"><?= View::e($_SESSION['error']) ?></div><?php unset($_SESSION['error']); endif; ?>
<table class="table table-striped bg-white">
  <thead><tr><th>N° Interno</th><th>Tipo</th><th>Marca/Modelo</th><th>Patente</th><th>Estado</th><th>Acciones</th></tr></thead>
  <tbody>
  <?php foreach ($moviles as $m): ?>
    <tr>
      <td><strong><?= View::e($m["numero_interno"]) ?></strong></td>
      <td><?= View::e($m["tipo"]??"-") ?></td>
      <td><?= View::e(($m["marca"]??"")." ".($m["modelo"]??"")) ?></td>
      <td><?= View::e($m["patente"]??"-") ?></td>
      <td>
        <?php
        $colors = ["Disponible"=>"success","Asignado"=>"warning","En servicio"=>"primary","Fuera de servicio"=>"secondary","En mantenimiento"=>"danger"];
        $c = $colors[$m["estado"]] ?? "secondary";
        ?>
        <span class="badge bg-<?= $c ?>"><?= View::e($m["estado"]) ?></span>
      </td>
      <td>
        <a href="<?= APP_URL ?>moviles/editar?id=<?= $m["id"] ?>" class="btn btn-sm btn-outline-primary">✏️</a>
        <form method="post" action="<?= APP_URL ?>moviles/eliminar" style="display:inline" onsubmit="return confirm('¿Eliminar móvil?')">
          <?= Csrf::field() ?><input type="hidden" name="id" value="<?= $m["id"] ?>">
          <button class="btn btn-sm btn-outline-danger">🗑️</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>