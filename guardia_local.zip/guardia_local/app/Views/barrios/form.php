<h3><?= !empty($barrio["id"]) ? "Editar barrio" : "Nuevo barrio" ?></h3>

<?php if (!empty($_SESSION["error"])): ?><div class="alert alert-danger"><?= View::e($_SESSION["error"]) ?></div><?php unset($_SESSION["error"]); endif; ?>
<?php if (!empty($_SESSION["ok"])): ?><div class="alert alert-success"><?= View::e($_SESSION["ok"]) ?></div><?php unset($_SESSION["ok"]); endif; ?>

<div class="alert alert-warning">
  <strong>⚠️ Requisito legal:</strong> Los límites territoriales deben provenir de información oficial de la Municipalidad de Villa Giardino.
  No se permiten límites inventados o estimados.
</div>

<form method="post" action="<?= APP_URL ?>barrios/<?= !empty($barrio["id"]) ? "actualizar" : "guardar" ?>" class="bg-white p-3 rounded mb-3">
  <?= Csrf::field() ?>
  <?php if (!empty($barrio["id"])): ?><input type="hidden" name="id" value="<?= $barrio["id"] ?>"><?php endif; ?>
  
  <div class="row g-2">
    <div class="col-md-6">
      <label>Nombre del barrio *</label>
      <input name="nombre" class="form-control" required value="<?= View::e($barrio["nombre"] ?? "") ?>">
    </div>
    <div class="col-md-6">
      <label>Descripción</label>
      <input name="descripcion" class="form-control" value="<?= View::e($barrio["descripcion"] ?? "") ?>" placeholder="Ej: Sector oeste, oficial según ordenanza municipal...">
    </div>
    <div class="col-12">
      <label>GeoJSON del polígono</label>
      <textarea name="geojson" class="form-control font-monospace" rows="8" placeholder='Pegá aquí el GeoJSON oficial (tipo Polygon, MultiPolygon, Feature o FeatureCollection)'><?= View::e($barrio["geojson"] ?? "") ?></textarea>
      <small class="text-muted">
        Formatos aceptados: Polygon, MultiPolygon, Feature, FeatureCollection.
        El sistema normalizará automáticamente a geometría pura.
      </small>
    </div>
  </div>
  
  <button class="btn btn-primary mt-3"><?= !empty($barrio["id"]) ? "💾 Actualizar" : "➕ Crear" ?></button>
  <a href="<?= APP_URL ?>barrios" class="btn btn-secondary mt-3">Cancelar</a>
</form>

<?php if (!empty($barrio["id"])): ?>
<div class="card bg-white p-3">
  <h5>📤 Importar archivo GeoJSON</h5>
  <p class="text-muted">Subí un archivo .geojson o .json oficial de la Municipalidad.</p>
  <form method="post" action="<?= APP_URL ?>barrios/upload_geojson" enctype="multipart/form-data" class="row g-2">
    <?= Csrf::field() ?>
    <input type="hidden" name="id" value="<?= $barrio["id"] ?>">
    <div class="col-md-8">
      <input type="file" name="geojson_file" class="form-control" accept=".geojson,.json" required>
    </div>
    <div class="col-md-4">
      <button class="btn btn-success w-100">📤 Importar archivo</button>
    </div>
  </form>
  
  <?php if (!empty($barrio["geojson"])): ?>
  <hr>
  <div class="form-check mt-2">
    <p class="text-muted">Si querés quitar el polígono actual, editá el barrio y dejá el campo GeoJSON vacío.</p>
  </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<div class="card bg-light p-3 mt-3">
  <h6>📋 Ejemplo de GeoJSON válido (Polygon):</h6>
  <pre class="bg-white p-2 border" style="font-size:11px;max-height:200px;overflow:auto">{
  "type": "Polygon",
  "coordinates": [
    [
      [-64.4020, -31.1460],
      [-64.4000, -31.1460],
      [-64.4000, -31.1480],
      [-64.4020, -31.1480],
      [-64.4020, -31.1460]
    ]
  ]
}</pre>
</div>