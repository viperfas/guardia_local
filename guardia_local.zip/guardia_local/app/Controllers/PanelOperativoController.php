<?php
declare(strict_types=1);
class PanelOperativoController extends Controller {
    public function index(): void {
        $db = Database::connection();
        $pendientes = $db->query("SELECT i.*, c.nombre AS categoria, b.nombre AS barrio
            FROM incidentes i
            LEFT JOIN categorias_incidentes c ON c.id=i.id_categoria
            LEFT JOIN barrios b ON b.id=i.id_barrio
            WHERE i.estado IN ('Recibido','Pendiente de evaluación')
            ORDER BY FIELD(i.prioridad,'Crítica','Alta','Media','Baja'), i.fecha DESC, i.hora DESC")->fetchAll();
        $activas = $db->query("SELECT iv.*, inc.descripcion AS incidente_desc, inc.prioridad AS inc_prioridad,
            m.numero_interno AS movil_numero, e.nombre AS equipo_nombre,
            TIMESTAMPDIFF(MINUTE, iv.fecha_hora_despacho, NOW()) AS minutos_transcurridos
            FROM intervenciones iv
            LEFT JOIN incidentes inc ON inc.id = iv.id_incidente
            LEFT JOIN moviles m ON m.id = iv.id_movil
            LEFT JOIN equipos e ON e.id = iv.id_equipo
            WHERE iv.estado IN ('Asignado','En intervención')
            ORDER BY FIELD(inc.prioridad,'Crítica','Alta','Media','Baja'), iv.fecha_hora_despacho")->fetchAll();
        $moviles = $db->query("SELECT * FROM moviles ORDER BY numero_interno")->fetchAll();
        $recientes = $db->query("SELECT iv.*, inc.descripcion AS incidente_desc, m.numero_interno AS movil_numero
            FROM intervenciones iv
            LEFT JOIN incidentes inc ON inc.id = iv.id_incidente
            LEFT JOIN moviles m ON m.id = iv.id_movil
            WHERE iv.estado IN ('Resuelto','Cerrado')
            ORDER BY iv.hora_finalizacion DESC LIMIT 10")->fetchAll();
        $this->view("panel/index", ["pendientes"=>$pendientes,"activas"=>$activas,"moviles"=>$moviles,"recientes"=>$recientes]);
    }
}
