<h3><?= $usuario && isset($usuario["id"]) ? "Editar usuario" : "Nuevo usuario" ?></h3>
<?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e) echo "<li>".View::e($e)."</li>"; ?></ul></div><?php endif; ?>
<form method="post" action="<?= APP_URL ?>usuarios/<?= $usuario && isset($usuario["id"]) ? "actualizar" : "guardar" ?>" class="bg-white p-3 rounded">
  <?= Csrf::field() ?>
  <?php if ($usuario && isset($usuario["id"])): ?><input type="hidden" name="id" value="<?= $usuario["id"] ?>"><?php endif; ?>
  <div class="row g-2">
    <div class="col-md-4"><label>Usuario</label>
      <input name="usuario" class="form-control" required value="<?= View::e($usuario["usuario"]??"") ?>" <?= $usuario && isset($usuario["id"])?"readonly":"" ?>>
    </div>
    <div class="col-md-4"><label>Nombre completo</label><input name="nombre_completo" class="form-control" required value="<?= View::e($usuario["nombre_completo"]??"") ?>"></div>
    <div class="col-md-4"><label>Rol</label>
      <select name="id_rol" class="form-select" required>
        <?php foreach ($roles as $r): ?><option value="<?= $r["id"] ?>" <?= ($usuario["id_rol"]??"")==$r["id"]?"selected":"" ?>><?= View::e($r["nombre"]) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4"><label>Contraseña <?= $usuario && isset($usuario["id"])?"(dejar vacío para no cambiar)":"" ?></label>
      <input type="password" name="password" class="form-control" <?= $usuario && isset($usuario["id"])?"":"required" ?>>
    </div>
    <?php if ($usuario && isset($usuario["id"])): ?>
      <div class="col-md-4"><label>Estado</label>
        <div class="form-check mt-2">
          <input type="checkbox" name="activo" class="form-check-input" value="1" <?= $usuario["activo"]?"checked":"" ?>>
          <label class="form-check-label">Activo</label>
        </div>
      </div>
    <?php endif; ?>
    <div class="col-12">
      <label class="form-label"><strong>Permisos</strong></label>
      <div class="row">
        <?php
        $db = \Database::connection();
        $todosPermisos = $db->query("SELECT * FROM permisos ORDER BY codigo")->fetchAll();
        foreach ($todosPermisos as $p): ?>
          <div class="col-md-3">
            <div class="form-check">
              <input type="checkbox" name="permisos[]" class="form-check-input" value="<?= $p["id"] ?>" <?= in_array($p["codigo"],$permisos)?"checked":"" ?>>
              <label class="form-check-label small"><?= View::e($p["codigo"]) ?></label>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
  <button class="btn btn-primary mt-3">Guardar</button>
  <a href="<?= APP_URL ?>usuarios" class="btn btn-secondary mt-3">Cancelar</a>
</form>
