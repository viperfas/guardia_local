<h3 class="mb-4">🤖 Informes con Inteligencia Artificial</h3>

<?php if (!empty($ia_disponible)): ?>
<div class="alert alert-success">
  ✅ <strong>IA activa:</strong> <?= View::e($ia_info ?? 'Configuración OK') ?><br>
  <small>Los datos enviados son anonimizados automáticamente (requisito 21.B).</small>
</div>
<?php else: ?>
<div class="alert alert-warning">
  ⚠️ <strong>IA no configurada</strong><br>
  El sistema generará análisis estadísticos locales. Para habilitar IA avanzada, configurá la API en 
  <a href="<?= APP_URL ?>configuracion">⚙️ Configuración</a>.<br>
  <small>Los datos enviados a la IA son anonimizados automáticamente (requisito 21.B).</small>
</div>
<?php endif; ?>

<div class="card bg-white p-4 mb-4">
  <h5>📊 Generar Informe</h5>
  <form method="post" action="<?= APP_URL ?>informes_ia/generar">
    <?= Csrf::field() ?>
    
    <div class="row g-3">
      <div class="col-md-6">
        <label>Fecha desde</label>
        <input type="date" name="desde" class="form-control" 
               value="<?= date('Y-m-01', strtotime('-1 month')) ?>" required>
      </div>
      <div class="col-md-6">
        <label>Fecha hasta</label>
        <input type="date" name="hasta" class="form-control" 
               value="<?= date('Y-m-d') ?>" required>
      </div>
      
      <div class="col-md-6">
        <label>Tipo de análisis</label>
        <select name="tipo" class="form-select">
          <option value="general">📋 Resumen ejecutivo general</option>
          <option value="barrios">🏘️ Análisis por barrios</option>
          <option value="temporal">📈 Tendencias temporales</option>
          <option value="categorias">📂 Análisis por categorías</option>
          <option value="predictivo">🔮 Análisis predictivo</option>
        </select>
      </div>
      
      <div class="col-md-6">
        <label>Barrio (opcional)</label>
        <select name="id_barrio" class="form-select">
          <option value="0">Todos los barrios</option>
          <?php foreach ($barrios as $b): ?>
            <option value="<?= $b['id'] ?>"><?= View::e($b['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      
      <div class="col-md-6">
        <label>Categoría (opcional)</label>
        <select name="id_categoria" class="form-select">
          <option value="0">Todas las categorías</option>
          <?php foreach ($categorias as $c): ?>
            <option value="<?= $c['id'] ?>"><?= View::e($c['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    
    <button type="submit" class="btn btn-primary btn-lg mt-4">
      🤖 Generar Informe
    </button>
  </form>
</div>

<div class="card bg-white p-4">
  <h5>💬 Chat con la IA</h5>
  <p class="text-muted">Hacé preguntas específicas sobre incidentes, estadísticas o tendencias.</p>
  <a href="<?= APP_URL ?>informes_ia/chat" class="btn btn-outline-primary">
    💬 Abrir Chat Conversacional
  </a>
</div>