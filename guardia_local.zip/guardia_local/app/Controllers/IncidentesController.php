<?php
declare(strict_types=1);
class IncidentesController extends Controller {
    public function index(): void {
        $db = Database::connection();
        $incidentes = $db->query("SELECT i.*, c.nombre AS categoria, b.nombre AS barrio
            FROM incidentes i
            LEFT JOIN categorias_incidentes c ON c.id=i.id_categoria
            LEFT JOIN barrios b ON b.id=i.id_barrio
            ORDER BY i.fecha DESC, i.hora DESC LIMIT 200")->fetchAll();
        $this->view('incidentes/index', ['incidentes'=>$incidentes]);
    }
    public function create(): void {
        $db = Database::connection();
        $categorias = $db->query("SELECT id, nombre FROM categorias_incidentes ORDER BY nombre")->fetchAll();
        $barrios = $db->query("SELECT id, nombre FROM barrios ORDER BY nombre")->fetchAll();
        $vecinos = $db->query("SELECT id, nombre, apellido, dni FROM vecinos WHERE activo=1 ORDER BY apellido LIMIT 500")->fetchAll();
        $this->view('incidentes/form', ['categorias'=>$categorias,'barrios'=>$barrios,'vecinos'=>$vecinos,'incidente'=>null]);
    }
    public function store(): void {
        $this->requirePost();
        $d = $_POST;
        $db = Database::connection();
        $stmt = $db->prepare("INSERT INTO incidentes
            (fecha, hora, id_vecino, telefono_informante, id_operador, id_categoria,
             descripcion, id_barrio, direccion, referencia, latitud, longitud, prioridad, estado)
            VALUES (CURDATE(), CURTIME(), NULLIF(?,0), ?, ?, NULLIF(?,0), ?, NULLIF(?,0), ?, ?, ?, ?, ?, 'Recibido')");
        $stmt->execute([
            $d['id_vecino']??0, $d['telefono_informante']??null, $_SESSION['user_id'],
            $d['id_categoria']??0, $d['descripcion']??'', $d['id_barrio']??0,
            $d['direccion']??'', $d['referencia']??'',
            $d['latitud']?:null, $d['longitud']?:null,
            $d['prioridad']??'Media'
        ]);
        Audit::log('alta_incidente','incidentes',(string)$db->lastInsertId());
        $this->redirect('incidentes');
    }
    public function edit(): void {
        $id = (int)($_GET['id']??0);
        $db = Database::connection();
        $stmt = $db->prepare("SELECT * FROM incidentes WHERE id=?");
        $stmt->execute([$id]);
        $incidente = $stmt->fetch();
        if (!$incidente) { $this->redirect('incidentes'); return; }
        $categorias = $db->query("SELECT id, nombre FROM categorias_incidentes ORDER BY nombre")->fetchAll();
        $barrios = $db->query("SELECT id, nombre FROM barrios ORDER BY nombre")->fetchAll();
        $vecinos = $db->query("SELECT id, nombre, apellido, dni FROM vecinos WHERE activo=1 ORDER BY apellido LIMIT 500")->fetchAll();
        $this->view('incidentes/form', ['categorias'=>$categorias,'barrios'=>$barrios,'vecinos'=>$vecinos,'incidente'=>$incidente]);
    }
    public function update(): void {
        $this->requirePost();
        $d = $_POST;
        $id = (int)$d['id'];
        $db = Database::connection();
        $stmt = $db->prepare("UPDATE incidentes SET
            id_vecino=NULLIF(?,0), telefono_informante=?, id_categoria=NULLIF(?,0),
            descripcion=?, id_barrio=NULLIF(?,0), direccion=?, referencia=?,
            latitud=?, longitud=?, prioridad=?, estado=?, observaciones=?
            WHERE id=?");
        $stmt->execute([
            $d['id_vecino']??0, $d['telefono_informante']??null,
            $d['id_categoria']??0, $d['descripcion']??'', $d['id_barrio']??0,
            $d['direccion']??'', $d['referencia']??'',
            $d['latitud']?:null, $d['longitud']?:null,
            $d['prioridad']??'Media', $d['estado']??'Recibido',
            $d['observaciones']??'', $id
        ]);
        Audit::log('edit_incidente','incidentes',(string)$id);
        $this->redirect('incidentes');
    }
    public function delete(): void {
        $this->requirePost();
        $id = (int)($_POST['id']??0);
        $db = Database::connection();
        // Verificar si tiene intervenciones asociadas
        $tiene = $db->prepare("SELECT COUNT(*) FROM intervenciones WHERE id_incidente=?");
        $tiene->execute([$id]);
        if ($tiene->fetchColumn() > 0) {
            $_SESSION['error'] = "No se puede eliminar: tiene intervenciones asociadas";
            $this->redirect('incidentes');
            return;
        }
        $db->prepare("DELETE FROM incidentes WHERE id=?")->execute([$id]);
        Audit::log('delete_incidente','incidentes',(string)$id);
        $this->redirect('incidentes');
    }
}