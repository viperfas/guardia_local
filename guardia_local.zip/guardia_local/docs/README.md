# Sistema Integral de Guardia Local
## Municipalidad de Villa Giardino - Córdoba - Argentina

### Instalación
1. Abrir: http://localhost/guardia_local/public/install.php
2. Completar datos de MySQL
3. Usuario: admin / Contraseña: Admin2026!
