<?php
declare(strict_types=1);
date_default_timezone_set("America/Argentina/Cordoba");

define("ROOT_PATH", dirname(__DIR__) . DIRECTORY_SEPARATOR);
define("CONFIG_PATH", ROOT_PATH . "config" . DIRECTORY_SEPARATOR);

$step = $_GET["step"] ?? "requirements";
$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && $step === "configure") {
    $host = trim($_POST["db_host"] ?? "localhost");
    $port = trim($_POST["db_port"] ?? "3306");
    $name = trim($_POST["db_name"] ?? "guardia_local");
    $user = trim($_POST["db_user"] ?? "root");
    $pass = $_POST["db_pass"] ?? "";

    try {
        $pdo = new PDO("mysql:host=$host;port=$port;charset=utf8mb4", $user, $pass,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `$name`");

        $sql = file_get_contents(ROOT_PATH . "database/schema.sql");
        $pdo->exec($sql);

        $seed = file_get_contents(ROOT_PATH . "database/seed.sql");
        $pdo->exec($seed);

        $hash = password_hash("Admin2026!", PASSWORD_BCRYPT);
        $pdo->prepare("UPDATE usuarios SET password=? WHERE usuario='admin'")->execute([$hash]);

        $config  = "<?php\nreturn [\n";
        $config .= "    'host' => " . var_export($host, true) . ",\n";
        $config .= "    'port' => " . var_export($port, true) . ",\n";
        $config .= "    'dbname' => " . var_export($name, true) . ",\n";
        $config .= "    'username' => " . var_export($user, true) . ",\n";
        $config .= "    'password' => " . var_export($pass, true) . ",\n";
        $config .= "    'charset' => 'utf8mb4',\n];\n";
        file_put_contents(CONFIG_PATH . "database.php", $config);

        $success = "✅ Instalación completada.<br>Usuario: <strong>admin</strong> / Contraseña: <strong>Admin2026!</strong><br>
                    <a href='index.php' class='btn btn-primary mt-2'>Ingresar al sistema</a>";
        $step = "done";
    } catch (Throwable $e) {
        $error = "❌ Error: " . htmlspecialchars($e->getMessage());
    }
}
?>
<!DOCTYPE html><html lang="es"><head><meta charset="utf-8">
<title>Instalación — Guardia Local</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body class="bg-light"><div class="container py-5"><div class="row justify-content-center"><div class="col-md-8">
<div class="card shadow">
  <div class="card-header bg-primary text-white">
    <h4 class="mb-0">Instalación — Sistema Integral de Guardia Local</h4>
    <small>Municipalidad de Villa Giardino – Córdoba</small>
  </div>
  <div class="card-body">
<?php if ($step === "requirements"): ?>
  <h5>1. Verificación de requisitos</h5>
  <table class="table">
    <tr><td>PHP >= 8.1</td><td><?= version_compare(PHP_VERSION,"8.1.0",">=")?"✅ ".PHP_VERSION:"❌ ".PHP_VERSION ?></td></tr>
    <tr><td>PDO MySQL</td><td><?= extension_loaded("pdo_mysql")?"✅":"❌" ?></td></tr>
    <tr><td>mbstring</td><td><?= extension_loaded("mbstring")?"✅":"❌" ?></td></tr>
    <tr><td>json</td><td><?= extension_loaded("json")?"✅":"❌" ?></td></tr>
    <tr><td>openssl</td><td><?= extension_loaded("openssl")?"✅":"❌" ?></td></tr>
    <tr><td>Escritura en /storage</td><td><?= is_writable(ROOT_PATH."storage")?"✅":"❌" ?></td></tr>
    <tr><td>Escritura en /config</td><td><?= is_writable(CONFIG_PATH)?"✅":"❌" ?></td></tr>
  </table>
  <a href="?step=configure" class="btn btn-primary">Continuar</a>

<?php elseif ($step === "configure"): ?>
  <h5>2. Configuración de base de datos</h5>
  <?php if ($error): ?><div class="alert alert-danger"><?= $error ?></div><?php endif; ?>
  <form method="post">
    <div class="mb-3"><label class="form-label">Host</label><input name="db_host" class="form-control" value="localhost" required></div>
    <div class="mb-3"><label class="form-label">Puerto</label><input name="db_port" class="form-control" value="3306" required></div>
    <div class="mb-3"><label class="form-label">Nombre de BD</label><input name="db_name" class="form-control" value="guardia_local" required></div>
    <div class="mb-3"><label class="form-label">Usuario</label><input name="db_user" class="form-control" value="root" required></div>
    <div class="mb-3"><label class="form-label">Contraseña</label><input type="password" name="db_pass" class="form-control"></div>
    <button class="btn btn-primary">Instalar</button>
  </form>

<?php elseif ($step === "done"): ?>
  <div class="alert alert-success"><?= $success ?></div>
<?php endif; ?>
  </div></div></div></div></div></body></html>
