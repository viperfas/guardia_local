<?php
$appUrl = defined('APP_URL') ? APP_URL : '/guardia_local/public/';
$e = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Editor visual de barrios</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.css">

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f6f9;
        }

        .top {
            background: #1f2d3d;
            color: white;
            padding: 12px 18px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top a {
            color: white;
            text-decoration: none;
            background: #32465c;
            padding: 7px 12px;
            border-radius: 4px;
            font-size: 14px;
        }

        .wrap {
            display: grid;
            grid-template-columns: 310px 1fr;
            gap: 12px;
            padding: 12px;
        }

        .panel {
            background: white;
            border: 1px solid #ddd;
            border-radius: 6px;
            padding: 12px;
        }

        #map {
            height: 650px;
            width: 100%;
            border: 1px solid #bbb;
            border-radius: 6px;
        }

        .barrio {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 9px;
            margin-bottom: 8px;
            cursor: pointer;
            background: #fff;
        }

        .barrio:hover {
            background: #eef5ff;
        }

        .barrio.active {
            background: #dceeff;
            border-color: #0d6efd;
        }

        .badge {
            float: right;
            padding: 2px 6px;
            border-radius: 4px;
            font-size: 12px;
        }

        .ok {
            background: #198754;
            color: white;
        }

        .pending {
            background: #ffc107;
            color: #222;
        }

        .alert {
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        .alert-info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }

        .alert-success {
            background: #d1e7dd;
            color: #0f5132;
            border: 1px solid #badbcc;
        }

        .alert-error {
            background: #f8d7da;
            color: #842029;
            border: 1px solid #f5c2c7;
        }

        .btn {
            border: 0;
            padding: 9px 12px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }

        .btn-primary {
            background: #0d6efd;
            color: white;
        }

        .btn-success {
            background: #198754;
            color: white;
        }

        .btn-danger {
            background: #dc3545;
            color: white;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn:disabled {
            opacity: .5;
            cursor: not-allowed;
        }

        textarea {
            width: 100%;
            min-height: 90px;
            font-family: Consolas, monospace;
            font-size: 12px;
        }

        input[type=text] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .small {
            font-size: 12px;
            color: #666;
        }

        .toolbar {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-top: 10px;
        }

        #estado {
            font-size: 13px;
            margin-top: 8px;
        }
    </style>
</head>
<body>

<div class="top">
    <strong>🗺️ Editor visual de barrios</strong>
    <div>
        <a href="<?= $e($appUrl) ?>barrios">Volver a barrios</a>
        <a href="<?= $e($appUrl) ?>mapa">Ver mapa territorial</a>
    </div>
</div>

<div class="wrap">
    <div>
        <div class="panel">
            <h3>Barrios</h3>

            <?php if (!empty($_SESSION['ok'])): ?>
                <div class="alert alert-success"><?= $e($_SESSION['ok']) ?></div>
                <?php unset($_SESSION['ok']); ?>
            <?php endif; ?>

            <?php if (!empty($_SESSION['error'])): ?>
                <div class="alert alert-error"><?= $e($_SESSION['error']) ?></div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <div class="alert alert-info">
                <strong>Pasos:</strong><br>
                1. Seleccioná un barrio.<br>
                2. Presioná <strong>Dibujar polígono</strong>.<br>
                3. Hacé clic en el mapa para marcar puntos.<br>
                4. Doble clic para cerrar.<br>
                5. Guardá el polígono.
            </div>

            <div id="listaBarrios" style="max-height:520px;overflow:auto">
                <?php foreach ($barrios as $b): ?>
                    <div class="barrio" data-id="<?= (int)$b['id'] ?>">
                        <strong><?= $e($b['nombre']) ?></strong>
                        <?php if (!empty($b['geojson'])): ?>
                            <span class="badge ok">✓</span>
                        <?php else: ?>
                            <span class="badge pending">Sin polígono</span>
                        <?php endif; ?>
                        <div class="small"><?= $e($b['descripcion'] ?? '') ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div>
        <div class="panel">
            <div id="map"></div>

            <div id="estado" class="alert alert-info">
                Verificando herramientas de dibujo...
            </div>

            <div class="toolbar">
                <button type="button" class="btn btn-primary" id="btnDibujar" disabled>✏️ Dibujar polígono</button>
                <button type="button" class="btn btn-danger" id="btnLimpiar" disabled>🗑️ Limpiar dibujo</button>
            </div>
        </div>

        <div class="panel" style="margin-top:12px">
            <h3>Guardar polígono</h3>

            <form method="post" action="<?= $e($appUrl) ?>barrios/guardar_poligono_visual" id="formGuardar">
                <?= class_exists('Csrf') ? Csrf::field() : '' ?>

                <input type="hidden" name="id_barrio" id="id_barrio" value="">
                <input type="hidden" name="geojson" id="geojson" value="">

                <label>Barrio seleccionado</label>
                <input type="text" id="nombreBarrio" readonly placeholder="Seleccioná un barrio de la lista">

                <br><br>

                <label>GeoJSON generado</label>
                <textarea id="geojsonPreview" readonly placeholder="Aquí aparecerá el polígono dibujado"></textarea>

                <div class="toolbar">
                    <button type="submit" class="btn btn-success" id="btnGuardar" disabled>💾 Guardar polígono</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.js"></script>

<script>
const APP_URL = <?= json_encode($appUrl) ?>;
const barrios = <?= json_encode($barrios, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

const estado = document.getElementById('estado');
const btnDibujar = document.getElementById('btnDibujar');
const btnLimpiar = document.getElementById('btnLimpiar');
const btnGuardar = document.getElementById('btnGuardar');

let selectedId = null;
let map;
let drawnItems;
let polygonDrawer = null;

function setEstado(msg, type = 'info') {
    estado.className = 'alert alert-' + (type === 'error' ? 'error' : type === 'success' ? 'success' : 'info');
    estado.innerHTML = msg;
}

if (typeof L === 'undefined') {
    setEstado('❌ Leaflet no cargó. Revisá acceso a cdnjs.cloudflare.com.', 'error');
} else if (typeof L.Draw === 'undefined') {
    setEstado('❌ Leaflet.draw no cargó. El mapa puede verse, pero no se podrá dibujar. Revisá acceso a cdnjs.cloudflare.com/ajax/libs/leaflet.draw.', 'error');
} else {
    initMap();
}

function initMap() {
    map = L.map('map').setView([-31.1470, -64.4010], 14);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
    }).addTo(map);

    drawnItems = new L.FeatureGroup();
    map.addLayer(drawnItems);

    const drawControl = new L.Control.Draw({
        edit: {
            featureGroup: drawnItems,
            remove: true
        },
        draw: {
            polygon: {
                allowIntersection: false,
                showArea: true,
                shapeOptions: {
                    color: '#d63384',
                    weight: 3,
                    fillOpacity: 0.25
                }
            },
            polyline: false,
            rectangle: false,
            circle: false,
            marker: false,
            circlemarker: false
        }
    });

    map.addControl(drawControl);

    map.on(L.Draw.Event.CREATED, function(e) {
        drawnItems.clearLayers();
        drawnItems.addLayer(e.layer);
        syncGeojson();
        setEstado('✅ Polígono dibujado. Ahora podés guardarlo.', 'success');
    });

    map.on(L.Draw.Event.EDITED, function() {
        syncGeojson();
        setEstado('✅ Polígono editado. Ahora podés guardar los cambios.', 'success');
    });

    map.on(L.Draw.Event.DELETED, function() {
        syncGeojson();
        setEstado('Polígono eliminado del editor.', 'info');
    });

    btnDibujar.disabled = false;
    btnDibujar.addEventListener('click', function() {
        if (!selectedId) {
            alert('Primero seleccioná un barrio.');
            return;
        }

        polygonDrawer = new L.Draw.Polygon(map, {
            allowIntersection: false,
            showArea: true,
            shapeOptions: {
                color: '#d63384',
                weight: 3,
                fillOpacity: 0.25
            }
        });

        polygonDrawer.enable();
        setEstado('✏️ Modo dibujo activo. Hacé clic en el mapa para marcar puntos. Doble clic para cerrar.', 'info');
    });

    btnLimpiar.addEventListener('click', function() {
        if (!confirm('¿Limpiar el dibujo actual?')) return;
        drawnItems.clearLayers();
        syncGeojson();
        setEstado('Dibujo limpiado. Podés dibujar un nuevo polígono.', 'info');
    });

    cargarPoligonosExistentes();

    setEstado('✅ Editor listo. Seleccioná un barrio y presioná “Dibujar polígono”.', 'success');

    setTimeout(() => map.invalidateSize(), 300);
}

function cargarPoligonosExistentes() {
    barrios.forEach(b => {
        if (!b.geojson) return;

        try {
            const geo = JSON.parse(b.geojson);
            const layer = L.geoJSON(geo, {
                style: {
                    color: '#1f78b1',
                    weight: 2,
                    fillOpacity: 0.12
                }
            });

            layer.bindPopup('<strong>' + b.nombre + '</strong>');
            layer.on('click', () => seleccionarBarrio(b.id));
            layer.addTo(map);
        } catch(e) {
            console.warn('GeoJSON inválido en barrio', b.nombre, e);
        }
    });
}

function seleccionarBarrio(id) {
    const barrio = barrios.find(b => Number(b.id) === Number(id));
    if (!barrio) return;

    selectedId = barrio.id;

    document.getElementById('id_barrio').value = barrio.id;
    document.getElementById('nombreBarrio').value = barrio.nombre;

    document.querySelectorAll('.barrio').forEach(el => {
        el.classList.toggle('active', Number(el.dataset.id) === Number(id));
    });

    drawnItems.clearLayers();

    if (barrio.geojson) {
        try {
            const geo = JSON.parse(barrio.geojson);
            const temp = L.geoJSON(geo);

            temp.eachLayer(layer => {
                if (layer.setStyle) {
                    layer.setStyle({
                        color: '#d63384',
                        weight: 3,
                        fillOpacity: 0.25
                    });
                }

                drawnItems.addLayer(layer);
            });

            if (drawnItems.getBounds().isValid()) {
                map.fitBounds(drawnItems.getBounds(), { padding: [30, 30] });
            }

            syncGeojson();
            setEstado('✅ Barrio seleccionado. Podés editar el polígono existente o dibujar uno nuevo.', 'success');
        } catch(e) {
            console.warn(e);
            syncGeojson();
            setEstado('⚠️ El barrio tiene un GeoJSON inválido. Dibujá un nuevo polígono.', 'error');
        }
    } else {
        syncGeojson();
        setEstado('Barrio seleccionado. No tiene polígono. Presioná “Dibujar polígono”.', 'info');
    }
}

function syncGeojson() {
    const layers = [];

    drawnItems.eachLayer(layer => {
        if (typeof layer.toGeoJSON === 'function') {
            layers.push(layer);
        }
    });

    let geometry = null;

    if (layers.length === 1) {
        const gj = layers[0].toGeoJSON();
        geometry = gj.geometry || null;
    } else if (layers.length > 1) {
        const coords = [];

        layers.forEach(layer => {
            const gj = layer.toGeoJSON();
            if (gj.geometry && gj.geometry.type === 'Polygon') {
                coords.push(gj.geometry.coordinates);
            }
        });

        if (coords.length > 0) {
            geometry = {
                type: 'MultiPolygon',
                coordinates: coords
            };
        }
    }

    const json = geometry ? JSON.stringify(geometry) : '';

    document.getElementById('geojson').value = json;
    document.getElementById('geojsonPreview').value = json ? JSON.stringify(geometry, null, 2) : '';

    btnGuardar.disabled = !(selectedId && json);
    btnLimpiar.disabled = !json;
}

document.querySelectorAll('.barrio').forEach(el => {
    el.addEventListener('click', () => seleccionarBarrio(el.dataset.id));
});

document.getElementById('formGuardar').addEventListener('submit', function(e) {
    if (!document.getElementById('id_barrio').value) {
        e.preventDefault();
        alert('Seleccioná un barrio.');
        return false;
    }

    if (!document.getElementById('geojson').value) {
        e.preventDefault();
        alert('Dibujá un polígono antes de guardar.');
        return false;
    }

    return confirm('¿Guardar este polígono para el barrio seleccionado?');
});
</script>

</body>
</html>