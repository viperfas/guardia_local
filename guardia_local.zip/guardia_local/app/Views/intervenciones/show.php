<div class="d-flex justify-content-between mb-3">
  <h3>Intervención #<?= (int)$int["id"] ?></h3>
  <a href="<?= APP_URL ?>intervenciones" class="btn btn-outline-secondary">← Volver</a>
</div>
<div class="row">
  <div class="col-md-6">
    <div class="card bg-white p-3 mb-3">
      <h5>Información general</h5>
      <p><strong>Estado:</strong> <span class="badge bg-info"><?= View::e($int["estado"]) ?></span></p>
      <p><strong>Despacho:</strong> <?= View::e($int["fecha_hora_despacho"]) ?></p>
      <p><strong>Salida:</strong> <?= View::e($int["hora_salida"]?:"-") ?></p>
      <p><strong>Llegada:</strong> <?= View::e($int["hora_llegada"]?:"-") ?></p>
      <p><strong>Finalización:</strong> <?= View::e($int["hora_finalizacion"]?:"-") ?></p>
      <p><strong>Móvil:</strong> <?= View::e($int["movil_numero"]?:"-") ?></p>
      <p><strong>Equipo:</strong> <?= View::e($int["equipo_nombre"]?:"-") ?></p>
      <p><strong>Operador:</strong> <?= View::e($int["operador"]?:"-") ?></p>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card bg-white p-3 mb-3">
      <h5>Incidente relacionado</h5>
      <p><strong>Prioridad:</strong> <?= View::e($int["inc_prioridad"]) ?></p>
      <p><strong>Dirección:</strong> <?= View::e($int["incidente_direccion"]?:"-") ?></p>
      <p><strong>Descripción:</strong><br><?= View::e($int["incidente_desc"]?:"") ?></p>
      <?php if ($int["resultado"]): ?>
        <hr>
        <p><strong>Resultado:</strong><br><?= View::e($int["resultado"]) ?></p>
        <p><strong>Acciones:</strong><br><?= View::e($int["acciones_realizadas"]?:"") ?></p>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php if (!in_array($int["estado"],["Resuelto","Cerrado"])): ?>
<div class="card bg-white p-3 mb-3">
  <h5>Acciones operativas</h5>
  <div class="row g-2">
    <?php if (!$int["hora_salida"]): ?>
      <div class="col-md-3">
        <form method="post" action="<?= APP_URL ?>intervenciones/marcar_salida">
          <?= Csrf::field() ?><input type="hidden" name="id" value="<?= $int["id"] ?>">
          <button class="btn btn-warning w-100">🚓 Marcar salida</button>
        </form>
      </div>
    <?php endif; ?>
    <?php if ($int["hora_salida"] && !$int["hora_llegada"]): ?>
      <div class="col-md-3">
        <form method="post" action="<?= APP_URL ?>intervenciones/marcar_llegada">
          <?= Csrf::field() ?><input type="hidden" name="id" value="<?= $int["id"] ?>">
          <button class="btn btn-primary w-100">📍 Marcar llegada</button>
        </form>
      </div>
    <?php endif; ?>
    <?php if ($int["hora_llegada"] && !$int["hora_finalizacion"]): ?>
      <div class="col-md-12">
        <form method="post" action="<?= APP_URL ?>intervenciones/cerrar" class="border p-2 rounded bg-light">
          <?= Csrf::field() ?><input type="hidden" name="id" value="<?= $int["id"] ?>">
          <?php if ($int["id_movil"]): ?><input type="hidden" name="id_movil" value="<?= $int["id_movil"] ?>"><?php endif; ?>
          <h6>Cierre de intervención</h6>
          <div class="row g-2">
            <div class="col-12"><label>Resultado</label><textarea name="resultado" class="form-control" rows="2" required></textarea></div>
            <div class="col-12"><label>Acciones realizadas</label><textarea name="acciones_realizadas" class="form-control" rows="2"></textarea></div>
            <div class="col-12"><label>Organismos externos intervinientes</label><input name="organismos_externos" class="form-control"></div>
          </div>
          <button class="btn btn-success mt-2">✅ Cerrar intervención</button>
        </form>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<div class="card bg-white p-3 mb-3">
  <h5>Agregar novedad</h5>
  <form method="post" action="<?= APP_URL ?>intervenciones/novedad" class="row g-2">
    <?= Csrf::field() ?>
    <input type="hidden" name="id_intervencion" value="<?= $int["id"] ?>">
    <div class="col-md-3">
      <select name="tipo" class="form-select">
        <option>novedad</option><option>derivacion</option><option>cambio_personal</option><option>observacion</option>
      </select>
    </div>
    <div class="col-md-7"><input name="descripcion" class="form-control" placeholder="Descripción" required></div>
    <div class="col-md-2"><button class="btn btn-outline-primary w-100">Agregar</button></div>
  </form>
</div>

<div class="card bg-white p-3">
  <h5>Cronología de novedades</h5>
  <ul class="list-group">
    <?php foreach ($novedades as $n): ?>
      <li class="list-group-item">
        <small class="text-muted"><?= View::e($n["fecha_hora"]) ?></small>
        <strong>[<?= View::e($n["tipo"]) ?>]</strong>
        <?= View::e($n["descripcion"]?:"") ?>
        <small class="text-muted">— <?= View::e($n["operador"]?:"sistema") ?></small>
      </li>
    <?php endforeach; ?>
  </ul>
  <?php if ($personal): ?>
    <h6 class="mt-3">Personal interviniente</h6>
    <ul>
      <?php foreach ($personal as $p): ?><li><?= View::e($p["nombre_completo"]) ?></li><?php endforeach; ?>
    </ul>
  <?php endif; ?>
</div>
