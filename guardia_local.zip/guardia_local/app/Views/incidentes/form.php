<h3><?= !empty($incidente['id']) ? 'Editar incidente' : 'Nuevo incidente' ?></h3>
<form method="post" action="<?= APP_URL ?>incidentes/<?= !empty($incidente['id']) ? 'actualizar' : 'guardar' ?>" class="bg-white p-3 rounded">
  <?= Csrf::field() ?>
  <?php if (!empty($incidente['id'])): ?><input type="hidden" name="id" value="<?= $incidente['id'] ?>"><?php endif; ?>
  <div class="row g-2">
    <div class="col-md-4"><label>Vecino informante</label>
      <select name="id_vecino" class="form-select">
        <option value="">- Anónimo -</option>
        <?php foreach ($vecinos as $v): ?><option value="<?= $v['id'] ?>" <?= ($incidente['id_vecino']??'')==$v['id']?'selected':'' ?>><?= View::e($v['apellido'].' '.$v['nombre']) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4"><label>Teléfono informante</label><input name="telefono_informante" class="form-control" value="<?= View::e($incidente['telefono_informante']??'') ?>"></div>
    <div class="col-md-4"><label>Categoría</label>
      <select name="id_categoria" class="form-select" required>
        <?php foreach ($categorias as $c): ?><option value="<?= $c['id'] ?>" <?= ($incidente['id_categoria']??'')==$c['id']?'selected':'' ?>><?= View::e($c['nombre']) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4"><label>Barrio</label>
      <select name="id_barrio" class="form-select">
        <option value="">-</option>
        <?php foreach ($barrios as $b): ?><option value="<?= $b['id'] ?>" <?= ($incidente['id_barrio']??'')==$b['id']?'selected':'' ?>><?= View::e($b['nombre']) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4"><label>Prioridad</label>
      <select name="prioridad" class="form-select">
        <?php foreach (['Baja','Media','Alta','Crítica'] as $p): ?>
          <option <?= ($incidente['prioridad']??'Alta')==$p?'selected':'' ?>><?= $p ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <?php if (!empty($incidente['id'])): ?>
    <div class="col-md-4"><label>Estado</label>
      <select name="estado" class="form-select">
        <?php foreach (['Recibido','Pendiente de evaluación','Asignado','En intervención','Derivado','Resuelto','Cerrado'] as $e): ?>
          <option <?= ($incidente['estado']??'Recibido')==$e?'selected':'' ?>><?= $e ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <?php endif; ?>
    <div class="col-md-6"><label>Dirección</label><input name="direccion" class="form-control" value="<?= View::e($incidente['direccion']??'') ?>"></div>
    <div class="col-md-6"><label>Referencia</label><input name="referencia" class="form-control" value="<?= View::e($incidente['referencia']??'') ?>"></div>
    <div class="col-12"><label>Descripción</label><textarea name="descripcion" class="form-control" rows="3" required><?= View::e($incidente['descripcion']??'') ?></textarea></div>
    <div class="col-md-6"><label>Latitud</label><input name="latitud" step="any" class="form-control" value="<?= View::e($incidente['latitud']??'') ?>"></div>
    <div class="col-md-6"><label>Longitud</label><input name="longitud" step="any" class="form-control" value="<?= View::e($incidente['longitud']??'') ?>"></div>
    <?php if (!empty($incidente['id'])): ?>
    <div class="col-12"><label>Observaciones</label><textarea name="observaciones" class="form-control"><?= View::e($incidente['observaciones']??'') ?></textarea></div>
    <?php endif; ?>
  </div>
  <button class="btn btn-primary mt-3"><?= !empty($incidente['id']) ? '💾 Actualizar' : '🚨 Registrar' ?></button>
  <a href="<?= APP_URL ?>incidentes" class="btn btn-secondary mt-3">Cancelar</a>
</form>