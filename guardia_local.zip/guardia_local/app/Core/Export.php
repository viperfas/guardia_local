<?php
declare(strict_types=1);
class Export {
    public static function csv(string $filename, array $rows, array $headers = []): void {
        if (empty($rows)) { echo "No hay datos"; return; }
        if (empty($headers)) $headers = array_keys($rows[0]);
        Audit::log("exportacion_csv","reportes",$filename." (".count($rows)." registros)");
        header("Content-Type: text/csv; charset=utf-8");
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        $out = fopen("php://output", "w");
        fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));
        fputcsv($out, $headers);
        foreach ($rows as $row) fputcsv($out, array_values($row));
        fclose($out);
        exit;
    }
}