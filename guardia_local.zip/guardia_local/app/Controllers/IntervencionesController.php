<?php
declare(strict_types=1);

class IntervencionesController extends Controller
{
    public function index(): void
    {
        $db = Database::connection();

        $intervenciones = $db->query("
            SELECT 
                i.*,
                inc.descripcion AS incidente_desc,
                inc.prioridad AS inc_prioridad,
                m.numero_interno AS movil_numero,
                e.nombre AS equipo_nombre,
                u.nombre_completo AS operador
            FROM intervenciones i
            LEFT JOIN incidentes inc ON inc.id = i.id_incidente
            LEFT JOIN moviles m ON m.id = i.id_movil
            LEFT JOIN equipos e ON e.id = i.id_equipo
            LEFT JOIN usuarios u ON u.id = i.id_operador_despacho
            ORDER BY i.fecha_hora_despacho DESC
            LIMIT 200
        ")->fetchAll();

        $this->view("intervenciones/index", [
            "intervenciones" => $intervenciones
        ]);
    }

    public function dispatch(): void
    {
        $idIncidente = (int)($_GET["incidente"] ?? 0);

        $db = Database::connection();

        $stmt = $db->prepare("
            SELECT 
                i.*,
                c.nombre AS categoria,
                b.nombre AS barrio
            FROM incidentes i
            LEFT JOIN categorias_incidentes c ON c.id = i.id_categoria
            LEFT JOIN barrios b ON b.id = i.id_barrio
            WHERE i.id = ?
        ");
        $stmt->execute([$idIncidente]);
        $incidente = $stmt->fetch();

        if (!$incidente) {
            $this->redirect("incidentes");
            return;
        }

        $moviles = $db->query("
            SELECT id, numero_interno
            FROM moviles
            WHERE estado = 'Disponible'
            ORDER BY numero_interno
        ")->fetchAll();

        $equipos = $db->query("
            SELECT id, nombre
            FROM equipos
            WHERE estado = 'Activo'
            ORDER BY nombre
        ")->fetchAll();

        $this->view("intervenciones/despachar", [
            "incidente" => $incidente,
            "moviles" => $moviles,
            "equipos" => $equipos
        ]);
    }

    public function saveDispatch(): void
    {
        $this->requirePost();

        $d = $_POST;
        $db = Database::connection();

        $stmt = $db->prepare("
            INSERT INTO intervenciones
            (
                id_incidente,
                prioridad,
                id_movil,
                id_equipo,
                id_operador_despacho,
                motivo,
                observaciones,
                estado
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            (int)$d["id_incidente"],
            $d["prioridad"] ?? "Media",
            !empty($d["id_movil"]) ? (int)$d["id_movil"] : null,
            !empty($d["id_equipo"]) ? (int)$d["id_equipo"] : null,
            $_SESSION["user_id"],
            $d["motivo"] ?? null,
            $d["observaciones"] ?? null,
            "Asignado"
        ]);

        $idInt = (int)$db->lastInsertId();

        if (!empty($d["id_movil"])) {
            $stmt = $db->prepare("UPDATE moviles SET estado = ? WHERE id = ?");
            $stmt->execute(["Asignado", (int)$d["id_movil"]]);
        }

        $stmt = $db->prepare("UPDATE incidentes SET estado = ? WHERE id = ?");
        $stmt->execute(["Asignado", (int)$d["id_incidente"]]);

        $stmt = $db->prepare("
            INSERT INTO intervenciones_novedades
            (
                id_intervencion,
                id_operador,
                tipo,
                descripcion
            )
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $idInt,
            $_SESSION["user_id"],
            "despacho",
            $d["motivo"] ?? "Despacho inicial"
        ]);

        Audit::log("despacho_intervencion", "intervenciones", (string)$idInt);

        $this->redirect("intervenciones/ver?id=" . $idInt);
    }

    public function show(): void
    {
        $id = (int)($_GET["id"] ?? 0);

        $db = Database::connection();

        $stmt = $db->prepare("
            SELECT 
                i.*,
                inc.descripcion AS incidente_desc,
                inc.prioridad AS inc_prioridad,
                inc.direccion AS incidente_direccion,
                inc.referencia AS incidente_referencia,
                m.numero_interno AS movil_numero,
                e.nombre AS equipo_nombre,
                u.nombre_completo AS operador
            FROM intervenciones i
            LEFT JOIN incidentes inc ON inc.id = i.id_incidente
            LEFT JOIN moviles m ON m.id = i.id_movil
            LEFT JOIN equipos e ON e.id = i.id_equipo
            LEFT JOIN usuarios u ON u.id = i.id_operador_despacho
            WHERE i.id = ?
        ");
        $stmt->execute([$id]);
        $int = $stmt->fetch();

        if (!$int) {
            $this->redirect("intervenciones");
            return;
        }

        $stmt = $db->prepare("
            SELECT 
                n.*,
                u.nombre_completo AS operador
            FROM intervenciones_novedades n
            LEFT JOIN usuarios u ON u.id = n.id_operador
            WHERE n.id_intervencion = ?
            ORDER BY n.fecha_hora ASC
        ");
        $stmt->execute([$id]);
        $novedades = $stmt->fetchAll();

        $stmt = $db->prepare("
            SELECT p.nombre_completo
            FROM intervenciones_personal ip
            INNER JOIN personal p ON p.id = ip.id_personal
            WHERE ip.id_intervencion = ?
        ");
        $stmt->execute([$id]);
        $personal = $stmt->fetchAll();

        $this->view("intervenciones/show", [
            "int" => $int,
            "novedades" => $novedades,
            "personal" => $personal
        ]);
    }

    public function edit(): void
    {
        $id = (int)($_GET["id"] ?? 0);

        $db = Database::connection();

        $stmt = $db->prepare("SELECT * FROM intervenciones WHERE id = ?");
        $stmt->execute([$id]);
        $int = $stmt->fetch();

        if (!$int) {
            $this->redirect("intervenciones");
            return;
        }

        $moviles = $db->query("
            SELECT id, numero_interno
            FROM moviles
            ORDER BY numero_interno
        ")->fetchAll();

        $equipos = $db->query("
            SELECT id, nombre
            FROM equipos
            ORDER BY nombre
        ")->fetchAll();

        $this->view("intervenciones/form_edit", [
            "int" => $int,
            "moviles" => $moviles,
            "equipos" => $equipos
        ]);
    }

    public function update(): void
    {
        $this->requirePost();

        $d = $_POST;
        $db = Database::connection();

        $stmt = $db->prepare("
            UPDATE intervenciones
            SET 
                prioridad = ?,
                id_movil = ?,
                id_equipo = ?,
                motivo = ?,
                observaciones = ?,
                estado = ?
            WHERE id = ?
        ");

        $stmt->execute([
            $d["prioridad"] ?? "Media",
            !empty($d["id_movil"]) ? (int)$d["id_movil"] : null,
            !empty($d["id_equipo"]) ? (int)$d["id_equipo"] : null,
            $d["motivo"] ?? null,
            $d["observaciones"] ?? null,
            $d["estado"] ?? "Asignado",
            (int)$d["id"]
        ]);

        Audit::log("edit_intervencion", "intervenciones", (string)$d["id"]);

        $this->redirect("intervenciones/ver?id=" . (int)$d["id"]);
    }

    public function delete(): void
    {
        $this->requirePost();

        $id = (int)($_POST["id"] ?? 0);

        $db = Database::connection();

        $stmt = $db->prepare("DELETE FROM intervenciones_novedades WHERE id_intervencion = ?");
        $stmt->execute([$id]);

        $stmt = $db->prepare("DELETE FROM intervenciones_personal WHERE id_intervencion = ?");
        $stmt->execute([$id]);

        $stmt = $db->prepare("DELETE FROM intervenciones WHERE id = ?");
        $stmt->execute([$id]);

        Audit::log("delete_intervencion", "intervenciones", (string)$id);

        $this->redirect("intervenciones");
    }

    public function addNov(): void
    {
        $this->requirePost();

        $db = Database::connection();

        $stmt = $db->prepare("
            INSERT INTO intervenciones_novedades
            (
                id_intervencion,
                id_operador,
                tipo,
                descripcion
            )
            VALUES (?, ?, ?, ?)
        ");

        $stmt->execute([
            (int)$_POST["id_intervencion"],
            $_SESSION["user_id"],
            $_POST["tipo"] ?? "novedad",
            $_POST["descripcion"] ?? ""
        ]);

        Audit::log("novedad_intervencion", "intervenciones", (string)$_POST["id_intervencion"]);

        $this->redirect("intervenciones/ver?id=" . (int)$_POST["id_intervencion"]);
    }

    public function markOut(): void
    {
        $this->requirePost();

        $id = (int)($_POST["id"] ?? 0);

        $db = Database::connection();

        $stmt = $db->prepare("
            UPDATE intervenciones
            SET 
                estado = ?,
                hora_salida = IFNULL(hora_salida, NOW())
            WHERE id = ?
        ");
        $stmt->execute(["En intervención", $id]);

        $stmt = $db->prepare("
            SELECT id_movil
            FROM intervenciones
            WHERE id = ?
        ");
        $stmt->execute([$id]);
        $idMovil = $stmt->fetchColumn();

        if ($idMovil) {
            $stmt = $db->prepare("UPDATE moviles SET estado = ? WHERE id = ?");
            $stmt->execute(["En servicio", (int)$idMovil]);
        }

        $stmt = $db->prepare("
            INSERT INTO intervenciones_novedades
            (
                id_intervencion,
                id_operador,
                tipo,
                descripcion
            )
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $id,
            $_SESSION["user_id"],
            "salida",
            "Móvil en camino"
        ]);

        Audit::log("salida_intervencion", "intervenciones", (string)$id);

        $this->redirect("intervenciones/ver?id=" . $id);
    }

    public function markArrival(): void
    {
        $this->requirePost();

        $id = (int)($_POST["id"] ?? 0);

        $db = Database::connection();

        $stmt = $db->prepare("
            UPDATE intervenciones
            SET hora_llegada = IFNULL(hora_llegada, NOW())
            WHERE id = ?
        ");
        $stmt->execute([$id]);

        $stmt = $db->prepare("
            INSERT INTO intervenciones_novedades
            (
                id_intervencion,
                id_operador,
                tipo,
                descripcion
            )
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $id,
            $_SESSION["user_id"],
            "llegada",
            "Personal en el lugar"
        ]);

        Audit::log("llegada_intervencion", "intervenciones", (string)$id);

        $this->redirect("intervenciones/ver?id=" . $id);
    }

    public function close(): void
    {
        $this->requirePost();

        $d = $_POST;
        $id = (int)($d["id"] ?? 0);

        $db = Database::connection();

        $stmt = $db->prepare("
            UPDATE intervenciones
            SET 
                estado = ?,
                hora_finalizacion = NOW(),
                resultado = ?,
                acciones_realizadas = ?,
                organismos_externos = ?
            WHERE id = ?
        ");

        $stmt->execute([
            "Resuelto",
            $d["resultado"] ?? null,
            $d["acciones_realizadas"] ?? null,
            $d["organismos_externos"] ?? null,
            $id
        ]);

        $stmt = $db->prepare("
            SELECT id_incidente, id_movil
            FROM intervenciones
            WHERE id = ?
        ");
        $stmt->execute([$id]);
        $row = $stmt->fetch();

        if ($row && !empty($row["id_movil"])) {
            $stmt = $db->prepare("UPDATE moviles SET estado = ? WHERE id = ?");
            $stmt->execute(["Disponible", (int)$row["id_movil"]]);
        }

        if ($row && !empty($row["id_incidente"])) {
            $stmt = $db->prepare("UPDATE incidentes SET estado = ? WHERE id = ?");
            $stmt->execute(["Resuelto", (int)$row["id_incidente"]]);
        }

        $stmt = $db->prepare("
            INSERT INTO intervenciones_novedades
            (
                id_intervencion,
                id_operador,
                tipo,
                descripcion
            )
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $id,
            $_SESSION["user_id"],
            "cierre",
            $d["resultado"] ?? "Intervención cerrada"
        ]);

        Audit::log("cierre_intervencion", "intervenciones", (string)$id);

        $this->redirect("intervenciones/ver?id=" . $id);
    }
}