<h3>Historial de informes IA</h3>
<table class="table table-striped bg-white">
  <thead><tr><th>Fecha</th><th>Tipo</th><th>Período</th><th>Proveedor IA</th></tr></thead>
  <tbody>
  <?php foreach ($informes as $i): ?>
    <tr>
      <td><?= View::e($i["fecha_generacion"]) ?></td>
      <td><?= View::e($i["tipo"]) ?></td>
      <td><?= View::e($i["periodo_desde"]??"") ?> a <?= View::e($i["periodo_hasta"]??"") ?></td>
      <td><?= View::e($i["proveedor_ia"]?:"-") ?></td>
    </tr>
    <tr><td colspan="4" style="background:#f9f9f9"><pre style="white-space:pre-wrap;margin:0;font-size:12px"><?= View::e($i["contenido"]??"") ?></pre></td></tr>
  <?php endforeach; ?>
  </tbody>
</table>
<a href="<?= APP_URL ?>informes_ia" class="btn btn-secondary">← Volver</a>