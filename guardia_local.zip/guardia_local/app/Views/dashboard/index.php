<h3 class="mb-4">Panel de control</h3>

<div class="row g-3 mb-4">
  <div class="col-md-2"><div class="card text-bg-primary p-3"><h6>Vecinos</h6><h3><?= (int)$stats["vecinos"] ?></h3></div></div>
  <div class="col-md-2"><div class="card text-bg-info p-3"><h6>Incidentes</h6><h3><?= (int)$stats["incidentes"] ?></h3></div></div>
  <div class="col-md-2"><div class="card text-bg-warning p-3"><h6>Pendientes</h6><h3><?= (int)$stats["pendientes"] ?></h3></div></div>
  <div class="col-md-2"><div class="card text-bg-danger p-3"><h6>Críticos</h6><h3><?= (int)$stats["criticos"] ?></h3></div></div>
  <div class="col-md-2"><div class="card text-bg-success p-3"><h6>Intervenciones</h6><h3><?= (int)$stats["intervenciones"] ?></h3></div></div>
  <div class="col-md-2"><div class="card text-bg-secondary p-3"><h6>Móviles disp.</h6><h3><?= (int)$stats["moviles_disp"] ?></h3></div></div>
</div>

<div class="row mt-4 g-2 mb-4">
  <div class="col-md-3"><a href="<?= APP_URL ?>incidentes/crear" class="btn btn-danger btn-lg w-100">🚨 NUEVO INCIDENTE</a></div>
  <div class="col-md-3"><a href="<?= APP_URL ?>panel_operativo" class="btn btn-warning btn-lg w-100">📡 PANEL OPERATIVO</a></div>
  <div class="col-md-3"><a href="<?= APP_URL ?>vecinos/crear" class="btn btn-primary btn-lg w-100">➕ NUEVO VECINO</a></div>
  <div class="col-md-3"><a href="<?= APP_URL ?>estadisticas" class="btn btn-info btn-lg w-100">📊 ESTADÍSTICAS</a></div>
</div>

<div class="row g-3">
  <div class="col-md-6">
    <div class="card bg-white p-3">
      <h5>📍 Incidentes por barrio (últimos 30 días)</h5>
      <canvas id="dashBarrios" height="200"></canvas>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card bg-white p-3">
      <h5>📋 Categorías más frecuentes</h5>
      <canvas id="dashCategorias" height="200"></canvas>
    </div>
  </div>
</div>

<script>
// Dashboard: incidentes por barrio
fetch("<?= APP_URL ?>api/stats/barrios?desde=<?= date("Y-m-d", strtotime("-30 days")) ?>&hasta=<?= date("Y-m-d") ?>")
  .then(r => r.json())
  .then(data => {
    const top5 = data.slice(0, 5);
    const ctx = document.getElementById("dashBarrios");
    new Chart(ctx, {
      type: "bar",
      data: {
        labels: top5.map(d => d.nombre),
        datasets: [{
          label: "Incidentes",
          data: top5.map(d => d.total),
          backgroundColor: "rgba(54, 162, 235, 0.6)"
        }]
      },
      options: {
        responsive: true,
        indexAxis: "y",
        plugins: { legend: { display: false } }
      }
    });
  });

// Dashboard: categorías
fetch("<?= APP_URL ?>api/stats/categorias?desde=<?= date("Y-m-d", strtotime("-30 days")) ?>&hasta=<?= date("Y-m-d") ?>")
  .then(r => r.json())
  .then(data => {
    const top5 = data.slice(0, 5);
    const ctx = document.getElementById("dashCategorias");
    new Chart(ctx, {
      type: "doughnut",
      data: {
        labels: top5.map(d => d.nombre),
        datasets: [{
          data: top5.map(d => d.total),
          backgroundColor: top5.map(d => d.color || "#6c757d")
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: "right" } }
      }
    });
  });
</script>
