<div class="d-flex justify-content-between mb-3">
  <h3>📄 Informe Generado</h3>
  <div>
    <a href="<?= APP_URL ?>informes_ia" class="btn btn-outline-secondary">← Nuevo informe</a>
    <button onclick="window.print()" class="btn btn-outline-primary">🖨️ Imprimir</button>
  </div>
</div>

<div class="card bg-white p-4 mb-3">
  <div class="row">
    <div class="col-md-4">
      <strong>📅 Período:</strong><br>
      <?= View::e($desde) ?> a <?= View::e($hasta) ?>
    </div>
    <div class="col-md-4">
      <strong>📊 Tipo:</strong><br>
      <?php
      $tipos = [
        'general' => 'Resumen ejecutivo',
        'barrios' => 'Análisis por barrios',
        'temporal' => 'Tendencias temporales',
        'categorias' => 'Análisis por categorías',
        'predictivo' => 'Análisis predictivo'
      ];
      echo View::e($tipos[$tipo] ?? ucfirst($tipo));
      ?>
    </div>
    <div class="col-md-4">
      <strong>🤖 Generado con:</strong><br>
      <?php if (!empty($usado_ia)): ?>
        <span class="badge bg-success">✅ IA (Ollama)</span>
      <?php else: ?>
        <span class="badge bg-warning text-dark">📊 Análisis local</span>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="card bg-white p-4">
  <h5>📋 Contenido del Informe</h5>
  <hr>
  <div class="informe-contenido">
    <?php
    // Convertir Markdown básico a HTML
    $texto = $informe ?? '';
    
    // Títulos
    $texto = preg_replace('/^### (.*$)/m', '<h5>$1</h5>', $texto);
    $texto = preg_replace('/^## (.*$)/m', '<h4>$1</h4>', $texto);
    $texto = preg_replace('/^# (.*$)/m', '<h3>$1</h3>', $texto);
    
    // Negritas
    $texto = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $texto);
    
    // Itálicas
    $texto = preg_replace('/\*(.*?)\*/', '<em>$1</em>', $texto);
    
    // Listas con viñetas
    $texto = preg_replace('/^\* (.*$)/m', '<li>$1</li>', $texto);
    $texto = preg_replace('/^- (.*$)/m', '<li>$1</li>', $texto);
    $texto = preg_replace('/^• (.*$)/m', '<li>$1</li>', $texto);
    
    // Listas numeradas
    $texto = preg_replace('/^\d+\. (.*$)/m', '<li>$1</li>', $texto);
    
    // Saltos de línea
    $texto = nl2br($texto);
    
    echo $texto;
    ?>
  </div>
</div>

<?php if (!empty($datos)): ?>
<div class="card bg-white p-4 mt-3">
  <h5>📈 Datos estadísticos utilizados</h5>
  <div class="row">
    <div class="col-md-3">
      <div class="border rounded p-3 text-center">
        <h2 class="text-primary"><?= (int)($datos['total'] ?? 0) ?></h2>
        <small>Total incidentes</small>
      </div>
    </div>
    <div class="col-md-3">
      <div class="border rounded p-3 text-center">
        <h2 class="text-danger"><?= (int)($datos['criticos'] ?? 0) ?></h2>
        <small>Críticos</small>
      </div>
    </div>
    <div class="col-md-3">
      <div class="border rounded p-3 text-center">
        <h2 class="text-info"><?= View::e($datos['barrio_top'] ?? '-') ?></h2>
        <small>Barrio con más incidentes</small>
      </div>
    </div>
    <div class="col-md-3">
      <div class="border rounded p-3 text-center">
        <h2 class="text-success"><?= count($datos['por_categoria'] ?? []) ?></h2>
        <small>Categorías</small>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<style>
.informe-contenido {
  line-height: 1.7;
  font-size: 15px;
}
.informe-contenido h3, .informe-contenido h4, .informe-contenido h5 {
  margin-top: 20px;
  color: #1f2d3d;
}
.informe-contenido li {
  margin-bottom: 5px;
}
@media print {
  .btn, .d-flex { display: none !important; }
}
</style>