<h3>Mi perfil</h3>
<?php if (!empty($_SESSION["perfil_error"])): ?><div class="alert alert-danger"><?= $_SESSION["perfil_error"] ?></div><?php unset($_SESSION["perfil_error"]); endif; ?>
<?php if (!empty($_SESSION["perfil_ok"])): ?><div class="alert alert-success"><?= $_SESSION["perfil_ok"] ?></div><?php unset($_SESSION["perfil_ok"]); endif; ?>
<div class="row">
  <div class="col-md-6">
    <div class="card bg-white p-3">
      <h5>Datos de la cuenta</h5>
      <p><strong>Usuario:</strong> <?= View::e($usuario["usuario"]) ?></p>
      <p><strong>Nombre:</strong> <?= View::e($usuario["nombre_completo"]) ?></p>
      <p><strong>Rol:</strong> <span class="badge bg-info"><?= View::e($usuario["rol"]) ?></span></p>
      <p><strong>Permisos activos:</strong></p>
      <ul class="small">
        <?php foreach ($permisos as $p): ?><li><?= View::e($p) ?></li><?php endforeach; ?>
      </ul>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card bg-white p-3">
      <h5>Cambiar contraseña</h5>
      <form method="post" action="<?= APP_URL ?>perfil/cambiar_clave">
        <?= Csrf::field() ?>
        <div class="mb-2"><label>Contraseña actual</label><input type="password" name="actual" class="form-control" required></div>
        <div class="mb-2"><label>Nueva contraseña (mín. 8 caracteres)</label><input type="password" name="nueva" class="form-control" required minlength="8"></div>
        <div class="mb-2"><label>Confirmar nueva contraseña</label><input type="password" name="confirmar" class="form-control" required></div>
        <button class="btn btn-primary">Actualizar contraseña</button>
      </form>
    </div>
  </div>
</div>
