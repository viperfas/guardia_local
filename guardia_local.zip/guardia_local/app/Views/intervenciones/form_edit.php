<h3>Editar intervención #<?= (int)$int["id"] ?></h3>
<form method="post" action="<?= APP_URL ?>intervenciones/actualizar" class="bg-white p-3 rounded">
  <?= Csrf::field() ?>
  <input type="hidden" name="id" value="<?= $int["id"] ?>">
  <div class="row g-2">
    <div class="col-md-4"><label>Móvil</label>
      <select name="id_movil" class="form-select">
        <option value="">-</option>
        <?php foreach ($moviles as $m): ?><option value="<?= $m["id"] ?>" <?= ($int["id_movil"]??'')==$m["id"]?'selected':'' ?>><?= View::e($m["numero_interno"]) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4"><label>Equipo</label>
      <select name="id_equipo" class="form-select">
        <option value="">-</option>
        <?php foreach ($equipos as $e): ?><option value="<?= $e["id"] ?>" <?= ($int["id_equipo"]??'')==$e["id"]?'selected':'' ?>><?= View::e($e["nombre"]) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4"><label>Prioridad</label>
      <select name="prioridad" class="form-select">
        <?php foreach (['Baja','Media','Alta','Crítica'] as $p): ?>
          <option <?= ($int["prioridad"]??'Media')==$p?'selected':'' ?>><?= $p ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4"><label>Estado</label>
      <select name="estado" class="form-select">
        <?php foreach (['Asignado','En intervención','Derivado','Resuelto','Cerrado'] as $e): ?>
          <option <?= ($int["estado"]??'Asignado')==$e?'selected':'' ?>><?= $e ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-12"><label>Motivo</label><textarea name="motivo" class="form-control" rows="2"><?= View::e($int["motivo"]??'') ?></textarea></div>
    <div class="col-12"><label>Observaciones</label><textarea name="observaciones" class="form-control" rows="2"><?= View::e($int["observaciones"]??'') ?></textarea></div>
  </div>
  <button class="btn btn-primary mt-3">💾 Actualizar</button>
  <a href="<?= APP_URL ?>intervenciones/ver?id=<?= $int["id"] ?>" class="btn btn-secondary mt-3">Cancelar</a>
</form>