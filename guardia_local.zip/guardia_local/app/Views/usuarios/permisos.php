<h3>Matriz de permisos por rol</h3>

<?php if (!empty($_SESSION["permisos_ok"])): ?>
<div class="alert alert-success"><?= View::e($_SESSION["permisos_ok"]) ?></div>
<?php unset($_SESSION["permisos_ok"]); endif; ?>

<p class="text-muted">Asigná permisos a cada rol. Se aplicarán a <strong>todos los usuarios</strong> con ese rol.</p>

<form method="post" action="<?= APP_URL ?>usuarios/guardar_permisos">
  <?= Csrf::field() ?>
  <div class="table-responsive bg-white p-3 rounded">
    <table class="table table-sm table-bordered">
      <thead class="table-dark">
        <tr>
          <th style="min-width:200px">Permiso</th>
          <?php foreach ($roles as $r): ?>
            <th class="text-center"><?= View::e($r["nombre"]) ?></th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($permisos as $p): ?>
          <tr>
            <td>
              <strong><?= View::e($p["codigo"]) ?></strong>
              <?php if (!empty($p["descripcion"])): ?>
                <br><small class="text-muted"><?= View::e($p["descripcion"]) ?></small>
              <?php endif; ?>
            </td>
            <?php foreach ($roles as $r): ?>
              <td class="text-center">
                <input type="checkbox" 
                       name="permisos[<?= $r["id"] ?>][]" 
                       value="<?= $p["id"] ?>"
                       <?= in_array($p["id"], $matriz[$r["id"]]??[])?"checked":"" ?>>
              </td>
            <?php endforeach; ?>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <div class="mt-3">
    <button class="btn btn-primary btn-lg">💾 Guardar permisos</button>
    <a href="<?= APP_URL ?>usuarios/sincronizar" class="btn btn-warning btn-lg" 
       onclick="return confirm('¿Sincronizar permisos de todos los usuarios según sus roles?')">
      🔄 Sincronizar todos los usuarios
    </a>
    <a href="<?= APP_URL ?>usuarios" class="btn btn-secondary btn-lg">← Volver</a>
  </div>
  <div class="alert alert-info mt-3">
    <small>
      <strong>💡 Consejo:</strong> Después de guardar, hacé clic en "Sincronizar todos los usuarios" 
      para asegurarte de que todos los usuarios tengan los permisos correctos según su rol.
    </small>
  </div>
</form>