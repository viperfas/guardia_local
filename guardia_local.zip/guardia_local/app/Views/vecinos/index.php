<div class="d-flex justify-content-between mb-3">
  <h3>Vecinos registrados</h3>
  <a href="<?= APP_URL ?>vecinos/crear" class="btn btn-primary">➕ Nuevo vecino</a>
</div>
<form class="row g-2 mb-3">
  <div class="col-md-6"><input name="q" class="form-control" placeholder="Buscar por nombre, apellido, DNI, teléfono..." value="<?= View::e($q) ?>"></div>
  <div class="col-md-4">
    <select name="barrio" class="form-select">
      <option value="">Todos los barrios</option>
      <?php foreach ($barrios as $b): ?>
        <option value="<?= $b['id'] ?>" <?= $barrio==$b['id']?'selected':'' ?>><?= View::e($b['nombre']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="col-md-2"><button class="btn btn-outline-primary w-100">Filtrar</button></div>
</form>
<table class="table table-striped bg-white">
  <thead><tr><th>Apellido</th><th>Nombre</th><th>DNI</th><th>Teléfono</th><th>Barrio</th><th>Dirección</th><th>Acciones</th></tr></thead>
  <tbody>
  <?php foreach ($vecinos as $v): ?>
    <tr>
      <td><?= View::e($v['apellido']) ?></td>
      <td><?= View::e($v['nombre']) ?></td>
      <td><?= View::e($v['dni']) ?></td>
      <td><?= View::e($v['telefono']) ?></td>
      <td><?= View::e($v['barrio_nombre']??'-') ?></td>
      <td><?= View::e($v['direccion'].' '.$v['numero']) ?></td>
      <td>
        <a href="<?= APP_URL ?>vecinos/editar?id=<?= $v['id'] ?>" class="btn btn-sm btn-outline-primary">✏️ Editar</a>
        <form method="post" action="<?= APP_URL ?>vecinos/eliminar" style="display:inline" onsubmit="return confirm('¿Dar de baja a este vecino?')">
          <?= Csrf::field() ?>
          <input type="hidden" name="id" value="<?= $v['id'] ?>">
          <button class="btn btn-sm btn-outline-danger">🗑️</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>