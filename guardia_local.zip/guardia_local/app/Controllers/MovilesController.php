<?php
declare(strict_types=1);
class MovilesController extends Controller {
    public function index(): void {
        $db = Database::connection();
        $moviles = $db->query("SELECT * FROM moviles ORDER BY numero_interno")->fetchAll();
        $this->view("moviles/index", ["moviles"=>$moviles]);
    }
    public function create(): void {
        $this->view("moviles/form", ["movil"=>null]);
    }
    public function store(): void {
        $this->requirePost();
        $d = $_POST;
        $db = Database::connection();
        $stmt = $db->prepare("INSERT INTO moviles (numero_interno, tipo, marca, modelo, patente, estado, observaciones, fecha_incorporacion)
            VALUES (?,?,?,?,?,?,?,?)");
        $stmt->execute([$d["numero_interno"],$d["tipo"]??null,$d["marca"]??null,$d["modelo"]??null,
            $d["patente"]??null,$d["estado"]??"Disponible",$d["observaciones"]??null,$d["fecha_incorporacion"]??null]);
        Audit::log("alta_movil","moviles",(string)$db->lastInsertId());
        $this->redirect("moviles");
    }
    public function edit(): void {
        $id = (int)($_GET["id"]??0);
        $db = Database::connection();
        $stmt = $db->prepare("SELECT * FROM moviles WHERE id=?");
        $stmt->execute([$id]);
        $movil = $stmt->fetch();
        if (!$movil) { $this->redirect("moviles"); return; }
        $this->view("moviles/form", ["movil"=>$movil]);
    }
    public function update(): void {
        $this->requirePost();
        $d = $_POST;
        $db = Database::connection();
        $stmt = $db->prepare("UPDATE moviles SET numero_interno=?, tipo=?, marca=?, modelo=?, patente=?, estado=?, observaciones=?, fecha_incorporacion=? WHERE id=?");
        $stmt->execute([$d["numero_interno"],$d["tipo"]??null,$d["marca"]??null,$d["modelo"]??null,
            $d["patente"]??null,$d["estado"]??"Disponible",$d["observaciones"]??null,$d["fecha_incorporacion"]??null,(int)$d["id"]]);
        Audit::log("edit_movil","moviles",$d["id"]);
        $this->redirect("moviles");
    }
    public function delete(): void {
        $this->requirePost();
        $id = (int)($_POST['id']??0);
        $db = Database::connection();
        $tiene = $db->prepare('SELECT COUNT(*) FROM intervenciones WHERE id_movil=?');
        $tiene->execute([$id]);
        if ($tiene->fetchColumn() > 0) {
            $_SESSION['error'] = 'No se puede eliminar: tiene intervenciones asociadas';
            $this->redirect('moviles');
            return;
        }
        $db->prepare('DELETE FROM moviles WHERE id=?')->execute([$id]);
        Audit::log('delete_movil','moviles',(string)$id);
        $this->redirect('moviles');
    }
    public function changeState(): void {
        $this->requirePost();
        $db = Database::connection();
        $db->prepare("UPDATE moviles SET estado=? WHERE id=?")->execute([$_POST["estado"], (int)$_POST["id"]]);
        Audit::log("estado_movil","moviles",$_POST["id"]." → ".$_POST["estado"]);
        $this->redirect("moviles");
    }
}
