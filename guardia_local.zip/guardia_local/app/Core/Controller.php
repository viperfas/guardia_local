<?php
declare(strict_types=1);

abstract class Controller
{
    /**
     * Renderiza una vista con datos
     */
    protected function view(string $vista, array $datos = []): void
    {
        extract($datos);
        $vistaPath = APP_PATH . 'Views/' . $vista . '.php';
        
        if (!file_exists($vistaPath)) {
            http_response_code(404);
            echo "<h1>Error 404</h1><p>Vista no encontrada: $vista</p>";
            return;
        }
        
        // Cargar layout principal
        $layoutPath = APP_PATH . 'Views/layouts/main.php';
        if (file_exists($layoutPath)) {
            ob_start();
            require $vistaPath;
            $content = ob_get_clean();
            require $layoutPath;
        } else {
            require $vistaPath;
        }
    }
    
    /**
     * Redirige a otra URL
     */
    protected function redirect(string $ruta): void
    {
        $url = defined('APP_URL') ? APP_URL . ltrim($ruta, '/') : '/' . ltrim($ruta, '/');
        header('Location: ' . $url);
        exit;
    }
    
    /**
     * Envía respuesta JSON
     */
    protected function json($data, int $code = 200): void
    {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    /**
     * Verifica que la petición sea POST
     */
    protected function requirePost(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo "Método no permitido";
            exit;
        }
        
        // Verificar CSRF si existe la clase
        if (class_exists('Csrf') && method_exists('Csrf', 'verify')) {
            try {
                Csrf::verify();
            } catch (Throwable $e) {
                http_response_code(403);
                echo "Token CSRF inválido";
                exit;
            }
        }
    }
    
    /**
     * Verifica que el usuario esté autenticado
     */
    protected function requireAuth(): void
    {
        if (empty($_SESSION['user_id'])) {
            $this->redirect('login');
        }
    }
	
	    protected function viewPlain(string $vista, array $datos = []): void
    {
        extract($datos, EXTR_SKIP);

        $vistaPath = APP_PATH . 'Views' . DIRECTORY_SEPARATOR .
            str_replace('/', DIRECTORY_SEPARATOR, $vista) . '.php';

        if (!file_exists($vistaPath)) {
            http_response_code(404);
            echo "<h1>Error 404</h1><p>Vista no encontrada: " . htmlspecialchars($vista, ENT_QUOTES, 'UTF-8') . "</p>";
            return;
        }

        require $vistaPath;
    }
}