<h3>Despacho de intervención</h3>
<div class="row">
  <div class="col-md-5">
    <div class="card bg-light p-3">
      <h5>Incidente a atender</h5>
      <p><strong>#<?= (int)$incidente["id"] ?></strong> — <?= View::e($incidente["fecha"]." ".$incidente["hora"]) ?></p>
      <p><strong>Categoría:</strong> <?= View::e($incidente["categoria"]??"-") ?></p>
      <p><strong>Prioridad:</strong> <span class="badge bg-<?= $incidente["prioridad"]=="Crítica"?"danger":($incidente["prioridad"]=="Alta"?"warning":"secondary") ?>"><?= View::e($incidente["prioridad"]) ?></span></p>
      <p><strong>Barrio:</strong> <?= View::e($incidente["barrio"]??"-") ?></p>
      <p><strong>Dirección:</strong> <?= View::e($incidente["direccion"]??"-") ?></p>
      <p><strong>Descripción:</strong><br><?= View::e($incidente["descripcion"]??"") ?></p>
    </div>
  </div>
  <div class="col-md-7">
    <form method="post" action="<?= APP_URL ?>intervenciones/guardar_despacho" class="bg-white p-3 rounded">
      <?= Csrf::field() ?>
      <input type="hidden" name="id_incidente" value="<?= $incidente["id"] ?>">
      <div class="row g-2">
        <div class="col-md-6"><label>Móvil a despachar</label>
          <select name="id_movil" class="form-select">
            <option value="">-</option>
            <?php foreach ($moviles as $m): ?><option value="<?= $m["id"] ?>"><?= View::e($m["numero_interno"]) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-6"><label>Equipo</label>
          <select name="id_equipo" class="form-select">
            <option value="">-</option>
            <?php foreach ($equipos as $e): ?><option value="<?= $e["id"] ?>"><?= View::e($e["nombre"]) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-6"><label>Prioridad</label>
          <select name="prioridad" class="form-select">
            <option>Baja</option><option>Media</option><option>Alta</option><option>Crítica</option>
          </select>
        </div>
        <div class="col-12"><label>Motivo</label><textarea name="motivo" class="form-control" rows="2" required></textarea></div>
        <div class="col-12"><label>Observaciones</label><textarea name="observaciones" class="form-control" rows="2"></textarea></div>
      </div>
      <button class="btn btn-danger mt-3">🚨 Despachar intervención</button>
      <a href="<?= APP_URL ?>incidentes" class="btn btn-secondary mt-3">Cancelar</a>
    </form>
  </div>
</div>
