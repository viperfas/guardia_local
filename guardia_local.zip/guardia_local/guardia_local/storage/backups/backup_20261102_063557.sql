/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.16-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: guardia_local
-- ------------------------------------------------------
-- Server version	10.11.16-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auditoria`
--

DROP TABLE IF EXISTS `auditoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditoria` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `fecha_hora` datetime NOT NULL DEFAULT current_timestamp(),
  `ip` varchar(45) NOT NULL,
  `tipo_operacion` varchar(60) NOT NULL,
  `modulo` varchar(60) NOT NULL,
  `registro_afectado` varchar(100) DEFAULT NULL,
  `valores_anteriores` text DEFAULT NULL,
  `valores_nuevos` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aud_fecha` (`fecha_hora`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria`
--

LOCK TABLES `auditoria` WRITE;
/*!40000 ALTER TABLE `auditoria` DISABLE KEYS */;
INSERT INTO `auditoria` VALUES
(2,1,'2026-11-02 02:45:31','::1','login','auth','admin',NULL,NULL),
(3,1,'2026-11-02 02:47:43','::1','edit_permisos_rol','usuarios','{\"1\":[\"11\",\"13\",\"8\",\"9\",\"5\",\"4\",\"6\",\"7\",\"10\",\"14\",\"12\",\"2\",\"3\",\"1\"],\"2\":[\"5\",\"4\",\"6\",\"10\",\"2\",\"3\",\"1',NULL,NULL),
(4,1,'2026-11-02 02:49:52','::1','edit_permisos_rol','usuarios','{\"1\":[\"11\",\"13\",\"8\",\"9\",\"5\",\"4\",\"6\",\"7\",\"10\",\"14\",\"12\",\"2\",\"3\",\"1\"],\"2\":[\"5\",\"4\",\"6\",\"10\",\"2\",\"3\",\"1',NULL,NULL),
(5,1,'2026-11-02 03:01:25','::1','edit_permisos_rol','usuarios','Matriz actualizada',NULL,NULL),
(6,1,'2026-11-02 03:03:11','::1','alta_usuario','usuarios','3',NULL,NULL),
(7,1,'2026-11-02 03:03:18','::1','logout','auth','Administrador inicial',NULL,NULL),
(8,NULL,'2026-11-02 03:03:21','::1','intento_login','auth','Ara',NULL,NULL),
(9,3,'2026-11-02 03:03:21','::1','login','auth','Ara',NULL,NULL),
(10,3,'2026-11-02 03:03:57','::1','logout','auth','Araceli',NULL,NULL),
(14,NULL,'2026-11-02 03:04:58','::1','intento_login','auth','Ara',NULL,NULL),
(15,3,'2026-11-02 03:04:59','::1','login','auth','Ara',NULL,NULL),
(16,3,'2026-11-02 03:06:19','::1','alta_vecino','vecinos','1',NULL,NULL),
(17,3,'2026-11-02 03:06:51','::1','alta_incidente','incidentes','1',NULL,NULL),
(18,3,'2026-11-02 03:07:07','::1','despacho_intervencion','intervenciones','1',NULL,NULL),
(19,3,'2026-11-02 03:07:14','::1','salida_intervencion','intervenciones','1',NULL,NULL),
(20,3,'2026-11-02 03:07:16','::1','llegada_intervencion','intervenciones','1',NULL,NULL),
(21,3,'2026-11-02 03:07:23','::1','cierre_intervencion','intervenciones','1',NULL,NULL),
(22,3,'2026-11-02 03:09:22','::1','logout','auth','Araceli',NULL,NULL),
(25,NULL,'2026-11-02 03:11:15','::1','bloqueo_login','auth','admin',NULL,NULL),
(26,NULL,'2026-11-02 03:14:15','::1','intento_login','auth','admin',NULL,NULL),
(27,1,'2026-11-02 03:14:15','::1','login','auth','admin',NULL,NULL),
(28,1,'2026-11-02 03:14:37','::1','sincronizar_permisos','usuarios','2 usuarios sincronizados',NULL,NULL),
(29,1,'2026-11-02 03:15:15','::1','logout','auth','Administrador inicial',NULL,NULL),
(30,NULL,'2026-11-02 03:15:16','::1','intento_login','auth','Ara',NULL,NULL),
(31,3,'2026-11-02 03:15:17','::1','login','auth','Ara',NULL,NULL),
(32,3,'2026-11-02 03:15:29','::1','logout','auth','Araceli',NULL,NULL),
(33,NULL,'2026-11-02 03:15:44','::1','intento_login','auth','admin',NULL,NULL),
(34,1,'2026-11-02 03:15:44','::1','login','auth','admin',NULL,NULL),
(35,1,'2026-11-02 03:26:13','::1','edit_vecino','vecinos','1',NULL,NULL),
(36,1,'2026-11-02 03:26:21','::1','edit_vecino','vecinos','1',NULL,NULL),
(37,1,'2026-11-02 03:26:28','::1','edit_vecino','vecinos','1',NULL,NULL),
(38,1,'2026-11-02 03:39:57','::1','logout','auth','Administrador inicial',NULL,NULL),
(39,NULL,'2026-11-02 03:39:59','::1','intento_login','auth','Ara',NULL,NULL),
(40,3,'2026-11-02 03:40:00','::1','login','auth','Ara',NULL,NULL),
(41,3,'2026-11-02 03:40:04','::1','logout','auth','Araceli',NULL,NULL),
(42,NULL,'2026-11-02 03:40:10','::1','intento_login','auth','admin',NULL,NULL),
(43,NULL,'2026-11-02 03:40:25','::1','intento_login','auth','admin',NULL,NULL),
(44,1,'2026-11-02 03:40:25','::1','login','auth','admin',NULL,NULL),
(45,1,'2026-11-02 03:52:19','::1','alta_movil','moviles','1',NULL,NULL),
(46,1,'2026-11-02 03:53:49','::1','alta_equipo','equipos','1',NULL,NULL),
(47,1,'2026-11-02 03:54:29','::1','alta_personal','personal','1',NULL,NULL),
(48,1,'2026-11-02 03:54:50','::1','alta_personal','personal','2',NULL,NULL),
(49,1,'2026-11-02 03:55:06','::1','edit_personal','personal','1',NULL,NULL),
(50,1,'2026-11-02 03:56:20','::1','edit_equipo','equipos','1',NULL,NULL),
(51,1,'2026-11-02 03:56:23','::1','logout','auth','Administrador inicial',NULL,NULL),
(52,NULL,'2026-11-02 03:56:25','::1','intento_login','auth','Ara',NULL,NULL),
(53,3,'2026-11-02 03:56:25','::1','login','auth','Ara',NULL,NULL),
(54,3,'2026-11-02 03:56:42','::1','logout','auth','Araceli',NULL,NULL),
(55,NULL,'2026-11-02 03:56:56','::1','intento_login','auth','admin',NULL,NULL),
(56,1,'2026-11-02 03:56:56','::1','login','auth','admin',NULL,NULL),
(57,1,'2026-11-02 03:58:21','::1','edit_usuario','usuarios','3',NULL,NULL),
(58,1,'2026-11-02 03:58:25','::1','logout','auth','Administrador inicial',NULL,NULL),
(59,NULL,'2026-11-02 03:58:27','::1','intento_login','auth','Ara',NULL,NULL),
(60,3,'2026-11-02 03:58:27','::1','login','auth','Ara',NULL,NULL),
(61,3,'2026-11-02 03:59:28','::1','alta_incidente','incidentes','2',NULL,NULL),
(62,3,'2026-11-02 04:00:40','::1','edit_incidente','incidentes','2',NULL,NULL),
(63,3,'2026-11-02 04:24:31','::1','despacho_intervencion','intervenciones','3',NULL,NULL),
(64,3,'2026-11-02 04:25:04','::1','logout','auth','Araceli',NULL,NULL),
(65,NULL,'2026-11-02 04:25:18','::1','intento_login','auth','admin',NULL,NULL),
(66,1,'2026-11-02 04:25:18','::1','login','auth','admin',NULL,NULL),
(67,1,'2026-11-02 04:30:37','::1','llegada_intervencion','intervenciones','2',NULL,NULL),
(68,1,'2026-11-02 04:30:48','::1','cierre_intervencion','intervenciones','2',NULL,NULL),
(69,1,'2026-11-02 04:31:28','::1','edit_intervencion','intervenciones','3',NULL,NULL),
(70,1,'2026-11-02 04:31:45','::1','llegada_intervencion','intervenciones','3',NULL,NULL),
(71,1,'2026-11-02 04:32:35','::1','cierre_intervencion','intervenciones','3',NULL,NULL),
(72,1,'2026-11-02 04:33:09','::1','edit_intervencion','intervenciones','1',NULL,NULL),
(73,1,'2026-11-02 04:34:25','::1','logout','auth','Administrador inicial',NULL,NULL),
(74,NULL,'2026-11-02 04:34:26','::1','intento_login','auth','Ara',NULL,NULL),
(75,3,'2026-11-02 04:34:27','::1','login','auth','Ara',NULL,NULL),
(76,3,'2026-11-02 04:35:41','::1','alta_vecino','vecinos','2',NULL,NULL),
(77,3,'2026-11-02 04:36:37','::1','edit_vecino','vecinos','1',NULL,NULL),
(78,3,'2026-11-02 04:37:22','::1','logout','auth','Araceli',NULL,NULL),
(79,NULL,'2026-11-02 04:37:37','::1','intento_login','auth','admin',NULL,NULL),
(80,1,'2026-11-02 04:37:37','::1','login','auth','admin',NULL,NULL),
(81,1,'2026-11-02 04:38:13','::1','edit_usuario','usuarios','3',NULL,NULL),
(82,1,'2026-11-02 04:38:17','::1','logout','auth','Administrador inicial',NULL,NULL),
(83,NULL,'2026-11-02 04:38:19','::1','intento_login','auth','Ara',NULL,NULL),
(84,3,'2026-11-02 04:38:19','::1','login','auth','Ara',NULL,NULL),
(85,3,'2026-11-02 04:39:15','::1','edit_intervencion','intervenciones','3',NULL,NULL),
(86,3,'2026-11-02 04:39:55','::1','edit_intervencion','intervenciones','3',NULL,NULL),
(87,3,'2026-11-02 04:40:09','::1','novedad_intervencion','intervenciones','3',NULL,NULL),
(88,3,'2026-11-02 04:40:37','::1','edit_intervencion','intervenciones','3',NULL,NULL),
(89,3,'2026-11-02 04:41:01','::1','edit_intervencion','intervenciones','3',NULL,NULL),
(90,3,'2026-11-02 04:41:44','::1','logout','auth','Araceli',NULL,NULL),
(91,NULL,'2026-11-02 04:41:57','::1','intento_login','auth','admin',NULL,NULL),
(92,1,'2026-11-02 04:41:57','::1','login','auth','admin',NULL,NULL),
(93,1,'2026-11-02 05:18:05','::1','logout','auth','Administrador inicial',NULL,NULL),
(94,NULL,'2026-11-02 05:18:21','::1','intento_login','auth','admin',NULL,NULL),
(95,1,'2026-11-02 05:18:21','::1','login','auth','admin',NULL,NULL),
(96,1,'2026-11-02 05:21:57','::1','logout','auth','Administrador inicial',NULL,NULL),
(97,NULL,'2026-11-02 05:21:58','::1','intento_login','auth','Ara',NULL,NULL),
(98,3,'2026-11-02 05:21:59','::1','login','auth','Ara',NULL,NULL),
(99,3,'2026-11-02 05:22:08','::1','logout','auth','Araceli',NULL,NULL),
(100,NULL,'2026-11-02 05:22:20','::1','intento_login','auth','admin',NULL,NULL),
(101,1,'2026-11-02 05:22:20','::1','login','auth','admin',NULL,NULL),
(102,1,'2026-11-02 06:11:56','::1','editor_visual_barrio','barrios','8',NULL,NULL),
(103,1,'2026-11-02 06:29:32','::1','editor_visual_barrio','barrios','6',NULL,NULL);
/*!40000 ALTER TABLE `auditoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `barrios`
--

DROP TABLE IF EXISTS `barrios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `barrios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `geojson` longtext DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_barrios_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `barrios`
--

LOCK TABLES `barrios` WRITE;
/*!40000 ALTER TABLE `barrios` DISABLE KEYS */;
INSERT INTO `barrios` VALUES
(1,'Centro','Casco céntrico de Villa Giardino',NULL,1),
(2,'Barrio San Martín','Sector oeste',NULL,1),
(3,'Barrio Parque','Sector residencial',NULL,1),
(4,'Barrio Los Aromos','Sector norte',NULL,1),
(5,'Barrio Las Flores','Sector sur',NULL,1),
(6,'Barrio Intiyaco','Sector periurbano','{\"type\":\"Polygon\",\"coordinates\":[[[-64.425054,-31.120643],[-64.399815,-31.116525],[-64.402391,-31.135937],[-64.429518,-31.143289],[-64.425054,-31.120643]]]}',1),
(7,'Barrio La Estación','Zona cercana a la estación',NULL,1),
(8,'Barrio El Dique','Zona próxima al dique','{\"type\":\"Polygon\",\"coordinates\":[[[-64.42975,-31.143407],[-64.402542,-31.136501],[-64.399023,-31.149577],[-64.427261,-31.152148],[-64.432411,-31.181672],[-64.468117,-31.140836],[-64.446487,-31.123203],[-64.424858,-31.120852],[-64.42975,-31.143407]]]}',1);
/*!40000 ALTER TABLE `barrios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `barrios_historial`
--

DROP TABLE IF EXISTS `barrios_historial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `barrios_historial` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_barrio` int(10) unsigned NOT NULL,
  `id_usuario` int(10) unsigned NOT NULL,
  `fecha_hora` datetime NOT NULL DEFAULT current_timestamp(),
  `tipo_operacion` varchar(50) NOT NULL,
  `geojson_anterior` longtext DEFAULT NULL,
  `geojson_nuevo` longtext DEFAULT NULL,
  `nombre_anterior` varchar(120) DEFAULT NULL,
  `nombre_nuevo` varchar(120) DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hist_barrio` (`id_barrio`),
  KEY `idx_hist_fecha` (`fecha_hora`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `barrios_historial`
--

LOCK TABLES `barrios_historial` WRITE;
/*!40000 ALTER TABLE `barrios_historial` DISABLE KEYS */;
INSERT INTO `barrios_historial` VALUES
(1,8,1,'2026-11-02 06:11:56','edicion_visual',NULL,'{\"type\":\"Polygon\",\"coordinates\":[[[-64.42975,-31.143407],[-64.402542,-31.136501],[-64.399023,-31.149577],[-64.427261,-31.152148],[-64.432411,-31.181672],[-64.468117,-31.140836],[-64.446487,-31.123203],[-64.424858,-31.120852],[-64.42975,-31.143407]]]}','Barrio El Dique','Barrio El Dique','Polígono cargado o editado desde editor visual'),
(2,6,1,'2026-11-02 06:29:32','edicion_visual',NULL,'{\"type\":\"Polygon\",\"coordinates\":[[[-64.425054,-31.120643],[-64.399815,-31.116525],[-64.402391,-31.135937],[-64.429518,-31.143289],[-64.425054,-31.120643]]]}','Barrio Intiyaco','Barrio Intiyaco','Polígono cargado o editado desde editor visual');
/*!40000 ALTER TABLE `barrios_historial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias_incidentes`
--

DROP TABLE IF EXISTS `categorias_incidentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorias_incidentes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `color` varchar(7) DEFAULT '#6c7572',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_categorias_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias_incidentes`
--

LOCK TABLES `categorias_incidentes` WRITE;
/*!40000 ALTER TABLE `categorias_incidentes` DISABLE KEYS */;
INSERT INTO `categorias_incidentes` VALUES
(1,'Robo','#dc3545',1),
(2,'Hurto','#fd7e14',1),
(3,'Vandalismo','#ffc107',1),
(4,'Persona sospechosa','#6f42c1',1),
(5,'Vehículo sospechoso','#20c997',1),
(6,'Violencia familiar','#d63384',1),
(7,'Violencia en vía pública','#e35d6a',1),
(8,'Accidente de tránsito','#0dcaf0',1),
(9,'Incendio','#dc3545',1),
(10,'Emergencia médica','#198754',1),
(11,'Ruidos molestos','#6c757d',1),
(12,'Animales sueltos','#adb5bd',1),
(13,'Animales peligrosos','#dc3545',1),
(14,'Conflictos vecinales','#fd7e14',1),
(15,'Daños en espacios públicos','#0d6efd',1),
(16,'Situaciones sospechosas generales','#6f42c1',1),
(17,'Emergencias generales','#dc3545',1),
(18,'Otros','#6c757d',1);
/*!40000 ALTER TABLE `categorias_incidentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuracion`
--

DROP TABLE IF EXISTS `configuracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `configuracion` (
  `clave` varchar(80) NOT NULL,
  `valor` text DEFAULT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuracion`
--

LOCK TABLES `configuracion` WRITE;
/*!40000 ALTER TABLE `configuracion` DISABLE KEYS */;
INSERT INTO `configuracion` VALUES
('ia_habilitada','0','0 = deshabilitada'),
('ia_proveedor','','Proveedor de IA'),
('mapa_center_lat','-31.1470','Latitud central'),
('mapa_center_lng','-64.4010','Longitud central'),
('mapa_zoom','14','Zoom inicial'),
('municipio_nombre','Municipalidad de Villa Giardino','Nombre oficial'),
('municipio_pais','Argentina','País'),
('municipio_provincia','Córdoba','Provincia');
/*!40000 ALTER TABLE `configuracion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipos`
--

DROP TABLE IF EXISTS `equipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `id_responsable` int(10) unsigned DEFAULT NULL,
  `turno` varchar(30) DEFAULT NULL,
  `id_movil` int(10) unsigned DEFAULT NULL,
  `estado` varchar(40) NOT NULL DEFAULT 'Activo',
  PRIMARY KEY (`id`),
  KEY `fk_equipos_responsable` (`id_responsable`),
  KEY `fk_equipos_movil` (`id_movil`),
  CONSTRAINT `fk_equipos_movil` FOREIGN KEY (`id_movil`) REFERENCES `moviles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_equipos_responsable` FOREIGN KEY (`id_responsable`) REFERENCES `personal` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipos`
--

LOCK TABLES `equipos` WRITE;
/*!40000 ALTER TABLE `equipos` DISABLE KEYS */;
INSERT INTO `equipos` VALUES
(1,'Choferes',NULL,'Rotativo',NULL,'Activo');
/*!40000 ALTER TABLE `equipos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipos_integrantes`
--

DROP TABLE IF EXISTS `equipos_integrantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipos_integrantes` (
  `id_equipo` int(10) unsigned NOT NULL,
  `id_personal` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_equipo`,`id_personal`),
  KEY `fk_ei_personal` (`id_personal`),
  CONSTRAINT `fk_ei_equipo` FOREIGN KEY (`id_equipo`) REFERENCES `equipos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ei_personal` FOREIGN KEY (`id_personal`) REFERENCES `personal` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipos_integrantes`
--

LOCK TABLES `equipos_integrantes` WRITE;
/*!40000 ALTER TABLE `equipos_integrantes` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipos_integrantes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidentes`
--

DROP TABLE IF EXISTS `incidentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `incidentes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numero` int(10) unsigned NOT NULL DEFAULT 0,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `id_vecino` int(10) unsigned DEFAULT NULL,
  `telefono_informante` varchar(30) DEFAULT NULL,
  `id_operador` int(10) unsigned NOT NULL,
  `id_categoria` int(10) unsigned DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `id_barrio` int(10) unsigned DEFAULT NULL,
  `direccion` varchar(200) DEFAULT NULL,
  `referencia` varchar(255) DEFAULT NULL,
  `latitud` decimal(10,7) DEFAULT NULL,
  `longitud` decimal(10,7) DEFAULT NULL,
  `prioridad` enum('Crítica','Alta','Media','Baja') NOT NULL DEFAULT 'Media',
  `estado` enum('Recibido','Pendiente de evaluación','Asignado','En intervención','Derivado','Resuelto','Cerrado') NOT NULL DEFAULT 'Recibido',
  `observaciones` text DEFAULT NULL,
  `fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_incidentes_fecha` (`fecha`),
  KEY `fk_incidentes_vecino` (`id_vecino`),
  KEY `fk_incidentes_operador` (`id_operador`),
  KEY `fk_incidentes_categoria` (`id_categoria`),
  KEY `fk_incidentes_barrio` (`id_barrio`),
  CONSTRAINT `fk_incidentes_barrio` FOREIGN KEY (`id_barrio`) REFERENCES `barrios` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_incidentes_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categorias_incidentes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_incidentes_operador` FOREIGN KEY (`id_operador`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `fk_incidentes_vecino` FOREIGN KEY (`id_vecino`) REFERENCES `vecinos` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidentes`
--

LOCK TABLES `incidentes` WRITE;
/*!40000 ALTER TABLE `incidentes` DISABLE KEYS */;
INSERT INTO `incidentes` VALUES
(1,0,'2026-11-02','03:06:51',1,'222222',3,11,'ssss',8,'wssss','',NULL,NULL,'Media','Resuelto',NULL,'2026-11-02 03:06:51'),
(2,0,'2026-11-02','03:59:28',1,'222222',3,11,'ret',8,'222222','rtg',NULL,NULL,'Alta','Resuelto','','2026-11-02 03:59:28');
/*!40000 ALTER TABLE `incidentes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidentes_adjuntos`
--

DROP TABLE IF EXISTS `incidentes_adjuntos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `incidentes_adjuntos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_incidente` int(10) unsigned NOT NULL,
  `nombre_archivo` varchar(255) NOT NULL,
  `ruta` varchar(500) NOT NULL,
  `tipo_mime` varchar(100) DEFAULT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_adj_incidente` (`id_incidente`),
  CONSTRAINT `fk_adj_incidente` FOREIGN KEY (`id_incidente`) REFERENCES `incidentes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidentes_adjuntos`
--

LOCK TABLES `incidentes_adjuntos` WRITE;
/*!40000 ALTER TABLE `incidentes_adjuntos` DISABLE KEYS */;
/*!40000 ALTER TABLE `incidentes_adjuntos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidentes_novedades`
--

DROP TABLE IF EXISTS `incidentes_novedades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `incidentes_novedades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_incidente` int(10) unsigned NOT NULL,
  `id_operador` int(10) unsigned NOT NULL,
  `fecha_hora` datetime NOT NULL DEFAULT current_timestamp(),
  `tipo` varchar(50) NOT NULL,
  `descripcion` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_nov_incidente` (`id_incidente`),
  KEY `fk_nov_operador` (`id_operador`),
  CONSTRAINT `fk_nov_incidente` FOREIGN KEY (`id_incidente`) REFERENCES `incidentes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nov_operador` FOREIGN KEY (`id_operador`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidentes_novedades`
--

LOCK TABLES `incidentes_novedades` WRITE;
/*!40000 ALTER TABLE `incidentes_novedades` DISABLE KEYS */;
/*!40000 ALTER TABLE `incidentes_novedades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `informes`
--

DROP TABLE IF EXISTS `informes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `informes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipo` varchar(60) NOT NULL,
  `periodo_desde` date DEFAULT NULL,
  `periodo_hasta` date DEFAULT NULL,
  `contenido` longtext DEFAULT NULL,
  `proveedor_ia` varchar(60) DEFAULT NULL,
  `modelo_ia` varchar(60) DEFAULT NULL,
  `id_usuario` int(10) unsigned DEFAULT NULL,
  `fecha_generacion` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `informes`
--

LOCK TABLES `informes` WRITE;
/*!40000 ALTER TABLE `informes` DISABLE KEYS */;
/*!40000 ALTER TABLE `informes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `intervenciones`
--

DROP TABLE IF EXISTS `intervenciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `intervenciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numero` int(10) unsigned NOT NULL DEFAULT 0,
  `id_incidente` int(10) unsigned NOT NULL,
  `fecha_hora_despacho` datetime NOT NULL DEFAULT current_timestamp(),
  `prioridad` enum('Crítica','Alta','Media','Baja') NOT NULL DEFAULT 'Media',
  `id_movil` int(10) unsigned DEFAULT NULL,
  `id_equipo` int(10) unsigned DEFAULT NULL,
  `id_operador_despacho` int(10) unsigned NOT NULL,
  `motivo` text DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `estado` enum('Asignado','En intervención','Derivado','Resuelto','Cerrado') NOT NULL DEFAULT 'Asignado',
  `hora_salida` datetime DEFAULT NULL,
  `hora_llegada` datetime DEFAULT NULL,
  `hora_finalizacion` datetime DEFAULT NULL,
  `resultado` text DEFAULT NULL,
  `acciones_realizadas` text DEFAULT NULL,
  `organismos_externos` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_int_incidente` (`id_incidente`),
  KEY `fk_int_movil` (`id_movil`),
  KEY `fk_int_equipo` (`id_equipo`),
  KEY `fk_int_operador` (`id_operador_despacho`),
  CONSTRAINT `fk_int_equipo` FOREIGN KEY (`id_equipo`) REFERENCES `equipos` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_int_incidente` FOREIGN KEY (`id_incidente`) REFERENCES `incidentes` (`id`),
  CONSTRAINT `fk_int_movil` FOREIGN KEY (`id_movil`) REFERENCES `moviles` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_int_operador` FOREIGN KEY (`id_operador_despacho`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `intervenciones`
--

LOCK TABLES `intervenciones` WRITE;
/*!40000 ALTER TABLE `intervenciones` DISABLE KEYS */;
INSERT INTO `intervenciones` VALUES
(1,0,1,'2026-11-02 03:07:07','Baja',1,1,3,'ssss','ssss','Resuelto','2026-11-02 03:07:13','2026-11-02 03:07:16','2026-11-02 03:07:23','ssss','ssss','sss'),
(2,0,2,'2026-11-02 04:01:03','Baja',1,1,3,'ra','','Resuelto','2026-11-02 04:25:44','2026-11-02 04:30:37','2026-11-02 04:30:48','wDE','SDA',''),
(3,0,2,'2026-11-02 04:24:31','Baja',1,1,3,'wwewe','wewe','Resuelto','2026-11-02 04:24:35','2026-11-02 04:31:45','2026-11-02 04:32:35','NADA','Se Patrullo','policia');
/*!40000 ALTER TABLE `intervenciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `intervenciones_novedades`
--

DROP TABLE IF EXISTS `intervenciones_novedades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `intervenciones_novedades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_intervencion` int(10) unsigned NOT NULL,
  `id_operador` int(10) unsigned DEFAULT NULL,
  `fecha_hora` datetime NOT NULL DEFAULT current_timestamp(),
  `tipo` varchar(50) NOT NULL,
  `descripcion` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_inv_nov` (`id_intervencion`),
  CONSTRAINT `fk_inv_nov` FOREIGN KEY (`id_intervencion`) REFERENCES `intervenciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `intervenciones_novedades`
--

LOCK TABLES `intervenciones_novedades` WRITE;
/*!40000 ALTER TABLE `intervenciones_novedades` DISABLE KEYS */;
INSERT INTO `intervenciones_novedades` VALUES
(1,1,3,'2026-11-02 03:07:07','despacho','ssss'),
(2,1,3,'2026-11-02 03:07:13','salida','Movil en camino'),
(3,1,3,'2026-11-02 03:07:16','llegada','Personal en el lugar'),
(4,1,3,'2026-11-02 03:07:23','cierre','ssss'),
(5,3,3,'2026-11-02 04:24:31','despacho','wwewe'),
(6,2,1,'2026-11-02 04:30:37','llegada','Personal en el lugar'),
(7,2,1,'2026-11-02 04:30:48','cierre','wDE'),
(8,3,1,'2026-11-02 04:31:45','llegada','Personal en el lugar'),
(9,3,1,'2026-11-02 04:32:35','cierre','NADA'),
(10,3,3,'2026-11-02 04:40:09','cambio_personal','aaxaxaxax');
/*!40000 ALTER TABLE `intervenciones_novedades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `intervenciones_personal`
--

DROP TABLE IF EXISTS `intervenciones_personal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `intervenciones_personal` (
  `id_intervencion` int(10) unsigned NOT NULL,
  `id_personal` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_intervencion`,`id_personal`),
  KEY `fk_ip_personal` (`id_personal`),
  CONSTRAINT `fk_ip_interv` FOREIGN KEY (`id_intervencion`) REFERENCES `intervenciones` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ip_personal` FOREIGN KEY (`id_personal`) REFERENCES `personal` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `intervenciones_personal`
--

LOCK TABLES `intervenciones_personal` WRITE;
/*!40000 ALTER TABLE `intervenciones_personal` DISABLE KEYS */;
/*!40000 ALTER TABLE `intervenciones_personal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moviles`
--

DROP TABLE IF EXISTS `moviles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `moviles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numero_interno` varchar(30) NOT NULL,
  `tipo` varchar(60) DEFAULT NULL,
  `marca` varchar(60) DEFAULT NULL,
  `modelo` varchar(60) DEFAULT NULL,
  `patente` varchar(20) DEFAULT NULL,
  `estado` enum('Disponible','Asignado','En servicio','Fuera de servicio','En mantenimiento') NOT NULL DEFAULT 'Disponible',
  `observaciones` text DEFAULT NULL,
  `fecha_incorporacion` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_moviles_numero` (`numero_interno`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moviles`
--

LOCK TABLES `moviles` WRITE;
/*!40000 ALTER TABLE `moviles` DISABLE KEYS */;
INSERT INTO `moviles` VALUES
(1,'Movil 1','Auto','Renault','Sandero','','Disponible','El mas viejito','2026-11-02');
/*!40000 ALTER TABLE `moviles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permisos`
--

DROP TABLE IF EXISTS `permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permisos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(80) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_permisos_codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permisos`
--

LOCK TABLES `permisos` WRITE;
/*!40000 ALTER TABLE `permisos` DISABLE KEYS */;
INSERT INTO `permisos` VALUES
(1,'vecinos.ver','Ver vecinos'),
(2,'vecinos.crear','Crear vecinos'),
(3,'vecinos.editar','Editar vecinos'),
(4,'incidentes.ver','Ver incidentes'),
(5,'incidentes.crear','Crear incidentes'),
(6,'intervenciones.despachar','Despachar intervenciones'),
(7,'mapa.ver','Ver mapa territorial'),
(8,'estadisticas.ver','Ver estadísticas'),
(9,'ia.generar','Generar informes IA'),
(10,'reportes.generar','Generar reportes'),
(11,'auditoria.ver','Ver auditoría'),
(12,'usuarios.gestionar','Gestionar usuarios'),
(13,'configuracion.editar','Editar configuración'),
(14,'respaldos.gestionar','Gestionar copias de seguridad'),
(16,'vecinos.eliminar','Eliminar vecinos'),
(17,'incidentes.editar','Editar incidentes'),
(18,'incidentes.eliminar','Eliminar incidentes'),
(19,'personal.eliminar','Eliminar personal'),
(20,'equipos.eliminar','Eliminar equipos'),
(21,'moviles.eliminar','Eliminar móviles'),
(22,'dashboard.ver','Ver dashboard'),
(31,'intervenciones.ver','Ver intervenciones'),
(33,'panel_operativo.ver','Ver panel operativo'),
(34,'moviles.ver','Ver móviles'),
(35,'moviles.gestionar','Gestionar móviles'),
(37,'personal.ver','Ver personal'),
(38,'personal.gestionar','Gestionar personal'),
(40,'equipos.ver','Ver equipos'),
(41,'equipos.gestionar','Gestionar equipos'),
(51,'barrios.ver','Ver barrios'),
(52,'barrios.gestionar','Gestionar barrios (ABM + GeoJSON)');
/*!40000 ALTER TABLE `permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal`
--

DROP TABLE IF EXISTS `personal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre_completo` varchar(120) NOT NULL,
  `legajo` varchar(30) DEFAULT NULL,
  `cargo` varchar(60) DEFAULT NULL,
  `turno` varchar(30) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal`
--

LOCK TABLES `personal` WRITE;
/*!40000 ALTER TABLE `personal` DISABLE KEYS */;
INSERT INTO `personal` VALUES
(1,'Araceli Abigail Moyano','','Operadora','Rotativo',1),
(2,'felipe antonio siwonia','','Chofer','Rotativo',1);
/*!40000 ALTER TABLE `personal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `respaldos`
--

DROP TABLE IF EXISTS `respaldos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `respaldos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre_archivo` varchar(255) NOT NULL,
  `tamano_bytes` bigint(20) unsigned DEFAULT NULL,
  `tipo` enum('automatico','manual') NOT NULL,
  `estado` enum('ok','error') NOT NULL DEFAULT 'ok',
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  `id_usuario` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `respaldos`
--

LOCK TABLES `respaldos` WRITE;
/*!40000 ALTER TABLE `respaldos` DISABLE KEYS */;
/*!40000 ALTER TABLE `respaldos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_roles_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'Administrador','Acceso total al sistema'),
(2,'Operador','Operador de guardia');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sectores`
--

DROP TABLE IF EXISTS `sectores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sectores` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_barrio` int(10) unsigned NOT NULL,
  `nombre` varchar(120) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sectores_barrio` (`id_barrio`),
  CONSTRAINT `fk_sectores_barrio` FOREIGN KEY (`id_barrio`) REFERENCES `barrios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sectores`
--

LOCK TABLES `sectores` WRITE;
/*!40000 ALTER TABLE `sectores` DISABLE KEYS */;
/*!40000 ALTER TABLE `sectores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario` varchar(60) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nombre_completo` varchar(120) NOT NULL,
  `id_rol` int(10) unsigned NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  `ultimo_acceso` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_usuarios_usuario` (`usuario`),
  KEY `fk_usuarios_rol` (`id_rol`),
  CONSTRAINT `fk_usuarios_rol` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES
(1,'admin','$2y$12$KdV/67sCzKAOPMRShj0b7uhmeZ2tGb7UFNx3bxysHocfgY8FbS64u','Administrador inicial',1,1,'2026-11-02 02:44:36',NULL),
(3,'Ara','$2y$12$qBefP/qtwthiLH.lU6qfqu8sxDxrMYvsJY0tAXchbS3sImGOSU0QK','Araceli',2,1,'2026-11-02 03:03:11',NULL);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios_permisos`
--

DROP TABLE IF EXISTS `usuarios_permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios_permisos` (
  `id_usuario` int(10) unsigned NOT NULL,
  `id_permiso` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_usuario`,`id_permiso`),
  KEY `fk_up_permiso` (`id_permiso`),
  CONSTRAINT `fk_up_permiso` FOREIGN KEY (`id_permiso`) REFERENCES `permisos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_up_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios_permisos`
--

LOCK TABLES `usuarios_permisos` WRITE;
/*!40000 ALTER TABLE `usuarios_permisos` DISABLE KEYS */;
INSERT INTO `usuarios_permisos` VALUES
(1,1),
(1,2),
(1,3),
(1,4),
(1,5),
(1,6),
(1,7),
(1,8),
(1,9),
(1,10),
(1,11),
(1,12),
(1,13),
(1,14),
(1,16),
(1,17),
(1,18),
(1,19),
(1,20),
(1,21),
(1,22),
(1,31),
(1,33),
(1,34),
(1,35),
(1,37),
(1,38),
(1,40),
(1,41),
(1,51),
(1,52),
(3,1),
(3,2),
(3,3),
(3,4),
(3,5),
(3,6),
(3,9),
(3,10),
(3,17),
(3,22),
(3,31),
(3,34),
(3,37),
(3,40);
/*!40000 ALTER TABLE `usuarios_permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vecinos`
--

DROP TABLE IF EXISTS `vecinos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vecinos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  `apellido` varchar(80) NOT NULL,
  `dni` varchar(15) NOT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `numero` varchar(20) DEFAULT NULL,
  `id_barrio` int(10) unsigned DEFAULT NULL,
  `contacto_emergencia` varchar(120) DEFAULT NULL,
  `telefono_emergencia` varchar(30) DEFAULT NULL,
  `observaciones` text DEFAULT NULL,
  `id_operador_alta` int(10) unsigned DEFAULT NULL,
  `fecha_alta` datetime NOT NULL DEFAULT current_timestamp(),
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_vecinos_dni` (`dni`),
  KEY `fk_vecinos_barrio` (`id_barrio`),
  CONSTRAINT `fk_vecinos_barrio` FOREIGN KEY (`id_barrio`) REFERENCES `barrios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vecinos`
--

LOCK TABLES `vecinos` WRITE;
/*!40000 ALTER TABLE `vecinos` DISABLE KEYS */;
INSERT INTO `vecinos` VALUES
(1,'a','a','46658101','22222222','2005-02-08','333333333333','333333333',6,'333333','33333333','wsssss',3,'2026-11-02 03:06:19',1),
(2,'felipe','siwonia','11111111','11111111',NULL,'Palo Amarillo','1393',8,'','11111111','11111111',3,'2026-11-02 04:35:41',1);
/*!40000 ALTER TABLE `vecinos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-02  6:35:58
