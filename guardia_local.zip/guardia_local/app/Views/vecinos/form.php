<h3><?= !empty($vecino['id']) ? 'Editar vecino' : 'Nuevo vecino' ?></h3>
<?php if (!empty($errors)): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $e) echo "<li>".View::e($e)."</li>"; ?></ul></div><?php endif; ?>
<form method="post" action="<?= APP_URL ?>vecinos/<?= !empty($vecino['id']) ? 'actualizar' : 'guardar' ?>" class="bg-white p-3 rounded">
  <?= Csrf::field() ?>
  <?php if (!empty($vecino['id'])): ?>
    <input type="hidden" name="id" value="<?= $vecino['id'] ?>">
  <?php endif; ?>
  <div class="row g-2">
    <div class="col-md-4"><label>Nombre</label><input name="nombre" class="form-control" required value="<?= View::e($vecino['nombre']??'') ?>"></div>
    <div class="col-md-4"><label>Apellido</label><input name="apellido" class="form-control" required value="<?= View::e($vecino['apellido']??'') ?>"></div>
    <div class="col-md-4"><label>DNI</label><input name="dni" class="form-control" required value="<?= View::e($vecino['dni']??'') ?>"></div>
    <div class="col-md-4"><label>Teléfono</label><input name="telefono" class="form-control" required value="<?= View::e($vecino['telefono']??'') ?>"></div>
    <div class="col-md-4"><label>Fecha nac.</label><input type="date" name="fecha_nacimiento" class="form-control" value="<?= View::e($vecino['fecha_nacimiento']??'') ?>"></div>
    <div class="col-md-4"><label>Barrio</label>
      <select name="id_barrio" class="form-select">
        <option value="">-</option>
        <?php foreach ($barrios as $b): ?><option value="<?= $b['id'] ?>" <?= ($vecino['id_barrio']??'')==$b['id']?'selected':'' ?>><?= View::e($b['nombre']) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-6"><label>Dirección</label><input name="direccion" class="form-control" value="<?= View::e($vecino['direccion']??'') ?>"></div>
    <div class="col-md-2"><label>Número</label><input name="numero" class="form-control" value="<?= View::e($vecino['numero']??'') ?>"></div>
    <div class="col-md-4"><label>Contacto emergencia</label><input name="contacto_emergencia" class="form-control" value="<?= View::e($vecino['contacto_emergencia']??'') ?>"></div>
    <div class="col-md-4"><label>Tel. emergencia</label><input name="telefono_emergencia" class="form-control" value="<?= View::e($vecino['telefono_emergencia']??'') ?>"></div>
    <div class="col-12"><label>Observaciones</label><textarea name="observaciones" class="form-control"><?= View::e($vecino['observaciones']??'') ?></textarea></div>
  </div>
  <button class="btn btn-primary mt-3"><?= !empty($vecino['id']) ? '💾 Actualizar' : '➕ Crear' ?></button>
  <a href="<?= APP_URL ?>vecinos" class="btn btn-secondary mt-3">Cancelar</a>
</form>