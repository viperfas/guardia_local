<?php
declare(strict_types=1);
class Permission {
    private static array $cache = [];
    public static function has(int $userId, string $code): bool {
        if (!isset(self::$cache[$userId])) {
            $db = Database::connection();
            $stmt = $db->prepare("SELECT p.codigo FROM usuarios_permisos up
                INNER JOIN permisos p ON p.id = up.id_permiso
                WHERE up.id_usuario = ?");
            $stmt->execute([$userId]);
            self::$cache[$userId] = array_column($stmt->fetchAll(), "codigo");
        }
        return in_array($code, self::$cache[$userId], true);
    }
    public static function clearCache(?int $userId = null): void {
        if ($userId === null) self::$cache = [];
        else unset(self::$cache[$userId]);
    }
    public static function allForUser(int $userId): array {
        $db = Database::connection();
        $stmt = $db->prepare("SELECT p.codigo FROM usuarios_permisos up
            INNER JOIN permisos p ON p.id = up.id_permiso
            WHERE up.id_usuario = ?");
        $stmt->execute([$userId]);
        return array_column($stmt->fetchAll(), "codigo");
    }
}
