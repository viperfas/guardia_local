<?php
declare(strict_types=1);

class ReportesController extends Controller
{
    public function index(): void
    {
        $this->view('reportes/index', []);
    }
    
    public function periodo(): void
    {
        $db = Database::connection();
        
        $desde = $_GET['desde'] ?? date('Y-m-01', strtotime('-1 month'));
        $hasta = $_GET['hasta'] ?? date('Y-m-d');
        
        $where = "i.fecha BETWEEN ? AND ?";
        $params = [$desde, $hasta];
        
        $datos = [];
        
        $stmt = $db->prepare("SELECT COUNT(*) FROM incidentes i WHERE $where");
        $stmt->execute($params);
        $datos['total'] = (int)$stmt->fetchColumn();
        
        $stmt = $db->prepare("SELECT COUNT(*) FROM incidentes i WHERE $where AND i.prioridad = 'Crítica'");
        $stmt->execute($params);
        $datos['criticos'] = (int)$stmt->fetchColumn();
        
        $stmt = $db->prepare("SELECT COUNT(*) FROM incidentes i WHERE $where AND i.estado IN ('Resuelto','Cerrado')");
        $stmt->execute($params);
        $datos['resueltos'] = (int)$stmt->fetchColumn();
        
        $stmt = $db->prepare("SELECT b.nombre, COUNT(*) as total FROM incidentes i 
            LEFT JOIN barrios b ON b.id=i.id_barrio WHERE $where 
            GROUP BY b.id,b.nombre ORDER BY total DESC LIMIT 10");
        $stmt->execute($params);
        $datos['por_barrio'] = $stmt->fetchAll();
        
        $stmt = $db->prepare("SELECT c.nombre, COUNT(*) as total FROM incidentes i 
            LEFT JOIN categorias_incidentes c ON c.id=i.id_categoria WHERE $where 
            GROUP BY c.id,c.nombre ORDER BY total DESC LIMIT 10");
        $stmt->execute($params);
        $datos['por_categoria'] = $stmt->fetchAll();
        
        $stmt = $db->prepare("SELECT i.prioridad, COUNT(*) as total FROM incidentes i 
            WHERE $where GROUP BY i.prioridad");
        $stmt->execute($params);
        $datos['por_prioridad'] = $stmt->fetchAll();
        
        $stmt = $db->prepare("SELECT i.estado, COUNT(*) as total FROM incidentes i 
            WHERE $where GROUP BY i.estado");
        $stmt->execute($params);
        $datos['por_estado'] = $stmt->fetchAll();
        
        $stmt = $db->prepare("SELECT DAYNAME(i.fecha) as dia, COUNT(*) as total FROM incidentes i 
            WHERE $where GROUP BY DAYNAME(i.fecha),DAYOFWEEK(i.fecha) ORDER BY DAYOFWEEK(i.fecha)");
        $stmt->execute($params);
        $datos['por_dia'] = $stmt->fetchAll();
        
        $stmt = $db->prepare("SELECT HOUR(i.hora) as hora, COUNT(*) as total FROM incidentes i 
            WHERE $where GROUP BY HOUR(i.hora) ORDER BY hora");
        $stmt->execute($params);
        $datos['por_hora'] = $stmt->fetchAll();
        
        $this->view('reportes/periodo', [
            'datos' => $datos,
            'desde' => $desde,
            'hasta' => $hasta
        ]);
    }
    
    public function formPdf(): void
    {
        $this->view('reportes/generar_pdf', []);
    }
    
    public function datosPdf(): void
    {
        $db = Database::connection();
        
        $desde = $_GET['desde'] ?? date('Y-m-01', strtotime('-1 month'));
        $hasta = $_GET['hasta'] ?? date('Y-m-d');
        
        $where = "i.fecha BETWEEN ? AND ?";
        $params = [$desde, $hasta];
        
        $datos = [];
        
        $stmt = $db->prepare("SELECT b.nombre, COUNT(*) as total FROM incidentes i 
            LEFT JOIN barrios b ON b.id=i.id_barrio WHERE $where 
            GROUP BY b.id,b.nombre ORDER BY total DESC LIMIT 10");
        $stmt->execute($params);
        $datos['por_barrio'] = $stmt->fetchAll();
        
        $stmt = $db->prepare("SELECT i.prioridad, COUNT(*) as total FROM incidentes i 
            WHERE $where GROUP BY i.prioridad");
        $stmt->execute($params);
        $datos['por_prioridad'] = $stmt->fetchAll();
        
        $stmt = $db->prepare("SELECT HOUR(i.hora) as hora, COUNT(*) as total FROM incidentes i 
            WHERE $where GROUP BY HOUR(i.hora) ORDER BY hora");
        $stmt->execute($params);
        $datos['por_hora'] = $stmt->fetchAll();
        
        $this->json($datos);
    }
    
    public function generarPdf(): void
    {
        $db = Database::connection();
        
        $desde = $_REQUEST['desde'] ?? date('Y-m-01', strtotime('-1 month'));
        $hasta = $_REQUEST['hasta'] ?? date('Y-m-d');
        $titulo = $_REQUEST['titulo'] ?? 'Informe Estadístico';
        $incluirIa = isset($_REQUEST['incluir_ia']) && $_REQUEST['incluir_ia'] === '1';
        $graficosJson = $_REQUEST['graficos'] ?? '[]';
        $graficos = json_decode($graficosJson, true) ?: [];
        
        $where = "i.fecha BETWEEN ? AND ?";
        $params = [$desde, $hasta];
        
        $datos = [];
        $datos['municipio'] = 'Guardia Local de Villa Giardino';
        
        $stmt = $db->prepare("SELECT COUNT(*) FROM incidentes i WHERE $where");
        $stmt->execute($params);
        $datos['total'] = (int)$stmt->fetchColumn();
        
        $stmt = $db->prepare("SELECT COUNT(*) FROM incidentes i WHERE $where AND i.prioridad = 'Crítica'");
        $stmt->execute($params);
        $datos['criticos'] = (int)$stmt->fetchColumn();
        
        $stmt = $db->prepare("SELECT COUNT(*) FROM incidentes i WHERE $where AND i.estado IN ('Resuelto','Cerrado')");
        $stmt->execute($params);
        $datos['resueltos'] = (int)$stmt->fetchColumn();
        
        $stmt = $db->prepare("SELECT b.nombre, COUNT(*) as total FROM incidentes i 
            LEFT JOIN barrios b ON b.id=i.id_barrio WHERE $where 
            GROUP BY b.id,b.nombre ORDER BY total DESC LIMIT 10");
        $stmt->execute($params);
        $datos['por_barrio'] = $stmt->fetchAll();
        
        if (!empty($datos['por_barrio'])) {
            $datos['barrio_top'] = $datos['por_barrio'][0]['nombre'];
        }
        
        $stmt = $db->prepare("SELECT c.nombre, COUNT(*) as total FROM incidentes i 
            LEFT JOIN categorias_incidentes c ON c.id=i.id_categoria WHERE $where 
            GROUP BY c.id,c.nombre ORDER BY total DESC LIMIT 10");
        $stmt->execute($params);
        $datos['por_categoria'] = $stmt->fetchAll();
        
        $stmt = $db->prepare("SELECT i.prioridad, COUNT(*) as total FROM incidentes i 
            WHERE $where GROUP BY i.prioridad");
        $stmt->execute($params);
        $datos['por_prioridad'] = $stmt->fetchAll();
        
        $stmt = $db->prepare("SELECT i.estado, COUNT(*) as total FROM incidentes i 
            WHERE $where GROUP BY i.estado");
        $stmt->execute($params);
        $datos['por_estado'] = $stmt->fetchAll();
        
        $stmt = $db->prepare("SELECT DAYNAME(i.fecha) as dia, COUNT(*) as total FROM incidentes i 
            WHERE $where GROUP BY DAYNAME(i.fecha),DAYOFWEEK(i.fecha) ORDER BY DAYOFWEEK(i.fecha)");
        $stmt->execute($params);
        $datos['por_dia'] = $stmt->fetchAll();
        
        $stmt = $db->prepare("SELECT HOUR(i.hora) as hora, COUNT(*) as total FROM incidentes i 
            WHERE $where GROUP BY HOUR(i.hora) ORDER BY hora");
        $stmt->execute($params);
        $datos['por_hora'] = $stmt->fetchAll();
        
        if ($incluirIa && class_exists('AiService') && AiService::isAvailable()) {
            $prompt = "Genera un análisis ejecutivo conciso (máximo 300 palabras) sobre los siguientes datos:\n" . 
                     json_encode($datos, JSON_UNESCAPED_UNICODE);
            $datos['informe_ia'] = AiService::consultarDatos($prompt, []);
        }
        
        if (class_exists('Audit')) {
            Audit::log('generar_pdf', 'reportes', "Período: $desde a $hasta");
        }
        
        require APP_PATH . 'Views/reportes/pdf_print.php';
        exit;
    }

    public function barrio(): void
    {
        $idBarrio = (int)($_GET['id_barrio'] ?? 0);
        $desde = $_GET['desde'] ?? date('Y-m-01', strtotime('-1 month'));
        $hasta = $_GET['hasta'] ?? date('Y-m-d');
        
        $this->view('reportes/barrio', [
            'id_barrio' => $idBarrio,
            'desde' => $desde,
            'hasta' => $hasta
        ]);
    }

    public function categoria(): void
    {
        $idCategoria = (int)($_GET['id_categoria'] ?? 0);
        $desde = $_GET['desde'] ?? date('Y-m-01', strtotime('-1 month'));
        $hasta = $_GET['hasta'] ?? date('Y-m-d');
        
        $this->view('reportes/categoria', [
            'id_categoria' => $idCategoria,
            'desde' => $desde,
            'hasta' => $hasta
        ]);
    }
}
