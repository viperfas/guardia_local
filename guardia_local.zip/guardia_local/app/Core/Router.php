<?php
declare(strict_types=1);
class Router {
    private static array $routes = [];
    public static function add(string $path, string $action, array $opts=[]): void {
        self::$routes[$path] = ["action"=>$action,"opts"=>$opts];
    }
    public static function dispatch(string $url): void {
        $url = trim($url,"/");
        if (!isset(self::$routes[$url])) { http_response_code(404); echo "<h1>404</h1>"; return; }
        $route = self::$routes[$url]; $opts = $route["opts"];
        if (isset($opts["method"]) && strtoupper($opts["method"]) !== $_SERVER["REQUEST_METHOD"]) { http_response_code(405); return; }
        if (!empty($opts["auth"]) && empty($_SESSION["user_id"])) { header("Location: ".APP_URL."login"); exit; }
        // Validación de permisos granulares
        if (!empty($opts["perm"]) && !empty($_SESSION["user_id"])) {
            if (!Permission::has($_SESSION["user_id"], $opts["perm"])) {
                http_response_code(403);
                echo "<h1>403 — Sin permisos</h1><p>No tenés permiso para: <strong>".$opts["perm"]."</strong></p>";
                echo "<p><a href='".APP_URL."dashboard'>Volver al inicio</a></p>";
                return;
            }
        }
        [$ctrl,$method] = explode("@", $route["action"]);
        $file = APP_PATH."Controllers/$ctrl.php";
        if (!file_exists($file)) { http_response_code(500); echo "Controller missing: $ctrl"; return; }
        require_once $file;
        $c = new $ctrl();
        if (!method_exists($c,$method)) { http_response_code(500); echo "Method missing: $method"; return; }
        $c->$method();
    }
}
