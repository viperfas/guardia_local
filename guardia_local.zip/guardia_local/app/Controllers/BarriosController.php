<?php
declare(strict_types=1);

class BarriosController extends Controller
{
    public function index(): void
    {
        $db = Database::connection();
        $barrios = $db->query("SELECT b.*, 
            (SELECT COUNT(*) FROM incidentes i WHERE i.id_barrio=b.id) AS total_incidentes,
            (SELECT COUNT(*) FROM incidentes i WHERE i.id_barrio=b.id AND i.prioridad='Crítica') AS criticos
            FROM barrios b ORDER BY b.nombre")->fetchAll();
        $this->view("barrios/index", ["barrios" => $barrios]);
    }
    
    public function create(): void
    {
        $this->view("barrios/form", ["barrio" => null]);
    }
    
    public function store(): void
    {
        $this->requirePost();
        $d = $_POST;
        $db = Database::connection();
        
        $geojsonLimpio = null;
        if (!empty($d["geojson"])) {
            $val = GeoJsonValidator::validar($d["geojson"]);
            if (!$val["valido"]) {
                $_SESSION["error"] = "GeoJSON inválido: " . $val["error"];
                $this->redirect("barrios/crear");
                return;
            }
            $geojsonLimpio = GeoJsonValidator::normalizar($d["geojson"]);
        }
        
        $stmt = $db->prepare("INSERT INTO barrios (nombre, descripcion, geojson, activo) VALUES (?,?,?,1)");
        $stmt->execute([$d["nombre"], $d["descripcion"] ?? null, $geojsonLimpio]);
        $id = (int)$db->lastInsertId();
        
        if ($geojsonLimpio) {
            $db->prepare("INSERT INTO barrios_historial (id_barrio, id_usuario, tipo_operacion, geojson_nuevo, nombre_nuevo, observaciones)
                VALUES (?,?,?,?,?,?)")->execute([$id, $_SESSION["user_id"], "alta", $geojsonLimpio, $d["nombre"], $d["descripcion"] ?? null]);
        }
        
        Audit::log("alta_barrio", "barrios", (string)$id);
        $_SESSION["ok"] = "Barrio creado correctamente";
        $this->redirect("barrios");
    }
    
    public function edit(): void
    {
        $id = (int)($_GET["id"] ?? 0);
        $db = Database::connection();
        $stmt = $db->prepare("SELECT * FROM barrios WHERE id=?");
        $stmt->execute([$id]);
        $barrio = $stmt->fetch();
        if (!$barrio) {
            $this->redirect("barrios");
            return;
        }
        $this->view("barrios/form", ["barrio" => $barrio]);
    }
    
    public function update(): void
    {
        $this->requirePost();
        $d = $_POST;
        $id = (int)$d["id"];
        $db = Database::connection();
        
        $stmt = $db->prepare("SELECT nombre, geojson FROM barrios WHERE id=?");
        $stmt->execute([$id]);
        $anterior = $stmt->fetch();
        
        $geojsonLimpio = null;
        if (!empty($d["geojson"])) {
            $val = GeoJsonValidator::validar($d["geojson"]);
            if (!$val["valido"]) {
                $_SESSION["error"] = "GeoJSON inválido: " . $val["error"];
                $this->redirect("barrios/editar?id=" . $id);
                return;
            }
            $geojsonLimpio = GeoJsonValidator::normalizar($d["geojson"]);
        } elseif (isset($d["quitar_geojson"]) && $d["quitar_geojson"] === "1") {
            $geojsonLimpio = null;
        } else {
            $geojsonLimpio = $anterior["geojson"];
        }
        
        $stmt = $db->prepare("UPDATE barrios SET nombre=?, descripcion=?, geojson=? WHERE id=?");
        $stmt->execute([$d["nombre"], $d["descripcion"] ?? null, $geojsonLimpio, $id]);
        
        if ($anterior["nombre"] !== $d["nombre"] || $anterior["geojson"] !== $geojsonLimpio) {
            $db->prepare("INSERT INTO barrios_historial (id_barrio, id_usuario, tipo_operacion, geojson_anterior, geojson_nuevo, nombre_anterior, nombre_nuevo, observaciones)
                VALUES (?,?,?,?,?,?,?,?)")->execute([
                $id, $_SESSION["user_id"], "edicion",
                $anterior["geojson"], $geojsonLimpio,
                $anterior["nombre"], $d["nombre"],
                $d["descripcion"] ?? null
            ]);
        }
        
        Audit::log("edit_barrio", "barrios", (string)$id);
        $_SESSION["ok"] = "Barrio actualizado";
        $this->redirect("barrios");
    }
    
    public function delete(): void
    {
        $this->requirePost();
        $id = (int)($_POST["id"] ?? 0);
        $db = Database::connection();
        
        $tiene = $db->prepare("SELECT COUNT(*) FROM incidentes WHERE id_barrio=?");
        $tiene->execute([$id]);
        if ($tiene->fetchColumn() > 0) {
            $_SESSION["error"] = "No se puede eliminar: tiene incidentes asociados. Primero reasigná esos incidentes.";
            $this->redirect("barrios");
            return;
        }
        
        $stmt = $db->prepare("SELECT nombre, geojson FROM barrios WHERE id=?");
        $stmt->execute([$id]);
        $barrio = $stmt->fetch();
        if ($barrio) {
            $db->prepare("INSERT INTO barrios_historial (id_barrio, id_usuario, tipo_operacion, geojson_anterior, nombre_anterior, observaciones)
                VALUES (?,?,?,?,?,?)")->execute([
                $id, $_SESSION["user_id"], "baja",
                $barrio["geojson"], $barrio["nombre"], "Barrio eliminado"
            ]);
        }
        
        $db->prepare("UPDATE barrios SET activo=0 WHERE id=?")->execute([$id]);
        Audit::log("baja_barrio", "barrios", (string)$id);
        $_SESSION["ok"] = "Barrio dado de baja";
        $this->redirect("barrios");
    }
    
    public function ver(): void
    {
        $id = (int)($_GET["id"] ?? 0);
        $db = Database::connection();
        
        $stmt = $db->prepare("SELECT * FROM barrios WHERE id=?");
        $stmt->execute([$id]);
        $barrio = $stmt->fetch();
        if (!$barrio) {
            $this->redirect("barrios");
            return;
        }
        
        $stats = $db->prepare("SELECT 
            COUNT(*) AS total,
            SUM(CASE WHEN prioridad='Crítica' THEN 1 ELSE 0 END) AS criticos,
            SUM(CASE WHEN estado IN ('Resuelto','Cerrado') THEN 1 ELSE 0 END) AS resueltos
            FROM incidentes WHERE id_barrio=?");
        $stats->execute([$id]);
        $stats = $stats->fetch();
        
        $cats = $db->prepare("SELECT c.nombre, COUNT(*) AS total
            FROM incidentes i
            INNER JOIN categorias_incidentes c ON c.id=i.id_categoria
            WHERE i.id_barrio=?
            GROUP BY c.id, c.nombre ORDER BY total DESC LIMIT 10");
        $cats->execute([$id]);
        $cats = $cats->fetchAll();
        
        $evol = $db->prepare("SELECT DATE_FORMAT(fecha,'%Y-%m') AS mes, COUNT(*) AS total
            FROM incidentes WHERE id_barrio=?
            GROUP BY DATE_FORMAT(fecha,'%Y-%m') ORDER BY mes DESC LIMIT 12");
        $evol->execute([$id]);
        $evol = $evol->fetchAll();
        
        $hist = $db->prepare("SELECT h.*, u.usuario FROM barrios_historial h
            LEFT JOIN usuarios u ON u.id=h.id_usuario
            WHERE h.id_barrio=? ORDER BY h.fecha_hora DESC LIMIT 20");
        $hist->execute([$id]);
        $hist = $hist->fetchAll();
        
        $this->view("barrios/ver", [
            "barrio" => $barrio,
            "stats" => $stats,
            "categorias" => $cats,
            "evolucion" => $evol,
            "historial" => $hist
        ]);
    }
    
    public function uploadGeojson(): void
    {
        $this->requirePost();
        $id = (int)($_POST["id"] ?? 0);
        
        if (empty($_FILES["geojson_file"]) || $_FILES["geojson_file"]["error"] !== UPLOAD_ERR_OK) {
            $_SESSION["error"] = "Error al subir el archivo";
            $this->redirect("barrios/editar?id=" . $id);
            return;
        }
        
        $file = $_FILES["geojson_file"];
        $ext = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));
        if (!in_array($ext, ["geojson", "json"])) {
            $_SESSION["error"] = "El archivo debe tener extensión .geojson o .json";
            $this->redirect("barrios/editar?id=" . $id);
            return;
        }
        
        $contenido = file_get_contents($file["tmp_name"]);
        $val = GeoJsonValidator::validar($contenido);
        if (!$val["valido"]) {
            $_SESSION["error"] = "GeoJSON inválido: " . $val["error"];
            $this->redirect("barrios/editar?id=" . $id);
            return;
        }
        
        $geojsonLimpio = GeoJsonValidator::normalizar($contenido);
        $db = Database::connection();
        
        $stmt = $db->prepare("SELECT nombre, geojson FROM barrios WHERE id=?");
        $stmt->execute([$id]);
        $anterior = $stmt->fetch();
        
        $db->prepare("UPDATE barrios SET geojson=? WHERE id=?")->execute([$geojsonLimpio, $id]);
        
        $db->prepare("INSERT INTO barrios_historial (id_barrio, id_usuario, tipo_operacion, geojson_anterior, geojson_nuevo, nombre_anterior, observaciones)
            VALUES (?,?,?,?,?,?,?)")->execute([
            $id, $_SESSION["user_id"], "importacion_geojson",
            $anterior["geojson"], $geojsonLimpio, $anterior["nombre"],
            "Archivo importado: " . $file["name"]
        ]);
        
        Audit::log("import_geojson", "barrios", (string)$id);
        $_SESSION["ok"] = "GeoJSON importado correctamente (" . $val["tipo"] . ")";
        $this->redirect("barrios/editar?id=" . $id);
    }
    
    public function reasignarIncidentes(): void
    {
        $this->requirePost();
        $barrioOrigen = (int)($_POST["barrio_origen"] ?? 0);
        $barrioDestino = (int)($_POST["barrio_destino"] ?? 0);
        
        if ($barrioOrigen === $barrioDestino) {
            $_SESSION["error"] = "Los barrios deben ser diferentes";
            $this->redirect("barrios");
            return;
        }
        
        $db = Database::connection();
        $stmt = $db->prepare("UPDATE incidentes SET id_barrio=? WHERE id_barrio=?");
        $stmt->execute([$barrioDestino, $barrioOrigen]);
        $afectados = $stmt->rowCount();
        
        Audit::log("reasignar_incidentes", "barrios", "De $barrioOrigen a $barrioDestino: $afectados incidentes");
        $_SESSION["ok"] = "$afectados incidentes reasignados correctamente";
        $this->redirect("barrios");
    }

}