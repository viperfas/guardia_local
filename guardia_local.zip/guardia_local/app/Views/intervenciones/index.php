<div class="d-flex justify-content-between mb-3">
  <h3>Intervenciones</h3>
  <a href="<?= APP_URL ?>panel_operativo" class="btn btn-warning">📡 Panel operativo</a>
</div>
<table class="table table-sm bg-white">
  <thead><tr><th>#</th><th>Despacho</th><th>Incidente</th><th>Móvil</th><th>Equipo</th><th>Estado</th><th>Acciones</th></tr></thead>
  <tbody>
  <?php foreach ($intervenciones as $i): ?>
    <tr>
      <td><?= (int)$i["id"] ?></td>
      <td><?= View::e($i["fecha_hora_despacho"]) ?></td>
      <td><small><?= View::e(substr($i["incidente_desc"]??"",0,60)) ?></small></td>
      <td><?= View::e($i["movil_numero"]??"-") ?></td>
      <td><?= View::e($i["equipo_nombre"]??"-") ?></td>
      <td>
        <?php
        $colors = ["Asignado"=>"warning","En intervención"=>"primary","Derivado"=>"info","Resuelto"=>"success","Cerrado"=>"secondary"];
        $c = $colors[$i["estado"]] ?? "secondary";
        ?>
        <span class="badge bg-<?= $c ?>"><?= View::e($i["estado"]) ?></span>
      </td>
      <td>
        <a href="<?= APP_URL ?>intervenciones/ver?id=<?= $i["id"] ?>" class="btn btn-sm btn-outline-primary">👁️</a>
        <a href="<?= APP_URL ?>intervenciones/editar?id=<?= $i["id"] ?>" class="btn btn-sm btn-outline-secondary">✏️</a>
        <a href="<?= APP_URL ?>reportes/intervencion?id=<?= $i["id"] ?>" target="_blank" class="btn btn-sm btn-outline-info">📄</a>
        <form method="post" action="<?= APP_URL ?>intervenciones/eliminar" style="display:inline" onsubmit="return confirm('¿Eliminar intervención?')">
          <?= Csrf::field() ?><input type="hidden" name="id" value="<?= $i["id"] ?>">
          <button class="btn btn-sm btn-outline-danger">🗑️</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>