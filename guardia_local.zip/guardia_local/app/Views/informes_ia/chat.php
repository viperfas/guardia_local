<div class="d-flex justify-content-between mb-3">
  <h3>💬 Chat con IA</h3>
  <a href="<?= APP_URL ?>informes_ia" class="btn btn-outline-secondary">← Volver a informes</a>
</div>

<?php if (empty($ia_disponible)): ?>
<div class="alert alert-warning">
  ⚠️ La IA no está disponible. Configurá la conexión en 
  <a href="<?= APP_URL ?>configuracion">⚙️ Configuración</a>.
</div>
<?php endif; ?>

<div class="card bg-white p-3">
  <div id="chatContainer" style="height:500px;overflow-y:auto;border:1px solid #ddd;border-radius:5px;padding:15px;background:#f8f9fa">
    <div class="text-center text-muted">
      <p><strong>👋 ¡Hola!</strong> Soy tu asistente de la Guardia Local.</p>
      <p>Podés preguntarme sobre incidentes, barrios, tendencias o cualquier dato del sistema.</p>
      <p class="small">Ejemplos: <em>"¿Cuál fue el barrio con más incidentes este mes?"</em></p>
    </div>
  </div>
  
  <form id="chatForm" class="mt-3">
    <div class="input-group">
      <input type="text" id="mensajeInput" class="form-control" 
             placeholder="Escribí tu pregunta..." autocomplete="off"
             <?= empty($ia_disponible) ? 'disabled' : '' ?>>
      <button type="submit" class="btn btn-primary" 
              <?= empty($ia_disponible) ? 'disabled' : '' ?>>
        📤 Enviar
      </button>
    </div>
  </form>
</div>

<script>
const form = document.getElementById('chatForm');
const input = document.getElementById('mensajeInput');
const container = document.getElementById('chatContainer');
let historial = [];

function agregarMensaje(texto, tipo) {
  const div = document.createElement('div');
  div.className = 'mb-3';
  
  const color = tipo === 'user' ? '#0d6efd' : '#198754';
  const icono = tipo === 'user' ? '👤' : '🤖';
  const align = tipo === 'user' ? 'text-end' : 'text-start';
  const bg = tipo === 'user' ? '#e7f1ff' : '#d1e7dd';
  
  // Convertir Markdown básico
  let html = texto;
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
  html = html.replace(/\n/g, '<br>');
  
  div.innerHTML = `
    <div class="${align}">
      <div style="display:inline-block;background:${bg};padding:10px 15px;border-radius:10px;max-width:80%;text-align:left">
        <small style="color:${color}">${icono} ${tipo === 'user' ? 'Vos' : 'IA'}</small><br>
        ${html}
      </div>
    </div>
  `;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const mensaje = input.value.trim();
  if (!mensaje) return;
  
  agregarMensaje(mensaje, 'user');
  input.value = '';
  input.disabled = true;
  
  // Indicador de "escribiendo..."
  const loading = document.createElement('div');
  loading.id = 'loading';
  loading.className = 'text-muted mb-3';
  loading.innerHTML = '<em>🤖 Pensando...</em>';
  container.appendChild(loading);
  container.scrollTop = container.scrollHeight;
  
  try {
    const formData = new FormData();
    formData.append('mensaje', mensaje);
    formData.append('historial', JSON.stringify(historial));
    formData.append('csrf_token', document.querySelector('[name="csrf_token"]')?.value || '');
    
    const response = await fetch('<?= APP_URL ?>informes_ia/chat', {
      method: 'POST',
      body: formData
    });
    
    const data = await response.json();
    
    document.getElementById('loading')?.remove();
    
    if (data.error) {
      agregarMensaje('❌ Error: ' + data.error, 'assistant');
    } else {
      agregarMensaje(data.respuesta, 'assistant');
      historial = data.historial || [];
    }
  } catch (err) {
    document.getElementById('loading')?.remove();
    agregarMensaje('❌ Error de conexión: ' + err.message, 'assistant');
  }
  
  input.disabled = false;
  input.focus();
});
</script>