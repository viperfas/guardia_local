<?php
declare(strict_types=1);

function hasPerm(string $code): bool {
    if (empty($_SESSION['user_id'])) return false;
    return Permission::has((int)$_SESSION['user_id'], $code);
}

function hasAnyPerm(array $codes): bool {
    foreach ($codes as $code) {
        if (hasPerm($code)) return true;
    }
    return false;
}

function hasAllPerms(array $codes): bool {
    foreach ($codes as $code) {
        if (!hasPerm($code)) return false;
    }
    return true;
}