<h3>📡 Panel operativo</h3>
<p class="text-muted">Actualización automática cada 15 segundos.</p>
<div class="row g-3 mb-3">
  <div class="col-md-3"><div class="card text-bg-warning p-3"><h6>Pendientes</h6><h2><?= count($pendientes) ?></h2></div></div>
  <div class="col-md-3"><div class="card text-bg-primary p-3"><h6>Activas</h6><h2><?= count($activas) ?></h2></div></div>
  <div class="col-md-3"><div class="card text-bg-success p-3"><h6>Móviles disp.</h6><h2><?= count(array_filter($moviles, fn($m)=>$m["estado"]=="Disponible")) ?></h2></div></div>
  <div class="col-md-3"><div class="card text-bg-danger p-3"><h6>Críticas</h6><h2><?= count(array_filter($pendientes, fn($p)=>$p["prioridad"]=="Crítica")) ?></h2></div></div>
</div>

<div class="row">
  <div class="col-md-6">
    <div class="card bg-white p-3 mb-3">
      <h5>🚨 Incidentes pendientes de asignación</h5>
      <table class="table table-sm">
        <thead><tr><th>Hora</th><th>Categoría</th><th>Barrio</th><th>Prioridad</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($pendientes as $p): ?>
          <tr>
            <td><?= View::e(substr($p["hora"],0,5)) ?></td>
            <td><?= View::e($p["categoria"]?:"-") ?></td>
            <td><?= View::e($p["barrio"]?:"-") ?></td>
            <td><span class="badge bg-<?= $p["prioridad"]=="Crítica"?"danger":($p["prioridad"]=="Alta"?"warning":"secondary") ?>"><?= View::e($p["prioridad"]) ?></span></td>
            <td><a href="<?= APP_URL ?>intervenciones/despachar?incidente=<?= $p["id"] ?>" class="btn btn-sm btn-danger">Despachar</a></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$pendientes): ?><tr><td colspan="5" class="text-muted text-center">Sin incidentes pendientes</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card bg-white p-3 mb-3">
      <h5>🚓 Intervenciones activas</h5>
      <table class="table table-sm">
        <thead><tr><th>Móvil</th><th>Estado</th><th>Tiempo</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($activas as $a): ?>
          <tr>
            <td><?= View::e($a["movil_numero"]?:"-") ?></td>
            <td><span class="badge bg-<?= $a["estado"]=="En intervención"?"primary":"warning" ?>"><?= View::e($a["estado"]) ?></span></td>
            <td><?= (int)$a["minutos_transcurridos"] ?> min</td>
            <td><a href="<?= APP_URL ?>intervenciones/ver?id=<?= $a["id"] ?>" class="btn btn-sm btn-outline-primary">Ver</a></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$activas): ?><tr><td colspan="4" class="text-muted text-center">Sin intervenciones activas</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="card bg-white p-3">
  <h5>Estado de móviles</h5>
  <div class="row">
    <?php foreach ($moviles as $m):
      $colors = ["Disponible"=>"success","Asignado"=>"warning","En servicio"=>"primary","Fuera de servicio"=>"secondary","En mantenimiento"=>"danger"];
      $c = $colors[$m["estado"]] ?? "secondary";
    ?>
      <div class="col-md-2 mb-2">
        <div class="border p-2 text-center">
          <strong><?= View::e($m["numero_interno"]) ?></strong><br>
          <span class="badge bg-<?= $c ?>"><?= View::e($m["estado"]) ?></span>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<script>
setTimeout(()=>location.reload(), 15000);
</script>
