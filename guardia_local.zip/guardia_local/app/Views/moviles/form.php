<h3><?= $movil && isset($movil["id"]) ? "Editar móvil" : "Nuevo móvil" ?></h3>
<form method="post" action="<?= APP_URL ?>moviles/<?= $movil && isset($movil["id"]) ? "actualizar" : "guardar" ?>" class="bg-white p-3 rounded">
  <?= Csrf::field() ?>
  <?php if ($movil && isset($movil["id"])): ?><input type="hidden" name="id" value="<?= $movil["id"] ?>"><?php endif; ?>
  <div class="row g-2">
    <div class="col-md-3"><label>N° Interno</label><input name="numero_interno" class="form-control" required value="<?= View::e($movil["numero_interno"]??"") ?>"></div>
    <div class="col-md-3"><label>Tipo</label><input name="tipo" class="form-control" placeholder="Ej: Camioneta" value="<?= View::e($movil["tipo"]??"") ?>"></div>
    <div class="col-md-3"><label>Marca</label><input name="marca" class="form-control" value="<?= View::e($movil["marca"]??"") ?>"></div>
    <div class="col-md-3"><label>Modelo</label><input name="modelo" class="form-control" value="<?= View::e($movil["modelo"]??"") ?>"></div>
    <div class="col-md-3"><label>Patente</label><input name="patente" class="form-control" value="<?= View::e($movil["patente"]??"") ?>"></div>
    <div class="col-md-3"><label>Estado</label>
      <select name="estado" class="form-select">
        <?php foreach (["Disponible","Asignado","En servicio","Fuera de servicio","En mantenimiento"] as $e): ?>
          <option <?= ($movil["estado"]??"Disponible")==$e?"selected":"" ?>><?= $e ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3"><label>Fecha incorporación</label><input type="date" name="fecha_incorporacion" class="form-control" value="<?= View::e($movil["fecha_incorporacion"]??"") ?>"></div>
    <div class="col-12"><label>Observaciones</label><textarea name="observaciones" class="form-control"><?= View::e($movil["observaciones"]??"") ?></textarea></div>
  </div>
  <button class="btn btn-primary mt-3">Guardar</button>
  <a href="<?= APP_URL ?>moviles" class="btn btn-secondary mt-3">Cancelar</a>
</form>
