<h3 class="mb-4">📜 Auditoría del sistema</h3>
<div class="card bg-white p-3 mb-3">
  <h5>Filtros</h5>
  <form method="get" class="row g-2">
    <div class="col-md-2"><label>Desde</label><input type="date" name="desde" class="form-control" value="<?= View::e($desde) ?>"></div>
    <div class="col-md-2"><label>Hasta</label><input type="date" name="hasta" class="form-control" value="<?= View::e($hasta) ?>"></div>
    <div class="col-md-2"><label>Tipo</label><select name="tipo" class="form-select"><option value="">Todos</option><?php foreach ($tipos as $t): ?><option <?= $tipo==$t?"selected":"" ?>><?= View::e($t) ?></option><?php endforeach; ?></select></div>
    <div class="col-md-2"><label>Módulo</label><select name="modulo" class="form-select"><option value="">Todos</option><?php foreach ($modulos as $m): ?><option <?= $modulo==$m?"selected":"" ?>><?= View::e($m) ?></option><?php endforeach; ?></select></div>
    <div class="col-md-2"><label>Usuario</label><select name="usuario" class="form-select"><option value="">Todos</option><?php foreach ($usuarios as $u): ?><option <?= $usuario==$u?"selected":"" ?>><?= View::e($u) ?></option><?php endforeach; ?></select></div>
    <div class="col-md-2 d-flex align-items-end"><button class="btn btn-primary w-100">Filtrar</button></div>
  </form>
  <div class="mt-2">
    <a href="<?= APP_URL ?>reportes/csv?tipo=auditoria&desde=<?= urlencode($desde) ?>&hasta=<?= urlencode($hasta) ?>" class="btn btn-sm btn-success">⬇️ Exportar CSV</a>
    <small class="text-muted ms-2">Total: <?= count($logs) ?></small>
  </div>
</div>
<div class="card bg-white p-3">
  <table class="table table-sm table-striped">
    <thead><tr><th>Fecha</th><th>Usuario</th><th>IP</th><th>Tipo</th><th>Módulo</th><th>Registro</th></tr></thead>
    <tbody>
    <?php foreach ($logs as $l): ?>
      <tr>
        <td><small><?= View::e($l["fecha_hora"]) ?></small></td>
        <td><?= View::e($l["usuario"]??"sistema") ?></td>
        <td><small><?= View::e($l["ip"]) ?></small></td>
        <td><span class="badge bg-secondary"><?= View::e($l["tipo_operacion"]) ?></span></td>
        <td><?= View::e($l["modulo"]) ?></td>
        <td><small><?= View::e($l["registro_afectado"]??"") ?></small></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>