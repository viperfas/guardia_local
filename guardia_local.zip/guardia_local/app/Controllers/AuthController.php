<?php
declare(strict_types=1);
class AuthController extends Controller {
    public function login(): void {
        if (!empty($_SESSION["user_id"])) $this->redirect("dashboard");
        $this->viewPlain("auth/login", ["error"=>$_GET["error"]??null,"expired"=>isset($_GET["expired"])]);
    }
    public function process(): void {
        $this->requirePost();
        $usuario = trim($_POST["usuario"]??"");
        $password = (string)($_POST["password"]??"");
        $db = Database::connection();

        $db->prepare("INSERT INTO auditoria (fecha_hora, ip, tipo_operacion, modulo, registro_afectado)
                      VALUES (NOW(), ?, 'intento_login', 'auth', ?)")
           ->execute([$_SERVER["REMOTE_ADDR"]??"127.0.0.1", $usuario]);

        $recent = $db->prepare("SELECT COUNT(*) FROM auditoria
            WHERE tipo_operacion='intento_login' AND registro_afectado=? AND ip=?
            AND fecha_hora > DATE_SUB(NOW(), INTERVAL ? MINUTE)");
        $recent->execute([$usuario, $_SERVER["REMOTE_ADDR"]??"127.0.0.1", LOCKOUT_MINUTES]);
        if ((int)$recent->fetchColumn() >= MAX_LOGIN_ATTEMPTS) {
            Audit::log("bloqueo_login","auth",$usuario);
            $this->viewPlain("auth/login",["error"=>"Cuenta bloqueada temporalmente."]);
            return;
        }

        $stmt = $db->prepare("SELECT u.*, r.nombre AS rol FROM usuarios u
                              LEFT JOIN roles r ON r.id=u.id_rol
                              WHERE u.usuario=? AND u.activo=1");
        $stmt->execute([$usuario]);
        $user = $stmt->fetch();
        if (!$user || !password_verify($password, $user["password"])) {
            $this->viewPlain("auth/login",["error"=>"Credenciales inválidas"]); return;
        }
        Session::regenerate();
        $_SESSION["user_id"]       = (int)$user["id"];
        $_SESSION["user_name"]     = $user["nombre_completo"];
        $_SESSION["user_role"]     = $user["rol"];
        $_SESSION["last_activity"] = time();
        Audit::log("login","auth",$usuario);
        $this->redirect("dashboard");
    }
    public function logout(): void {
        Audit::log("logout","auth",$_SESSION["user_name"]??null);
        Session::destroy();
        $this->redirect("login");
    }
}
