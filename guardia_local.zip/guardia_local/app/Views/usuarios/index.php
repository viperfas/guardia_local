<div class="d-flex justify-content-between mb-3">
  <h3>Usuarios del sistema</h3>
  <div>
    <a href="<?= APP_URL ?>usuarios/permisos" class="btn btn-outline-primary">🔑 Matriz de permisos</a>
    <a href="<?= APP_URL ?>usuarios/crear" class="btn btn-primary">➕ Nuevo usuario</a>
  </div>
</div>
<table class="table table-striped bg-white">
  <thead><tr><th>Usuario</th><th>Nombre</th><th>Rol</th><th>Estado</th><th>Acciones</th></tr></thead>
  <tbody>
  <?php foreach ($usuarios as $u): ?>
    <tr class="<?= $u["activo"]?"":"table-secondary" ?>">
      <td><?= View::e($u["usuario"]) ?></td>
      <td><?= View::e($u["nombre_completo"]) ?></td>
      <td><span class="badge bg-info"><?= View::e($u["rol"]??"-") ?></span></td>
      <td><?= $u["activo"]?"<span class='badge bg-success'>Activo</span>":"<span class='badge bg-secondary'>Inactivo</span>" ?></td>
      <td>
        <a href="<?= APP_URL ?>usuarios/editar?id=<?= $u["id"] ?>" class="btn btn-sm btn-outline-primary">Editar</a>
        <?php if ($u["id"] != ($_SESSION["user_id"]??0)): ?>
          <form method="post" action="<?= APP_URL ?>usuarios/eliminar" style="display:inline" onsubmit="return confirm('¿Eliminar usuario?')">
            <?= Csrf::field() ?>
            <input type="hidden" name="id" value="<?= $u["id"] ?>">
            <button class="btn btn-sm btn-outline-danger">Dar de baja</button>
          </form>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
