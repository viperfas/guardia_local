<?php
$db = Database::connection();
$idCategoria = (int)($_GET['id_categoria'] ?? 0);
$desde = $_GET['desde'] ?? date('Y-m-01', strtotime('-1 month'));
$hasta = $_GET['hasta'] ?? date('Y-m-d');

$stmt = $db->prepare("SELECT nombre FROM categorias_incidentes WHERE id=?");
$stmt->execute([$idCategoria]);
$cat = $stmt->fetch();
$nombreCategoria = $cat['nombre'] ?? 'Categoría no encontrada';

$where = "i.fecha BETWEEN ? AND ? AND i.id_categoria=?";
$params = [$desde, $hasta, $idCategoria];

$stmt = $db->prepare("SELECT COUNT(*) FROM incidentes i WHERE $where");
$stmt->execute($params);
$total = (int)$stmt->fetchColumn();

$stmt = $db->prepare("SELECT COUNT(*) FROM incidentes i WHERE $where AND i.prioridad='Crítica'");
$stmt->execute($params);
$criticos = (int)$stmt->fetchColumn();

$stmt = $db->prepare("SELECT b.nombre, COUNT(*) as total FROM incidentes i 
    LEFT JOIN barrios b ON b.id=i.id_barrio 
    WHERE $where GROUP BY b.id,b.nombre ORDER BY total DESC");
$stmt->execute($params);
$porBarrio = $stmt->fetchAll();

$stmt = $db->prepare("SELECT i.prioridad, COUNT(*) as total FROM incidentes i 
    WHERE $where GROUP BY i.prioridad");
$stmt->execute($params);
$porPrioridad = $stmt->fetchAll();

$stmt = $db->prepare("SELECT HOUR(i.hora) as hora, COUNT(*) as total FROM incidentes i 
    WHERE $where GROUP BY HOUR(i.hora) ORDER BY hora");
$stmt->execute($params);
$porHora = $stmt->fetchAll();
?>

<h3 class="mb-3">📂 Reporte de Categoría: <?= View::e($nombreCategoria) ?></h3>

<div class="d-flex justify-content-between mb-3">
    <div>
        <span class="badge bg-primary fs-6">📅 <?= View::e($desde) ?> al <?= View::e($hasta) ?></span>
    </div>
    <div>
        <a href="<?= APP_URL ?>reportes/generar_pdf_form?desde=<?= urlencode($desde) ?>&hasta=<?= urlencode($hasta) ?>" 
           class="btn btn-success" target="_blank">
            📄 Exportar a PDF
        </a>
        <a href="<?= APP_URL ?>reportes" class="btn btn-outline-secondary">
            ← Volver
        </a>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-6">
        <div class="card bg-primary text-white text-center p-3">
            <h2 class="mb-0"><?= $total ?></h2>
            <small>Total de Incidentes</small>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card bg-danger text-white text-center p-3">
            <h2 class="mb-0"><?= $criticos ?></h2>
            <small>Incidentes Críticos</small>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-6">
        <div class="card bg-white p-3">
            <h5 class="card-title text-center">Por Barrio</h5>
            <canvas id="chartBarrio"></canvas>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card bg-white p-3">
            <h5 class="card-title text-center">Por Prioridad</h5>
            <canvas id="chartPrioridad"></canvas>
        </div>
    </div>
    <div class="col-md-12">
        <div class="card bg-white p-3">
            <h5 class="card-title text-center">Por Hora del Día</h5>
            <canvas id="chartHora"></canvas>
        </div>
    </div>
</div>

<div class="card bg-white p-3">
    <h5 class="card-title">🏘️ Por Barrio</h5>
    <table class="table table-sm table-striped">
        <thead><tr><th>Barrio</th><th class="text-end">Cantidad</th></tr></thead>
        <tbody>
            <?php foreach ($porBarrio as $row): ?>
                <tr>
                    <td><?= View::e($row['nombre'] ?? 'Sin asignar') ?></td>
                    <td class="text-end"><span class="badge bg-secondary"><?= (int)$row['total'] ?></span></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<script>
const datosBarrio = <?= json_encode($porBarrio) ?>;
const datosPrioridad = <?= json_encode($porPrioridad) ?>;
const datosHora = <?= json_encode($porHora) ?>;

if (datosBarrio.length > 0) {
    new Chart(document.getElementById('chartBarrio'), {
        type: 'bar',
        data: {
            labels: datosBarrio.map(d => d.nombre || 'Sin asignar'),
            datasets: [{
                label: 'Incidentes',
                data: datosBarrio.map(d => d.total),
                backgroundColor: 'rgba(13, 110, 253, 0.7)'
            }]
        },
        options: { responsive: true, plugins: { legend: { display: false } } }
    });
}

if (datosPrioridad.length > 0) {
    new Chart(document.getElementById('chartPrioridad'), {
        type: 'doughnut',
        data: {
            labels: datosPrioridad.map(d => d.prioridad || 'Sin asignar'),
            datasets: [{
                data: datosPrioridad.map(d => d.total),
                backgroundColor: ['#dc3545', '#fd7e14', '#ffc107', '#198754']
            }]
        },
        options: { responsive: true }
    });
}

if (datosHora.length > 0) {
    new Chart(document.getElementById('chartHora'), {
        type: 'line',
        data: {
            labels: datosHora.map(d => (d.hora < 10 ? '0' + d.hora : d.hora) + ':00'),
            datasets: [{
                label: 'Incidentes',
                data: datosHora.map(d => d.total),
                borderColor: '#198754',
                backgroundColor: 'rgba(25, 135, 84, 0.1)',
                fill: true,
                tension: 0.3
            }]
        },
        options: { 
            responsive: true,
            scales: {
                x: { title: { display: true, text: 'Hora del día' } },
                y: { beginAtZero: true, ticks: { stepSize: 1 } }
            }
        }
    });
}
</script>