<div class="d-flex justify-content-between mb-3">
  <h3>Equipos operativos</h3>
  <a href="<?= APP_URL ?>equipos/crear" class="btn btn-primary">➕ Nuevo equipo</a>
</div>
<?php if (!empty($_SESSION['error'])): ?><div class="alert alert-warning"><?= View::e($_SESSION['error']) ?></div><?php unset($_SESSION['error']); endif; ?>
<table class="table table-striped bg-white">
  <thead><tr><th>Nombre</th><th>Responsable</th><th>Móvil</th><th>Turno</th><th>Estado</th><th>Acciones</th></tr></thead>
  <tbody>
  <?php foreach ($equipos as $e): ?>
    <tr>
      <td><strong><?= View::e($e["nombre"]) ?></strong></td>
      <td><?= View::e($e["responsable"]??"-") ?></td>
      <td><?= View::e($e["movil_numero"]??"-") ?></td>
      <td><?= View::e($e["turno"]??"-") ?></td>
      <td><span class="badge bg-info"><?= View::e($e["estado"]) ?></span></td>
      <td>
        <a href="<?= APP_URL ?>equipos/editar?id=<?= $e["id"] ?>" class="btn btn-sm btn-outline-primary">✏️</a>
        <form method="post" action="<?= APP_URL ?>equipos/eliminar" style="display:inline" onsubmit="return confirm('¿Eliminar equipo?')">
          <?= Csrf::field() ?><input type="hidden" name="id" value="<?= $e["id"] ?>">
          <button class="btn btn-sm btn-outline-danger">🗑️</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>