<?php
declare(strict_types=1);
class EquiposController extends Controller {
    public function index(): void {
        $db = Database::connection();
        $equipos = $db->query("SELECT e.*, p.nombre_completo AS responsable, m.numero_interno AS movil_numero
            FROM equipos e
            LEFT JOIN personal p ON p.id = e.id_responsable
            LEFT JOIN moviles m ON m.id = e.id_movil
            ORDER BY e.nombre")->fetchAll();
        $this->view("equipos/index", ["equipos"=>$equipos]);
    }
    public function create(): void {
        $db = Database::connection();
        $personal = $db->query("SELECT id, nombre_completo FROM personal WHERE activo=1 ORDER BY nombre_completo")->fetchAll();
        $moviles = $db->query("SELECT id, numero_interno FROM moviles ORDER BY numero_interno")->fetchAll();
        $this->view("equipos/form", ["equipo"=>null,"personal"=>$personal,"moviles"=>$moviles,"integrantes"=>[]]);
    }
    public function store(): void {
        $this->requirePost();
        $d = $_POST;
        $db = Database::connection();
        $stmt = $db->prepare("INSERT INTO equipos (nombre, id_responsable, turno, id_movil, estado) VALUES (?,?,?,?,?)");
        $stmt->execute([$d["nombre"],$d["id_responsable"]?:null,$d["turno"]??null,$d["id_movil"]?:null,$d["estado"]??"Activo"]);
        $id = (int)$db->lastInsertId();
        foreach (($d["integrantes"]??[]) as $pid) {
            $db->prepare("INSERT INTO equipos_integrantes (id_equipo, id_personal) VALUES (?,?)")->execute([$id,(int)$pid]);
        }
        Audit::log("alta_equipo","equipos",(string)$id);
        $this->redirect("equipos");
    }
    public function edit(): void {
        $id = (int)($_GET["id"]??0);
        $db = Database::connection();
        $stmt = $db->prepare("SELECT * FROM equipos WHERE id=?");
        $stmt->execute([$id]);
        $equipo = $stmt->fetch();
        if (!$equipo) { $this->redirect("equipos"); return; }
        $personal = $db->query("SELECT id, nombre_completo FROM personal WHERE activo=1 ORDER BY nombre_completo")->fetchAll();
        $moviles = $db->query("SELECT id, numero_interno FROM moviles ORDER BY numero_interno")->fetchAll();
        $ints = $db->prepare("SELECT id_personal FROM equipos_integrantes WHERE id_equipo=?");
        $ints->execute([$id]);
        $integrantes = array_column($ints->fetchAll(), "id_personal");
        $this->view("equipos/form", ["equipo"=>$equipo,"personal"=>$personal,"moviles"=>$moviles,"integrantes"=>$integrantes]);
    }
    public function update(): void {
        $this->requirePost();
        $d = $_POST;
        $db = Database::connection();
        $stmt = $db->prepare("UPDATE equipos SET nombre=?, id_responsable=?, turno=?, id_movil=?, estado=? WHERE id=?");
        $stmt->execute([$d["nombre"],$d["id_responsable"]?:null,$d["turno"]??null,$d["id_movil"]?:null,$d["estado"]??"Activo",(int)$d["id"]]);
        $db->prepare("DELETE FROM equipos_integrantes WHERE id_equipo=?")->execute([$d["id"]]);
        foreach (($d["integrantes"]??[]) as $pid) {
            $db->prepare("INSERT INTO equipos_integrantes (id_equipo, id_personal) VALUES (?,?)")->execute([(int)$d["id"],(int)$pid]);
        }
        Audit::log("edit_equipo","equipos",$d["id"]);
        $this->redirect("equipos");
    }
    public function delete(): void {
        $this->requirePost();
        $id = (int)($_POST["id"]??0);
        $db = Database::connection();
        $tiene = $db->prepare("SELECT COUNT(*) FROM intervenciones WHERE id_equipo=?");
        $tiene->execute([$id]);
        if ($tiene->fetchColumn() > 0) {
            $_SESSION['error'] = "No se puede eliminar: tiene intervenciones asociadas";
            $this->redirect("equipos");
            return;
        }
        $db->prepare("DELETE FROM equipos_integrantes WHERE id_equipo=?")->execute([$id]);
        $db->prepare("DELETE FROM equipos WHERE id=?")->execute([$id]);
        Audit::log("delete_equipo","equipos",(string)$id);
        $this->redirect("equipos");
    }
}