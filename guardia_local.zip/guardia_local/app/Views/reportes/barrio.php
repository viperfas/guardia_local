<h3 class="mb-3">🏘️ Reporte por Barrio</h3>

<div class="card bg-white p-3 mb-4">
    <form method="get" action="<?= APP_URL ?>reportes/barrio" class="row g-2 align-items-end">
        <div class="col-md-8">
            <label class="form-label">Seleccionar Barrio</label>
            <select name="id" class="form-select" onchange="this.form.submit()">
                <option value="0">-- Ver listado de todos los barrios --</option>
                <?php foreach ($barrios as $b): ?>
                    <option value="<?= $b['id'] ?>" <?= $id_seleccionado == $b['id'] ? 'selected' : '' ?>>
                        <?= View::e($b['nombre']) ?> (<?= (int)$b['total'] ?> incidentes)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-4">
            <button type="submit" class="btn btn-primary w-100">🔍 Filtrar</button>
        </div>
    </form>
</div>

<?php if ($id_seleccionado == 0): ?>
    <div class="card bg-white p-3">
        <h5 class="card-title mb-3">📋 Listado General de Barrios</h5>
        <table class="table table-striped">
            <thead><tr><th>Barrio</th><th class="text-end">Total Incidentes</th></tr></thead>
            <tbody>
                <?php foreach ($barrios as $b): ?>
                    <tr style="cursor:pointer" onclick="window.location.href='<?= APP_URL ?>reportes/barrio?id=<?= $b['id'] ?>'">
                        <td><?= View::e($b['nombre']) ?></td>
                        <td class="text-end"><span class="badge bg-primary"><?= (int)$b['total'] ?></span></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php elseif ($datos): ?>
    <h4 class="mb-3">📊 Estadísticas de: <span class="text-primary"><?= View::e($datos['nombre']) ?></span></h4>
    
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card bg-primary text-white text-center p-3">
                <h2 class="mb-0"><?= (int)$datos['total'] ?></h2>
                <small>Total de Incidentes</small>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-danger text-white text-center p-3">
                <h2 class="mb-0"><?= (int)$datos['criticos'] ?></h2>
                <small>Críticos</small>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-success text-white text-center p-3">
                <h2 class="mb-0"><?= (int)$datos['resueltos'] ?></h2>
                <small>Resueltos</small>
            </div>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-md-6">
            <div class="card bg-white p-3">
                <h5>📂 Por Categoría</h5>
                <table class="table table-sm table-striped">
                    <thead><tr><th>Categoría</th><th class="text-end">Cantidad</th></tr></thead>
                    <tbody>
                        <?php if (!empty($datos['por_categoria'])): ?>
                            <?php foreach ($datos['por_categoria'] as $row): ?>
                                <tr>
                                    <td><?= View::e($row['nombre'] ?? 'Sin asignar') ?></td>
                                    <td class="text-end"><span class="badge bg-secondary"><?= (int)$row['total'] ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="2" class="text-center text-muted">Sin incidentes</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card bg-white p-3">
                <h5>📌 Por Estado</h5>
                <table class="table table-sm table-striped">
                    <thead><tr><th>Estado</th><th class="text-end">Cantidad</th></tr></thead>
                    <tbody>
                        <?php if (!empty($datos['por_estado'])): ?>
                            <?php foreach ($datos['por_estado'] as $row): ?>
                                <tr>
                                    <td><?= View::e($row['estado'] ?? 'Sin asignar') ?></td>
                                    <td class="text-end"><span class="badge bg-secondary"><?= (int)$row['total'] ?></span></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="2" class="text-center text-muted">Sin datos</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <div class="mt-3">
        <a href="<?= APP_URL ?>reportes/barrio" class="btn btn-outline-secondary">← Volver al listado general</a>
    </div>
<?php else: ?>
    <div class="alert alert-warning">No se encontraron datos para este barrio.</div>
<?php endif; ?>