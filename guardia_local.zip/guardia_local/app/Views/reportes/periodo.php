<h3 class="mb-3">📊 Reporte por Período</h3>

<div class="d-flex justify-content-between mb-3">
    <span class="badge bg-primary fs-6">📅 <?= View::e($desde) ?> al <?= View::e($hasta) ?></span>
    <a href="<?= APP_URL ?>reportes" class="btn btn-outline-secondary">← Volver</a>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card bg-primary text-white text-center p-3">
            <h2 class="mb-0"><?= (int)($datos['total'] ?? 0) ?></h2>
            <small>Total de Incidentes</small>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-danger text-white text-center p-3">
            <h2 class="mb-0"><?= (int)($datos['criticos'] ?? 0) ?></h2>
            <small>Críticos</small>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-success text-white text-center p-3">
            <h2 class="mb-0"><?= (int)($datos['resueltos'] ?? 0) ?></h2>
            <small>Resueltos</small>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-6">
        <div class="card bg-white p-3">
            <h5 class="text-center">🏘️ Incidentes por Barrio</h5>
            <canvas id="chartBarrio"></canvas>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card bg-white p-3">
            <h5 class="text-center">⚠️ Distribución por Prioridad</h5>
            <canvas id="chartPrioridad"></canvas>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-md-6">
        <div class="card bg-white p-3">
            <h5>🏘️ Por Barrio</h5>
            <table class="table table-sm table-striped">
                <thead><tr><th>Barrio</th><th class="text-end">Cantidad</th></tr></thead>
                <tbody>
                    <?php if (!empty($datos['por_barrio'])): ?>
                        <?php foreach ($datos['por_barrio'] as $row): ?>
                            <tr>
                                <td><?= View::e($row['nombre'] ?? 'Sin asignar') ?></td>
                                <td class="text-end"><span class="badge bg-secondary"><?= (int)$row['total'] ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="2" class="text-center text-muted">Sin datos</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card bg-white p-3">
            <h5>📂 Por Categoría</h5>
            <table class="table table-sm table-striped">
                <thead><tr><th>Categoría</th><th class="text-end">Cantidad</th></tr></thead>
                <tbody>
                    <?php if (!empty($datos['por_categoria'])): ?>
                        <?php foreach ($datos['por_categoria'] as $row): ?>
                            <tr>
                                <td><?= View::e($row['nombre'] ?? 'Sin asignar') ?></td>
                                <td class="text-end"><span class="badge bg-secondary"><?= (int)$row['total'] ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="2" class="text-center text-muted">Sin datos</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<script>
const datosBarrio = <?= json_encode($datos['por_barrio'] ?? []) ?>;
const datosPrioridad = <?= json_encode($datos['por_prioridad'] ?? []) ?>;

if (datosBarrio.length > 0) {
    new Chart(document.getElementById('chartBarrio'), {
        type: 'bar',
        data: {
            labels: datosBarrio.map(d => d.nombre || 'Sin asignar'),
            datasets: [{
                label: 'Incidentes',
                data: datosBarrio.map(d => d.total),
                backgroundColor: 'rgba(13, 110, 253, 0.7)'
            }]
        },
        options: { responsive: true, plugins: { legend: { display: false } } }
    });
}

if (datosPrioridad.length > 0) {
    new Chart(document.getElementById('chartPrioridad'), {
        type: 'doughnut',
        data: {
            labels: datosPrioridad.map(d => d.prioridad || 'Sin asignar'),
            datasets: [{
                data: datosPrioridad.map(d => d.total),
                backgroundColor: ['#dc3545', '#fd7e14', '#ffc107', '#198754', '#6c757d']
            }]
        },
        options: { responsive: true }
    });
}
</script>