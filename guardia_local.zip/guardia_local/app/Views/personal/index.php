<div class="d-flex justify-content-between mb-3">
  <h3>Personal</h3>
  <a href="<?= APP_URL ?>personal/crear" class="btn btn-primary">➕ Nuevo</a>
</div>
<?php if (!empty($_SESSION['error'])): ?><div class="alert alert-warning"><?= View::e($_SESSION['error']) ?></div><?php unset($_SESSION['error']); endif; ?>
<table class="table table-striped bg-white">
  <thead><tr><th>Nombre</th><th>Legajo</th><th>Cargo</th><th>Turno</th><th>Acciones</th></tr></thead>
  <tbody>
  <?php foreach ($personal as $p): ?>
    <tr>
      <td><?= View::e($p["nombre_completo"]) ?></td>
      <td><?= View::e($p["legajo"]??"-") ?></td>
      <td><?= View::e($p["cargo"]??"-") ?></td>
      <td><?= View::e($p["turno"]??"-") ?></td>
      <td>
        <a href="<?= APP_URL ?>personal/editar?id=<?= $p["id"] ?>" class="btn btn-sm btn-outline-primary">✏️</a>
        <form method="post" action="<?= APP_URL ?>personal/eliminar" style="display:inline" onsubmit="return confirm('¿Dar de baja?')">
          <?= Csrf::field() ?><input type="hidden" name="id" value="<?= $p["id"] ?>">
          <button class="btn btn-sm btn-outline-danger">🗑️</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>