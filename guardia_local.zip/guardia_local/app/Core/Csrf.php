<?php
declare(strict_types=1);
class Csrf {
    public static function token(): string {
        if (empty($_SESSION[CSRF_TOKEN_NAME]))
            $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
        return $_SESSION[CSRF_TOKEN_NAME];
    }
    public static function field(): string {
        return '<input type="hidden" name="'.CSRF_TOKEN_NAME.'" value="'.self::token().'">';
    }
    public static function verify(): bool {
        $t = $_POST[CSRF_TOKEN_NAME] ?? "";
        return is_string($t) && hash_equals($_SESSION[CSRF_TOKEN_NAME]??"", $t);
    }
}
