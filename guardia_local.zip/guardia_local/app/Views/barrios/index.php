<div class="d-flex justify-content-between mb-3">
  <h3>🏘️ Gestión de Barrios</h3>
  <a href="<?= APP_URL ?>barrios/crear" class="btn btn-primary">➕ Nuevo barrio</a>
</div>

<?php if (!empty($_SESSION["ok"])): ?><div class="alert alert-success"><?= View::e($_SESSION["ok"]) ?></div><?php unset($_SESSION["ok"]); endif; ?>
<?php if (!empty($_SESSION["error"])): ?><div class="alert alert-danger"><?= View::e($_SESSION["error"]) ?></div><?php unset($_SESSION["error"]); endif; ?>

<div class="alert alert-info">
  <strong>ℹ️ Importante:</strong> Los límites de los barrios deben provenir de información oficial de la Municipalidad.
  No se muestran estimaciones como información oficial. Cargá los GeoJSON oficiales desde el formulario de cada barrio.
</div>

<table class="table table-striped bg-white">
  <thead>
    <tr>
      <th>Barrio</th>
      <th>Descripción</th>
      <th>GeoJSON</th>
      <th>Incidentes</th>
      <th>Críticos</th>
      <th>Acciones</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($barrios as $b): ?>
    <tr>
      <td><strong><?= View::e($b["nombre"]) ?></strong></td>
      <td><small><?= View::e($b["descripcion"] ?? "-") ?></small></td>
      <td>
        <?php if ($b["geojson"]): ?>
          <span class="badge bg-success">✓ Cargado</span>
        <?php else: ?>
          <span class="badge bg-warning text-dark">⚠️ Sin polígono</span>
        <?php endif; ?>
      </td>
      <td><span class="badge bg-info"><?= (int)$b["total_incidentes"] ?></span></td>
      <td><span class="badge bg-danger"><?= (int)$b["criticos"] ?></span></td>
      <td>
        <a href="<?= APP_URL ?>barrios/ver?id=<?= $b["id"] ?>" class="btn btn-sm btn-outline-info">👁️ Ver</a>
        <a href="<?= APP_URL ?>barrios/editar?id=<?= $b["id"] ?>" class="btn btn-sm btn-outline-primary">✏️ Editar</a>
        <form method="post" action="<?= APP_URL ?>barrios/eliminar" style="display:inline" onsubmit="return confirm('¿Dar de baja este barrio?')">
          <?= Csrf::field() ?><input type="hidden" name="id" value="<?= $b["id"] ?>">
          <button class="btn btn-sm btn-outline-danger">🗑️</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>

<div class="card bg-white p-3 mt-3">
  <h5>🔄 Reasignar incidentes entre barrios</h5>
  <p class="text-muted">Útil cuando se corrige la división territorial oficial.</p>
  <form method="post" action="<?= APP_URL ?>barrios/reasignar" class="row g-2">
    <?= Csrf::field() ?>
    <div class="col-md-4">
      <label>Barrio origen</label>
      <select name="barrio_origen" class="form-select" required>
        <option value="">Seleccionar...</option>
        <?php foreach ($barrios as $b): ?>
          <option value="<?= $b["id"] ?>"><?= View::e($b["nombre"]) ?> (<?= (int)$b["total_incidentes"] ?> incidentes)</option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4">
      <label>Barrio destino</label>
      <select name="barrio_destino" class="form-select" required>
        <option value="">Seleccionar...</option>
        <?php foreach ($barrios as $b): ?>
          <option value="<?= $b["id"] ?>"><?= View::e($b["nombre"]) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-4 d-flex align-items-end">
      <button class="btn btn-warning w-100" onclick="return confirm('¿Confirmar reasignación? Esta acción queda registrada en auditoría.')">🔄 Reasignar</button>
    </div>
  </form>
</div>