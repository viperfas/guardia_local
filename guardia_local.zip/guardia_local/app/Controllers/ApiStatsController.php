<?php
declare(strict_types=1);
class ApiStatsController extends Controller {
    public function barrios(): void {
        $db = Database::connection();
        $desde = $_GET["desde"] ?? date("Y-m-01", strtotime("-1 month"));
        $hasta = $_GET["hasta"] ?? date("Y-m-d");
        
        $sql = "SELECT b.id, b.nombre, b.geojson, COUNT(i.id) as total,
            SUM(CASE WHEN i.prioridad = 'Crítica' THEN 1 ELSE 0 END) as criticos
            FROM barrios b
            LEFT JOIN incidentes i ON i.id_barrio = b.id AND i.fecha BETWEEN ? AND ?
            GROUP BY b.id, b.nombre, b.geojson
            ORDER BY total DESC";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$desde, $hasta]);
        $this->json($stmt->fetchAll());
    }
    
    public function categorias(): void {
        $db = Database::connection();
        $desde = $_GET["desde"] ?? date("Y-m-01", strtotime("-1 month"));
        $hasta = $_GET["hasta"] ?? date("Y-m-d");
        
        $sql = "SELECT c.id, c.nombre, c.color, COUNT(i.id) as total
            FROM categorias_incidentes c
            LEFT JOIN incidentes i ON i.id_categoria = c.id AND i.fecha BETWEEN ? AND ?
            GROUP BY c.id, c.nombre, c.color
            ORDER BY total DESC";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$desde, $hasta]);
        $this->json($stmt->fetchAll());
    }
    
    public function temporal(): void {
        $db = Database::connection();
        $desde = $_GET["desde"] ?? date("Y-m-01", strtotime("-6 month"));
        $hasta = $_GET["hasta"] ?? date("Y-m-d");
        
        $sql = "SELECT DATE(i.fecha) as fecha, COUNT(*) as total
            FROM incidentes i
            WHERE i.fecha BETWEEN ? AND ?
            GROUP BY DATE(i.fecha)
            ORDER BY fecha";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$desde, $hasta]);
        $this->json($stmt->fetchAll());
    }
    
    public function horaria(): void {
        $db = Database::connection();
        $desde = $_GET["desde"] ?? date("Y-m-01", strtotime("-1 month"));
        $hasta = $_GET["hasta"] ?? date("Y-m-d");
        
        $sql = "SELECT HOUR(i.hora) as hora, COUNT(*) as total
            FROM incidentes i
            WHERE i.fecha BETWEEN ? AND ?
            GROUP BY HOUR(i.hora)
            ORDER BY hora";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$desde, $hasta]);
        $resultados = $stmt->fetchAll();
        
        $horas = array_fill(0, 24, 0);
        foreach ($resultados as $r) {
            $horas[(int)$r["hora"]] = (int)$r["total"];
        }
        
        $this->json($horas);
    }
    
    public function tiempos(): void {
        $db = Database::connection();
        $desde = $_GET["desde"] ?? date("Y-m-01", strtotime("-1 month"));
        $hasta = $_GET["hasta"] ?? date("Y-m-d");
        
        $sql = "SELECT 
            AVG(TIMESTAMPDIFF(MINUTE, CONCAT(i.fecha, ' ', i.hora), iv.hora_salida)) as tiempo_despacho,
            AVG(TIMESTAMPDIFF(MINUTE, iv.hora_salida, iv.hora_llegada)) as tiempo_traslado,
            AVG(TIMESTAMPDIFF(MINUTE, iv.hora_llegada, iv.hora_finalizacion)) as tiempo_intervencion,
            AVG(TIMESTAMPDIFF(MINUTE, CONCAT(i.fecha, ' ', i.hora), iv.hora_finalizacion)) as tiempo_total,
            COUNT(*) as total_intervenciones
            FROM intervenciones iv
            INNER JOIN incidentes i ON i.id = iv.id_incidente
            WHERE i.fecha BETWEEN ? AND ?
            AND iv.hora_salida IS NOT NULL
            AND iv.hora_llegada IS NOT NULL
            AND iv.hora_finalizacion IS NOT NULL";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$desde, $hasta]);
        $this->json($stmt->fetch());
    }
}
