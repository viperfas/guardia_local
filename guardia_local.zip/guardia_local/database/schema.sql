SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET time_zone = '-03:00';

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(60) NOT NULL,
  `descripcion` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_roles_nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `usuario` VARCHAR(60) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `nombre_completo` VARCHAR(120) NOT NULL,
  `id_rol` INT UNSIGNED NOT NULL,
  `activo` TINYINT(1) NOT NULL DEFAULT 1,
  `fecha_creacion` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_usuarios_usuario` (`usuario`),
  CONSTRAINT `fk_usuarios_rol` FOREIGN KEY (`id_rol`) REFERENCES `roles`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `permisos`;
CREATE TABLE `permisos` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `codigo` VARCHAR(80) NOT NULL,
  `descripcion` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_permisos_codigo` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `usuarios_permisos`;
CREATE TABLE `usuarios_permisos` (
  `id_usuario` INT UNSIGNED NOT NULL,
  `id_permiso` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id_usuario`,`id_permiso`),
  CONSTRAINT `fk_up_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_up_permiso` FOREIGN KEY (`id_permiso`) REFERENCES `permisos`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `barrios`;
CREATE TABLE `barrios` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(120) NOT NULL,
  `descripcion` VARCHAR(255) DEFAULT NULL,
  `geojson` LONGTEXT DEFAULT NULL,
  `activo` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_barrios_nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `sectores`;
CREATE TABLE `sectores` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_barrio` INT UNSIGNED NOT NULL,
  `nombre` VARCHAR(120) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_sectores_barrio` FOREIGN KEY (`id_barrio`) REFERENCES `barrios`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `vecinos`;
CREATE TABLE `vecinos` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(80) NOT NULL,
  `apellido` VARCHAR(80) NOT NULL,
  `dni` VARCHAR(15) NOT NULL,
  `telefono` VARCHAR(30) DEFAULT NULL,
  `fecha_nacimiento` DATE DEFAULT NULL,
  `direccion` VARCHAR(150) DEFAULT NULL,
  `numero` VARCHAR(20) DEFAULT NULL,
  `id_barrio` INT UNSIGNED DEFAULT NULL,
  `contacto_emergencia` VARCHAR(120) DEFAULT NULL,
  `telefono_emergencia` VARCHAR(30) DEFAULT NULL,
  `observaciones` TEXT DEFAULT NULL,
  `id_operador_alta` INT UNSIGNED DEFAULT NULL,
  `fecha_alta` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activo` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_vecinos_dni` (`dni`),
  CONSTRAINT `fk_vecinos_barrio` FOREIGN KEY (`id_barrio`) REFERENCES `barrios`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `categorias_incidentes`;
CREATE TABLE `categorias_incidentes` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(100) NOT NULL,
  `color` VARCHAR(7) DEFAULT '#6c7572',
  `activo` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_categorias_nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `incidentes`;
CREATE TABLE `incidentes` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `numero` INT UNSIGNED NOT NULL DEFAULT 0,
  `fecha` DATE NOT NULL,
  `hora` TIME NOT NULL,
  `id_vecino` INT UNSIGNED DEFAULT NULL,
  `telefono_informante` VARCHAR(30) DEFAULT NULL,
  `id_operador` INT UNSIGNED NOT NULL,
  `id_categoria` INT UNSIGNED DEFAULT NULL,
  `descripcion` TEXT DEFAULT NULL,
  `id_barrio` INT UNSIGNED DEFAULT NULL,
  `direccion` VARCHAR(200) DEFAULT NULL,
  `referencia` VARCHAR(255) DEFAULT NULL,
  `latitud` DECIMAL(10,7) DEFAULT NULL,
  `longitud` DECIMAL(10,7) DEFAULT NULL,
  `prioridad` ENUM('Crítica','Alta','Media','Baja') NOT NULL DEFAULT 'Media',
  `estado` ENUM('Recibido','Pendiente de evaluación','Asignado','En intervención','Derivado','Resuelto','Cerrado') NOT NULL DEFAULT 'Recibido',
  `observaciones` TEXT DEFAULT NULL,
  `fecha_creacion` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_incidentes_fecha` (`fecha`),
  CONSTRAINT `fk_incidentes_vecino` FOREIGN KEY (`id_vecino`) REFERENCES `vecinos`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_incidentes_operador` FOREIGN KEY (`id_operador`) REFERENCES `usuarios`(`id`),
  CONSTRAINT `fk_incidentes_categoria` FOREIGN KEY (`id_categoria`) REFERENCES `categorias_incidentes`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_incidentes_barrio` FOREIGN KEY (`id_barrio`) REFERENCES `barrios`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `incidentes_novedades`;
CREATE TABLE `incidentes_novedades` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_incidente` INT UNSIGNED NOT NULL,
  `id_operador` INT UNSIGNED NOT NULL,
  `fecha_hora` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tipo` VARCHAR(50) NOT NULL,
  `descripcion` TEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_nov_incidente` FOREIGN KEY (`id_incidente`) REFERENCES `incidentes`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nov_operador` FOREIGN KEY (`id_operador`) REFERENCES `usuarios`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `incidentes_adjuntos`;
CREATE TABLE `incidentes_adjuntos` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_incidente` INT UNSIGNED NOT NULL,
  `nombre_archivo` VARCHAR(255) NOT NULL,
  `ruta` VARCHAR(500) NOT NULL,
  `tipo_mime` VARCHAR(100) DEFAULT NULL,
  `fecha` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_adj_incidente` FOREIGN KEY (`id_incidente`) REFERENCES `incidentes`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `moviles`;
CREATE TABLE `moviles` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `numero_interno` VARCHAR(30) NOT NULL,
  `tipo` VARCHAR(60) DEFAULT NULL,
  `marca` VARCHAR(60) DEFAULT NULL,
  `modelo` VARCHAR(60) DEFAULT NULL,
  `patente` VARCHAR(20) DEFAULT NULL,
  `estado` ENUM('Disponible','Asignado','En servicio','Fuera de servicio','En mantenimiento') NOT NULL DEFAULT 'Disponible',
  `observaciones` TEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_moviles_numero` (`numero_interno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `personal`;
CREATE TABLE `personal` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nombre_completo` VARCHAR(120) NOT NULL,
  `legajo` VARCHAR(30) DEFAULT NULL,
  `cargo` VARCHAR(60) DEFAULT NULL,
  `turno` VARCHAR(30) DEFAULT NULL,
  `activo` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `equipos`;
CREATE TABLE `equipos` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(100) NOT NULL,
  `id_responsable` INT UNSIGNED DEFAULT NULL,
  `turno` VARCHAR(30) DEFAULT NULL,
  `id_movil` INT UNSIGNED DEFAULT NULL,
  `estado` VARCHAR(40) NOT NULL DEFAULT 'Activo',
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_equipos_responsable` FOREIGN KEY (`id_responsable`) REFERENCES `personal`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_equipos_movil` FOREIGN KEY (`id_movil`) REFERENCES `moviles`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `equipos_integrantes`;
CREATE TABLE `equipos_integrantes` (
  `id_equipo` INT UNSIGNED NOT NULL,
  `id_personal` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id_equipo`,`id_personal`),
  CONSTRAINT `fk_ei_equipo` FOREIGN KEY (`id_equipo`) REFERENCES `equipos`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ei_personal` FOREIGN KEY (`id_personal`) REFERENCES `personal`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `intervenciones`;
CREATE TABLE `intervenciones` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `numero` INT UNSIGNED NOT NULL DEFAULT 0,
  `id_incidente` INT UNSIGNED NOT NULL,
  `fecha_hora_despacho` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `prioridad` ENUM('Crítica','Alta','Media','Baja') NOT NULL DEFAULT 'Media',
  `id_movil` INT UNSIGNED DEFAULT NULL,
  `id_equipo` INT UNSIGNED DEFAULT NULL,
  `id_operador_despacho` INT UNSIGNED NOT NULL,
  `motivo` TEXT DEFAULT NULL,
  `observaciones` TEXT DEFAULT NULL,
  `estado` ENUM('Asignado','En intervención','Derivado','Resuelto','Cerrado') NOT NULL DEFAULT 'Asignado',
  `hora_salida` DATETIME DEFAULT NULL,
  `hora_llegada` DATETIME DEFAULT NULL,
  `hora_finalizacion` DATETIME DEFAULT NULL,
  `resultado` TEXT DEFAULT NULL,
  `acciones_realizadas` TEXT DEFAULT NULL,
  `organismos_externos` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_int_incidente` FOREIGN KEY (`id_incidente`) REFERENCES `incidentes`(`id`),
  CONSTRAINT `fk_int_movil` FOREIGN KEY (`id_movil`) REFERENCES `moviles`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_int_equipo` FOREIGN KEY (`id_equipo`) REFERENCES `equipos`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_int_operador` FOREIGN KEY (`id_operador_despacho`) REFERENCES `usuarios`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `intervenciones_novedades`;
CREATE TABLE `intervenciones_novedades` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_intervencion` INT UNSIGNED NOT NULL,
  `id_operador` INT UNSIGNED DEFAULT NULL,
  `fecha_hora` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tipo` VARCHAR(50) NOT NULL,
  `descripcion` TEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_inv_nov` FOREIGN KEY (`id_intervencion`) REFERENCES `intervenciones`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `intervenciones_personal`;
CREATE TABLE `intervenciones_personal` (
  `id_intervencion` INT UNSIGNED NOT NULL,
  `id_personal` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id_intervencion`,`id_personal`),
  CONSTRAINT `fk_ip_interv` FOREIGN KEY (`id_intervencion`) REFERENCES `intervenciones`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ip_personal` FOREIGN KEY (`id_personal`) REFERENCES `personal`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `auditoria`;
CREATE TABLE `auditoria` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_usuario` INT UNSIGNED DEFAULT NULL,
  `fecha_hora` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` VARCHAR(45) NOT NULL,
  `tipo_operacion` VARCHAR(60) NOT NULL,
  `modulo` VARCHAR(60) NOT NULL,
  `registro_afectado` VARCHAR(100) DEFAULT NULL,
  `valores_anteriores` TEXT DEFAULT NULL,
  `valores_nuevos` TEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aud_fecha` (`fecha_hora`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `informes`;
CREATE TABLE `informes` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `tipo` VARCHAR(60) NOT NULL,
  `periodo_desde` DATE DEFAULT NULL,
  `periodo_hasta` DATE DEFAULT NULL,
  `contenido` LONGTEXT DEFAULT NULL,
  `proveedor_ia` VARCHAR(60) DEFAULT NULL,
  `modelo_ia` VARCHAR(60) DEFAULT NULL,
  `id_usuario` INT UNSIGNED DEFAULT NULL,
  `fecha_generacion` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `configuracion`;
CREATE TABLE `configuracion` (
  `clave` VARCHAR(80) NOT NULL,
  `valor` TEXT DEFAULT NULL,
  `descripcion` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`clave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `respaldos`;
CREATE TABLE `respaldos` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nombre_archivo` VARCHAR(255) NOT NULL,
  `tamano_bytes` BIGINT UNSIGNED DEFAULT NULL,
  `tipo` ENUM('automatico','manual') NOT NULL,
  `estado` ENUM('ok','error') NOT NULL DEFAULT 'ok',
  `fecha` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_usuario` INT UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
