<div class="d-flex justify-content-between mb-3">
  <h3>🏘️ <?= View::e($barrio["nombre"]) ?></h3>
  <div>
    <a href="<?= APP_URL ?>barrios/editar?id=<?= $barrio["id"] ?>" class="btn btn-outline-primary">✏️ Editar</a>
    <a href="<?= APP_URL ?>barrios" class="btn btn-outline-secondary">← Volver</a>
  </div>
</div>

<div class="row g-3 mb-3">
  <div class="col-md-3">
    <div class="card text-bg-info p-3">
      <h6>Total incidentes</h6>
      <h2><?= (int)$stats["total"] ?></h2>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card text-bg-danger p-3">
      <h6>Críticos</h6>
      <h2><?= (int)$stats["criticos"] ?></h2>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card text-bg-success p-3">
      <h6>Resueltos</h6>
      <h2><?= (int)$stats["resueltos"] ?></h2>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card text-bg-warning p-3">
      <h6>Pendientes</h6>
      <h2><?= (int)$stats["total"] - (int)$stats["resueltos"] ?></h2>
    </div>
  </div>
</div>

<div class="row g-3 mb-3">
  <div class="col-md-6">
    <div class="card bg-white p-3">
      <h5>📋 Top categorías</h5>
      <?php if (empty($categorias)): ?>
        <p class="text-muted">Sin incidentes registrados</p>
      <?php else: ?>
        <table class="table table-sm">
          <thead><tr><th>Categoría</th><th class="text-end">Total</th></tr></thead>
          <tbody>
          <?php foreach ($categorias as $c): ?>
            <tr><td><?= View::e($c["nombre"]) ?></td><td class="text-end"><?= (int)$c["total"] ?></td></tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>
  <div class="col-md-6">
    <div class="card bg-white p-3">
      <h5>📈 Evolución mensual</h5>
      <?php if (empty($evolucion)): ?>
        <p class="text-muted">Sin datos</p>
      <?php else: ?>
        <table class="table table-sm">
          <thead><tr><th>Mes</th><th class="text-end">Incidentes</th></tr></thead>
          <tbody>
          <?php foreach ($evolucion as $e): ?>
            <tr><td><?= View::e($e["mes"]) ?></td><td class="text-end"><?= (int)$e["total"] ?></td></tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php if ($barrio["geojson"]): ?>
<div class="card bg-white p-3 mb-3">
  <h5>🗺️ Polígono territorial</h5>
  <div id="mapBarrio" style="height:400px;border:1px solid #ccc"></div>
  <script>
    const map = L.map('mapBarrio').setView([-31.1470, -64.4010], 14);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap', maxZoom: 19
    }).addTo(map);
    try {
      const geo = JSON.parse(<?= json_encode($barrio["geojson"]) ?>);
      const layer = L.geoJSON(geo, {
        style: { color: '#d63384', weight: 3, fillOpacity: 0.2 }
      }).addTo(map);
      map.fitBounds(layer.getBounds());
    } catch(e) {
      console.warn('GeoJSON inválido', e);
    }
  </script>
</div>
<?php else: ?>
<div class="alert alert-warning">
  ⚠️ Este barrio no tiene polígono GeoJSON cargado. No aparecerá en el mapa territorial.
  <a href="<?= APP_URL ?>barrios/editar?id=<?= $barrio["id"] ?>">Cargar polígono</a>
</div>
<?php endif; ?>

<div class="card bg-white p-3">
  <h5>📜 Historial de modificaciones territoriales</h5>
  <?php if (empty($historial)): ?>
    <p class="text-muted">Sin modificaciones registradas</p>
  <?php else: ?>
    <table class="table table-sm">
      <thead><tr><th>Fecha</th><th>Usuario</th><th>Operación</th><th>Observaciones</th></tr></thead>
      <tbody>
      <?php foreach ($historial as $h): ?>
        <tr>
          <td><small><?= View::e($h["fecha_hora"]) ?></small></td>
          <td><?= View::e($h["usuario"] ?? "sistema") ?></td>
          <td><span class="badge bg-secondary"><?= View::e($h["tipo_operacion"]) ?></span></td>
          <td><small><?= View::e($h["observaciones"] ?? "") ?></small></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>