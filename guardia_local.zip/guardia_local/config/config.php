<?php
declare(strict_types=1);
define("APP_NAME", "Guardia Local Villa Giardino");
define("APP_VERSION", "1.0.0");
define("APP_DEBUG", true);
define('APP_URL', 'http://localhost/guardia_local/public/');
define("APP_TIMEZONE", "America/Argentina/Cordoba");
define("APP_LOCALE", "es_AR");

define("SESSION_LIFETIME", 3600);
define("MAX_LOGIN_ATTEMPTS", 5);
define("LOCKOUT_MINUTES", 15);
define("CSRF_TOKEN_NAME", "csrf_token");

define("MAX_UPLOAD_SIZE", 10 * 1024 * 1024);
define("ALLOWED_EXTENSIONS", ["jpg","jpeg","png","pdf","doc","docx"]);

define("AI_MIN_AGGREGATION", 5);
