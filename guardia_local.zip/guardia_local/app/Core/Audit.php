<?php
declare(strict_types=1);
class Audit {
    public static function log(string $tipo, string $modulo, ?string $registro=null,
                               ?string $anterior=null, ?string $nuevo=null): void {
        try {
            $db = Database::connection();
            $stmt = $db->prepare("INSERT INTO auditoria
                (id_usuario, fecha_hora, ip, tipo_operacion, modulo, registro_afectado, valores_anteriores, valores_nuevos)
                VALUES (?, NOW(), ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $_SESSION["user_id"] ?? null,
                $_SERVER["REMOTE_ADDR"] ?? "127.0.0.1",
                $tipo, $modulo, $registro, $anterior, $nuevo
            ]);
        } catch (Throwable $e) { error_log("Audit: ".$e->getMessage()); }
    }
}
