<?php
declare(strict_types=1);
class MapaController extends Controller {
    public function index(): void {
        $db = Database::connection();
        $barrios = $db->query("SELECT id, nombre, geojson FROM barrios WHERE activo=1 ORDER BY nombre")->fetchAll();
        
        $categorias = $db->query("SELECT id, nombre, color FROM categorias_incidentes WHERE activo=1 ORDER BY nombre")->fetchAll();
        
        $this->view("mapa/index", [
            "barrios" => $barrios,
            "categorias" => $categorias
        ]);
    }
    
    public function barrios(): void {
        $db = Database::connection();
        $desde = $_GET["desde"] ?? date("Y-m-01", strtotime("-1 month"));
        $hasta = $_GET["hasta"] ?? date("Y-m-d");
        $categoria = (int)($_GET["categoria"] ?? 0);
        $prioridad = $_GET["prioridad"] ?? "";
        
        $where = "i.fecha BETWEEN ? AND ?";
        $params = [$desde, $hasta];
        
        if ($categoria > 0) {
            $where .= " AND i.id_categoria = ?";
            $params[] = $categoria;
        }
        if ($prioridad) {
            $where .= " AND i.prioridad = ?";
            $params[] = $prioridad;
        }
        
        $sql = "SELECT b.id, b.nombre, b.geojson, COUNT(i.id) AS total,
            SUM(CASE WHEN i.prioridad='Crítica' THEN 1 ELSE 0 END) AS criticos,
            SUM(CASE WHEN i.estado IN ('Resuelto','Cerrado') THEN 1 ELSE 0 END) AS resueltos
            FROM barrios b
            LEFT JOIN incidentes i ON i.id_barrio=b.id AND $where
            WHERE b.activo=1 AND b.geojson IS NOT NULL
            GROUP BY b.id, b.nombre, b.geojson
            ORDER BY total DESC";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $this->json($stmt->fetchAll());
    }
    
    public function incidentes(): void {
        $db = Database::connection();
        $desde = $_GET["desde"] ?? date("Y-m-01", strtotime("-1 month"));
        $hasta = $_GET["hasta"] ?? date("Y-m-d");
        $barrio = (int)($_GET["barrio"] ?? 0);
        $categoria = (int)($_GET["categoria"] ?? 0);
        
        $where = "i.fecha BETWEEN ? AND ? AND i.latitud IS NOT NULL AND i.longitud IS NOT NULL";
        $params = [$desde, $hasta];
        
        if ($barrio > 0) {
            $where .= " AND i.id_barrio=?";
            $params[] = $barrio;
        }
        if ($categoria > 0) {
            $where .= " AND i.id_categoria=?";
            $params[] = $categoria;
        }
        
        $sql = "SELECT i.id, i.latitud, i.longitud, i.prioridad, i.estado, i.fecha, i.hora,
            c.nombre AS categoria, c.color AS categoria_color, b.nombre AS barrio
            FROM incidentes i
            LEFT JOIN categorias_incidentes c ON c.id=i.id_categoria
            LEFT JOIN barrios b ON b.id=i.id_barrio
            WHERE $where";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $this->json($stmt->fetchAll());
    }
    
    public function asignarBarrio(): void {
        $this->requirePost();
        $idIncidente = (int)($_POST["id_incidente"] ?? 0);
        $idBarrio = (int)($_POST["id_barrio"] ?? 0);
        
        $db = Database::connection();
        $stmt = $db->prepare("UPDATE incidentes SET id_barrio=? WHERE id=?");
        $stmt->execute([$idBarrio ?: null, $idIncidente]);
        
        Audit::log("asignar_barrio_incidente", "mapa", "Incidente $idIncidente → Barrio " . ($idBarrio ?: "ninguno"));
        $this->json(["ok" => true]);
    }
}