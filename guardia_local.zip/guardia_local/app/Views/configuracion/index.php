<h3 class="mb-4">⚙️ Configuración del sistema</h3>

<?php if (!empty($_SESSION["config_ok"])): ?>
<div class="alert alert-success"><?= View::e($_SESSION["config_ok"]) ?></div>
<?php unset($_SESSION["config_ok"]); endif; ?>

<?php if (!empty($_SESSION["config_err"])): ?>
<div class="alert alert-danger"><?= View::e($_SESSION["config_err"]) ?></div>
<?php unset($_SESSION["config_err"]); endif; ?>

<form method="post" action="<?= APP_URL ?>configuracion/guardar">
  <?= Csrf::field() ?>
  
  <div class="card bg-white p-3 mb-3">
    <h5>🏛️ Datos institucionales</h5>
    <?php 
    $keys = ["municipio_nombre" => "Nombre del municipio", 
             "municipio_provincia" => "Provincia", 
             "municipio_pais" => "País"];
    foreach ($keys as $k => $label):
      $v = ""; foreach ($configs as $c) if ($c["clave"]==$k) $v = $c["valor"];
    ?>
      <div class="row g-2 mb-2">
        <div class="col-md-3"><label><?= $label ?></label></div>
        <div class="col-md-9"><input name="config[<?= $k ?>]" class="form-control" value="<?= View::e($v) ?>"></div>
      </div>
    <?php endforeach; ?>
  </div>
  
  <div class="card bg-white p-3 mb-3">
    <h5>🤖 Inteligencia Artificial</h5>
    <p class="text-muted">Los datos enviados son anonimizados automáticamente (requisito 21.B).</p>
    <?php 
    $iaKeys = [
        "ia_proveedor" => "Proveedor (groq, ollama, openai, qwen)",
        "ia_modelo" => "Modelo (ej: llama3-8b-8192, qwen2.5:7b)",
        "ia_api_key_path" => "Ruta al archivo de API key",
    ];
    foreach ($iaKeys as $k => $label):
      $v = ""; foreach ($configs as $c) if ($c["clave"]==$k) $v = $c["valor"];
    ?>
      <div class="row g-2 mb-2">
        <div class="col-md-3"><label><?= $label ?></label></div>
        <div class="col-md-9"><input name="config[<?= $k ?>]" class="form-control" value="<?= View::e($v) ?>"></div>
      </div>
    <?php endforeach; ?>
    
    <?php 
    $v = "0"; foreach ($configs as $c) if ($c["clave"]=="ia_habilitada") $v = $c["valor"];
    ?>
    <div class="row g-2 mb-2">
      <div class="col-md-3"><label>Habilitar IA</label></div>
      <div class="col-md-9">
        <select name="config[ia_habilitada]" class="form-select">
          <option value="0" <?= $v==="0"?"selected":"" ?>>❌ Deshabilitada</option>
          <option value="1" <?= $v==="1"?"selected":"" ?>>✅ Habilitada</option>
        </select>
      </div>
    </div>
    
    <div class="alert alert-info mt-2">
      <small>
        <strong>Proveedores gratuitos:</strong><br>
        • <strong>groq</strong> (nube, ultrarrápido) → https://console.groq.com/keys<br>
        • <strong>ollama</strong> (local, privado) → https://ollama.com/download<br>
        <strong>API Key:</strong> guardala en un archivo fuera de htdocs (ej: C:\ia\groq_api.key)
      </small>
    </div>
  </div>
  
  <button type="submit" class="btn btn-primary btn-lg">💾 Guardar configuración</button>
</form>