<h3 class="mb-4">📄 Reportes y Exportaciones</h3>

<div class="alert alert-info">
    <strong>ℹ️ Información:</strong> Desde esta sección podés generar reportes estadísticos del sistema de guardia.
</div>

<div class="row g-4">
    <div class="col-md-6">
        <div class="card bg-white p-4 h-100">
            <h4 class="card-title">📅 Reporte por Período</h4>
            <p class="text-muted">Generá un reporte de incidentes filtrando por rango de fechas.</p>
            <form method="get" action="<?= APP_URL ?>reportes/periodo" class="mt-3">
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <label>Desde</label>
                        <input type="date" name="desde" class="form-control" 
                               value="<?= date('Y-m-01', strtotime('-1 month')) ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label>Hasta</label>
                        <input type="date" name="hasta" class="form-control" 
                               value="<?= date('Y-m-d') ?>" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary w-100">📊 Generar Reporte</button>
            </form>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card bg-white p-4 h-100">
            <h4 class="card-title">🏘️ Reporte por Barrio</h4>
            <p class="text-muted">Consultá estadísticas detalladas por barrio.</p>
            <a href="<?= APP_URL ?>reportes/barrio" class="btn btn-success w-100 mt-3">
                🏘️ Ver Reporte por Barrio
            </a>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card bg-white p-4 h-100">
            <h4 class="card-title">📄 PDF con Gráficos</h4>
            <p class="text-muted">Generá un PDF profesional con gráficos estadísticos.</p>
            <a href="<?= APP_URL ?>reportes/generar_pdf_form" class="btn btn-warning w-100 mt-3">
                📄 Generar PDF
            </a>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card bg-white p-4 h-100">
            <h4 class="card-title">🤖 Informes con IA</h4>
            <p class="text-muted">Generá análisis avanzados con inteligencia artificial.</p>
            <a href="<?= APP_URL ?>informes_ia" class="btn btn-info w-100 mt-3 text-white">
                🤖 Ir a Informes IA
            </a>
        </div>
    </div>
</div>