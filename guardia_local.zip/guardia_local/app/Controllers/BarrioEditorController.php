<?php
declare(strict_types=1);

class BarrioEditorController extends Controller
{
    public function index(): void
    {
        $db = Database::connection();

        $barrios = $db->query("
            SELECT id, nombre, descripcion, geojson
            FROM barrios
            WHERE activo = 1
            ORDER BY nombre
        ")->fetchAll();

        require APP_PATH . 'Views/barrios/editor_visual.php';
        exit;
    }

    public function save(): void
    {
        $this->requirePost();

        $id = (int)($_POST['id_barrio'] ?? 0);
        $geojson = trim($_POST['geojson'] ?? '');

        if ($id <= 0 || $geojson === '') {
            $_SESSION['error'] = 'Debe seleccionar un barrio y dibujar un polígono.';
            $this->redirect('barrios/editor_visual');
            return;
        }

        $data = json_decode($geojson, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            $_SESSION['error'] = 'GeoJSON inválido: ' . json_last_error_msg();
            $this->redirect('barrios/editor_visual');
            return;
        }

        if (!isset($data['type']) || !in_array($data['type'], ['Polygon', 'MultiPolygon'], true)) {
            $_SESSION['error'] = 'El dibujo debe ser un polígono válido.';
            $this->redirect('barrios/editor_visual');
            return;
        }

        if (empty($data['coordinates']) || !is_array($data['coordinates'])) {
            $_SESSION['error'] = 'El polígono no tiene coordenadas válidas.';
            $this->redirect('barrios/editor_visual');
            return;
        }

        $db = Database::connection();

        $stmt = $db->prepare("SELECT nombre, geojson FROM barrios WHERE id = ?");
        $stmt->execute([$id]);
        $anterior = $stmt->fetch();

        if (!$anterior) {
            $_SESSION['error'] = 'Barrio no encontrado.';
            $this->redirect('barrios/editor_visual');
            return;
        }

        $stmt = $db->prepare("UPDATE barrios SET geojson = ? WHERE id = ?");
        $stmt->execute([$geojson, $id]);

        try {
            $stmt = $db->prepare("
                INSERT INTO barrios_historial
                (
                    id_barrio,
                    id_usuario,
                    tipo_operacion,
                    geojson_anterior,
                    geojson_nuevo,
                    nombre_anterior,
                    nombre_nuevo,
                    observaciones
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $id,
                $_SESSION['user_id'] ?? null,
                'edicion_visual',
                $anterior['geojson'] ?? null,
                $geojson,
                $anterior['nombre'] ?? null,
                $anterior['nombre'] ?? null,
                'Polígono cargado o editado desde editor visual'
            ]);
        } catch (Throwable $e) {
            // Si no existe tabla historial, no bloqueamos el guardado.
        }

        if (class_exists('Audit')) {
            Audit::log('editor_visual_barrio', 'barrios', (string)$id);
        }

        $_SESSION['ok'] = 'Polígono guardado correctamente.';
        $this->redirect('barrios/editor_visual');
    }
}