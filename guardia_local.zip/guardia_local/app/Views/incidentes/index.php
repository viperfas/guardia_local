<div class="d-flex justify-content-between mb-3">
  <h3>Incidentes</h3>
  <a href="<?= APP_URL ?>incidentes/crear" class="btn btn-danger">🚨 Nuevo incidente</a>
</div>
<?php if (!empty($_SESSION['error'])): ?><div class="alert alert-warning"><?= View::e($_SESSION['error']) ?></div><?php unset($_SESSION['error']); endif; ?>
<table class="table table-sm bg-white">
  <thead><tr><th>#</th><th>Fecha</th><th>Categoría</th><th>Barrio</th><th>Prioridad</th><th>Estado</th><th>Acciones</th></tr></thead>
  <tbody>
  <?php foreach ($incidentes as $i): ?>
    <tr>
      <td><?= (int)$i['id'] ?></td>
      <td><?= View::e($i['fecha'].' '.$i['hora']) ?></td>
      <td><?= View::e($i['categoria']??'-') ?></td>
      <td><?= View::e($i['barrio']??'-') ?></td>
      <td><span class="badge bg-<?= $i['prioridad']=='Crítica'?'danger':($i['prioridad']=='Alta'?'warning':'secondary') ?>"><?= View::e($i['prioridad']) ?></span></td>
      <td><?= View::e($i['estado']) ?></td>
      <td>
        <a href="<?= APP_URL ?>incidentes/editar?id=<?= $i['id'] ?>" class="btn btn-sm btn-outline-primary">✏️</a>
        <a href="<?= APP_URL ?>intervenciones/despachar?incidente=<?= $i['id'] ?>" class="btn btn-sm btn-danger">🚓</a>
        <a href="<?= APP_URL ?>reportes/incidente?id=<?= $i['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary">📄</a>
        <form method="post" action="<?= APP_URL ?>incidentes/eliminar" style="display:inline" onsubmit="return confirm('¿Eliminar incidente?')">
          <?= Csrf::field() ?><input type="hidden" name="id" value="<?= $i['id'] ?>">
          <button class="btn btn-sm btn-outline-danger">🗑️</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>