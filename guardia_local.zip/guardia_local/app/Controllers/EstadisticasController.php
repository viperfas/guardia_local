<?php
declare(strict_types=1);
class EstadisticasController extends Controller {
    public function index(): void {
        $db = Database::connection();
        
        // Filtros
        $desde = $_GET["desde"] ?? date("Y-m-01", strtotime("-1 month"));
        $hasta = $_GET["hasta"] ?? date("Y-m-d");
        $barrio = (int)($_GET["barrio"] ?? 0);
        $categoria = (int)($_GET["categoria"] ?? 0);
        
        // Construir WHERE
        $where = ["i.fecha BETWEEN ? AND ?"];
        $params = [$desde, $hasta];
        
        if ($barrio > 0) {
            $where[] = "i.id_barrio = ?";
            $params[] = $barrio;
        }
        if ($categoria > 0) {
            $where[] = "i.id_categoria = ?";
            $params[] = $categoria;
        }
        
        $whereClause = "WHERE " . implode(" AND ", $where);
        
        // Estadísticas generales
        $total = $db->prepare("SELECT COUNT(*) FROM incidentes i $whereClause");
        $total->execute($params);
        $totalIncidentes = (int)$total->fetchColumn();
        
        $criticos = $db->prepare("SELECT COUNT(*) FROM incidentes i $whereClause AND i.prioridad = 'Crítica'");
        $criticos->execute($params);
        $totalCriticos = (int)$criticos->fetchColumn();
        
        $resueltos = $db->prepare("SELECT COUNT(*) FROM incidentes i $whereClause AND i.estado IN ('Resuelto','Cerrado')");
        $resueltos->execute($params);
        $totalResueltos = (int)$resueltos->fetchColumn();
        
        // Datos para gráficos
        $barrios = $db->query("SELECT id, nombre FROM barrios ORDER BY nombre")->fetchAll();
        $categorias = $db->query("SELECT id, nombre FROM categorias_incidentes ORDER BY nombre")->fetchAll();
        
        $this->view("estadisticas/index", [
            "desde" => $desde,
            "hasta" => $hasta,
            "barrio" => $barrio,
            "categoria" => $categoria,
            "total" => $totalIncidentes,
            "criticos" => $totalCriticos,
            "resueltos" => $totalResueltos,
            "barrios" => $barrios,
            "categorias" => $categorias
        ]);
    }
    
    public function barrios(): void {
        $db = Database::connection();
        $desde = $_GET["desde"] ?? date("Y-m-01", strtotime("-1 month"));
        $hasta = $_GET["hasta"] ?? date("Y-m-d");
        
        $sql = "SELECT b.id, b.nombre, COUNT(i.id) as total,
            SUM(CASE WHEN i.prioridad = 'Crítica' THEN 1 ELSE 0 END) as criticos,
            SUM(CASE WHEN i.estado IN ('Resuelto','Cerrado') THEN 1 ELSE 0 END) as resueltos
            FROM barrios b
            LEFT JOIN incidentes i ON i.id_barrio = b.id AND i.fecha BETWEEN ? AND ?
            GROUP BY b.id, b.nombre
            ORDER BY total DESC";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$desde, $hasta]);
        $this->json($stmt->fetchAll());
    }
    
    public function categorias(): void {
        $db = Database::connection();
        $desde = $_GET["desde"] ?? date("Y-m-01", strtotime("-1 month"));
        $hasta = $_GET["hasta"] ?? date("Y-m-d");
        $barrio = (int)($_GET["barrio"] ?? 0);
        
        $where = "i.fecha BETWEEN ? AND ?";
        $params = [$desde, $hasta];
        
        if ($barrio > 0) {
            $where .= " AND i.id_barrio = ?";
            $params[] = $barrio;
        }
        
        $sql = "SELECT c.id, c.nombre, c.color, COUNT(i.id) as total
            FROM categorias_incidentes c
            LEFT JOIN incidentes i ON i.id_categoria = c.id AND $where
            GROUP BY c.id, c.nombre, c.color
            ORDER BY total DESC";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $this->json($stmt->fetchAll());
    }
    
    public function temporal(): void {
        $db = Database::connection();
        $desde = $_GET["desde"] ?? date("Y-m-01", strtotime("-6 month"));
        $hasta = $_GET["hasta"] ?? date("Y-m-d");
        $barrio = (int)($_GET["barrio"] ?? 0);
        
        $where = "i.fecha BETWEEN ? AND ?";
        $params = [$desde, $hasta];
        
        if ($barrio > 0) {
            $where .= " AND i.id_barrio = ?";
            $params[] = $barrio;
        }
        
        $sql = "SELECT DATE(i.fecha) as fecha, COUNT(*) as total
            FROM incidentes i
            WHERE $where
            GROUP BY DATE(i.fecha)
            ORDER BY fecha";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $this->json($stmt->fetchAll());
    }
    
    public function horaria(): void {
        $db = Database::connection();
        $desde = $_GET["desde"] ?? date("Y-m-01", strtotime("-1 month"));
        $hasta = $_GET["hasta"] ?? date("Y-m-d");
        $barrio = (int)($_GET["barrio"] ?? 0);
        
        $where = "i.fecha BETWEEN ? AND ?";
        $params = [$desde, $hasta];
        
        if ($barrio > 0) {
            $where .= " AND i.id_barrio = ?";
            $params[] = $barrio;
        }
        
        $sql = "SELECT HOUR(i.hora) as hora, COUNT(*) as total
            FROM incidentes i
            WHERE $where
            GROUP BY HOUR(i.hora)
            ORDER BY hora";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $resultados = $stmt->fetchAll();
        
        // Completar horas faltantes con 0
        $horas = array_fill(0, 24, 0);
        foreach ($resultados as $r) {
            $horas[(int)$r["hora"]] = (int)$r["total"];
        }
        
        $this->json($horas);
    }
    
    public function tiempos(): void {
        $db = Database::connection();
        $desde = $_GET["desde"] ?? date("Y-m-01", strtotime("-1 month"));
        $hasta = $_GET["hasta"] ?? date("Y-m-d");
        
        $sql = "SELECT 
            AVG(TIMESTAMPDIFF(MINUTE, i.fecha, i.hora, iv.hora_salida)) as tiempo_despacho,
            AVG(TIMESTAMPDIFF(MINUTE, iv.hora_salida, iv.hora_llegada)) as tiempo_traslado,
            AVG(TIMESTAMPDIFF(MINUTE, iv.hora_llegada, iv.hora_finalizacion)) as tiempo_intervencion,
            AVG(TIMESTAMPDIFF(MINUTE, i.fecha, i.hora, iv.hora_finalizacion)) as tiempo_total,
            COUNT(*) as total_intervenciones
            FROM intervenciones iv
            INNER JOIN incidentes i ON i.id = iv.id_incidente
            WHERE i.fecha BETWEEN ? AND ?
            AND iv.hora_salida IS NOT NULL
            AND iv.hora_llegada IS NOT NULL
            AND iv.hora_finalizacion IS NOT NULL";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$desde, $hasta]);
        $this->json($stmt->fetch());
    }
    
    public function comparar(): void {
        $db = Database::connection();
        
        $periodo1_desde = $_GET["p1_desde"] ?? date("Y-m-01", strtotime("-2 month"));
        $periodo1_hasta = $_GET["p1_hasta"] ?? date("Y-m-d", strtotime("-1 month"));
        $periodo2_desde = $_GET["p2_desde"] ?? date("Y-m-01", strtotime("-1 month"));
        $periodo2_hasta = $_GET["p2_hasta"] ?? date("Y-m-d");
        
        $sql = "SELECT 
            (SELECT COUNT(*) FROM incidentes WHERE fecha BETWEEN ? AND ?) as p1_total,
            (SELECT COUNT(*) FROM incidentes WHERE fecha BETWEEN ? AND ?) as p2_total,
            (SELECT COUNT(*) FROM incidentes WHERE fecha BETWEEN ? AND ? AND prioridad = 'Crítica') as p1_criticos,
            (SELECT COUNT(*) FROM incidentes WHERE fecha BETWEEN ? AND ? AND prioridad = 'Crítica') as p2_criticos";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$periodo1_desde, $periodo1_hasta, $periodo2_desde, $periodo2_hasta,
                        $periodo1_desde, $periodo1_hasta, $periodo2_desde, $periodo2_hasta]);
        
        $result = $stmt->fetch();
        $result["p1_desde"] = $periodo1_desde;
        $result["p1_hasta"] = $periodo1_hasta;
        $result["p2_desde"] = $periodo2_desde;
        $result["p2_hasta"] = $periodo2_hasta;
        
        $this->json($result);
    }
}
