<?php
declare(strict_types=1);
class Database {
    private static ?PDO $instance = null;
    public static function connection(): PDO {
        if (self::$instance === null) {
            $cfg = require CONFIG_PATH . "database.php";
            if (empty($cfg["dbname"])) throw new RuntimeException("BD no configurada.");
            $dsn = sprintf("mysql:host=%s;port=%s;dbname=%s;charset=%s",
                $cfg["host"],$cfg["port"],$cfg["dbname"],$cfg["charset"]??"utf8mb4");
            self::$instance = new PDO($dsn, $cfg["username"], $cfg["password"], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        }
        return self::$instance;
    }
}
