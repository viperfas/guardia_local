<?php
declare(strict_types=1);
class ApiController extends Controller {
    public function incidentes(): void {
        $db = Database::connection();
        $rows = $db->query("SELECT i.id, i.fecha, i.hora, i.prioridad, i.estado,
            c.nombre AS categoria, b.nombre AS barrio, i.latitud, i.longitud
            FROM incidentes i
            LEFT JOIN categorias_incidentes c ON c.id=i.id_categoria
            LEFT JOIN barrios b ON b.id=i.id_barrio
            ORDER BY i.fecha DESC LIMIT 1000")->fetchAll();
        $this->json($rows);
    }
    public function intervencionesActivas(): void {
        $db = Database::connection();
        $rows = $db->query("SELECT iv.id, iv.estado, iv.fecha_hora_despacho, iv.hora_salida, iv.hora_llegada,
            inc.prioridad, m.numero_interno AS movil, e.nombre AS equipo,
            TIMESTAMPDIFF(MINUTE, iv.fecha_hora_despacho, NOW()) AS minutos
            FROM intervenciones iv
            LEFT JOIN incidentes inc ON inc.id = iv.id_incidente
            LEFT JOIN moviles m ON m.id = iv.id_movil
            LEFT JOIN equipos e ON e.id = iv.id_equipo
            WHERE iv.estado IN ('Asignado','En intervención')
            ORDER BY iv.fecha_hora_despacho")->fetchAll();
        $this->json($rows);
    }
    public function movilesEstado(): void {
        $db = Database::connection();
        $rows = $db->query("SELECT id, numero_interno, estado FROM moviles ORDER BY numero_interno")->fetchAll();
        $this->json($rows);
    }
}
