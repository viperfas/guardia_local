<?php
declare(strict_types=1);

class AiService
{
    public static function isAvailable(): bool
    {
        try {
            $db = Database::connection();
            $configs = $db->query("SELECT clave, valor FROM configuracion WHERE clave IN ('ia_habilitada', 'ia_proveedor', 'ia_modelo', 'ia_api_key_path')")->fetchAll();
            $map = [];
            foreach ($configs as $c) {
                $map[$c['clave']] = $c['valor'];
            }
            
            if (($map['ia_habilitada'] ?? '0') !== '1') return false;
            if (empty($map['ia_proveedor']) || empty($map['ia_modelo'])) return false;
            
            $proveedor = strtolower(trim($map['ia_proveedor']));
            
            if ($proveedor === 'ollama' || $proveedor === 'local') {
                return !empty($map['ia_api_key_path']);
            }
            
            $path = $map['ia_api_key_path'] ?? '';
            return !empty($path) && file_exists($path) && !empty(trim(file_get_contents($path)));
        } catch (Throwable $e) {
            return false;
        }
    }
    
    public static function getConfig(): array
    {
        $db = Database::connection();
        $configs = $db->query("SELECT clave, valor FROM configuracion WHERE clave LIKE 'ia_%'")->fetchAll();
        $map = [];
        foreach ($configs as $c) {
            $map[$c['clave']] = $c['valor'];
        }
        return $map;
    }
    
    private static function getEndpoint(string $proveedor): string
    {
        return match (strtolower($proveedor)) {
            'openai' => 'https://api.openai.com/v1/chat/completions',
            'anthropic' => 'https://api.anthropic.com/v1/messages',
            'groq' => 'https://api.groq.com/openai/v1/chat/completions',
            'qwen', 'dashscope' => 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions',
            'ollama', 'local' => 'http://localhost:11434/v1/chat/completions',
            default => ''
        };
    }
    
    private static function getApiKey(string $proveedor, string $path): string
    {
        $proveedor = strtolower($proveedor);
        if ($proveedor === 'ollama' || $proveedor === 'local') {
            return 'ollama-no-key-needed';
        }
        if (empty($path) || !file_exists($path)) {
            return '';
        }
        return trim(file_get_contents($path));
    }
    
    private static function httpPost(string $url, array $data, string $apiKey): array
    {
        $headers = ['Content-Type: application/json'];
        $proveedor = self::getConfig()['ia_proveedor'] ?? '';
        if (strtolower($proveedor) !== 'ollama' && strtolower($proveedor) !== 'local') {
            $headers[] = 'Authorization: Bearer ' . $apiKey;
        }
        
        $options = [
            'http' => [
                'method' => 'POST',
                'header' => implode("\r\n", $headers),
                'content' => json_encode($data),
                'timeout' => 60,
                'ignore_errors' => true
            ],
            'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]
        ];
        
        $context = stream_context_create($options);
        $response = @file_get_contents($url, false, $context);
        
        $httpCode = 500;
        if (isset($http_response_header) && is_array($http_response_header)) {
            foreach ($http_response_header as $header) {
                if (preg_match('/HTTP\/\d\.\d\s+(\d{3})/', $header, $matches)) {
                    $httpCode = (int)$matches[1];
                    break;
                }
            }
        }
        
        if ($response === false) {
            return ['ok' => false, 'error' => 'No se pudo conectar al servicio de IA', 'http_code' => $httpCode];
        }
        
        $decoded = json_decode($response, true);
        if ($httpCode >= 400) {
            $errorMsg = $decoded['error']['message'] ?? $decoded['message'] ?? 'Error HTTP ' . $httpCode;
            return ['ok' => false, 'error' => $errorMsg, 'http_code' => $httpCode];
        }
        
        return ['ok' => true, 'data' => $decoded, 'http_code' => $httpCode];
    }
    
    public static function ask(string $prompt, string $systemPrompt = ''): string
    {
        if (!self::isAvailable()) return '';
        
        $config = self::getConfig();
        $endpoint = self::getEndpoint($config['ia_proveedor']);
        $apiKey = self::getApiKey($config['ia_proveedor'], $config['ia_api_key_path']);
        $modelo = $config['ia_modelo'];
        
        if (empty($endpoint)) return '';
        
        $messages = [];
        if (!empty($systemPrompt)) {
            $messages[] = ['role' => 'system', 'content' => $systemPrompt];
        }
        $messages[] = ['role' => 'user', 'content' => $prompt];
        
        $payload = ['model' => $modelo, 'messages' => $messages, 'temperature' => 0.7, 'max_tokens' => 2000];
        $result = self::httpPost($endpoint, $payload, $apiKey);
        
        if (!$result['ok']) return '';
        
        $data = $result['data'];
        if (isset($data['choices'][0]['message']['content'])) return trim($data['choices'][0]['message']['content']);
        if (isset($data['content'][0]['text'])) return trim($data['content'][0]['text']);
        
        return '';
    }
    
    public static function chat(array $messages, string $systemPrompt = ''): string
    {
        if (!self::isAvailable()) return '';
        
        $config = self::getConfig();
        $endpoint = self::getEndpoint($config['ia_proveedor']);
        $apiKey = self::getApiKey($config['ia_proveedor'], $config['ia_api_key_path']);
        $modelo = $config['ia_modelo'];
        
        if (empty($endpoint)) return '';
        
        $allMessages = [];
        if (!empty($systemPrompt)) {
            $allMessages[] = ['role' => 'system', 'content' => $systemPrompt];
        }
        foreach ($messages as $msg) {
            $allMessages[] = $msg;
        }
        
        $payload = ['model' => $modelo, 'messages' => $allMessages, 'temperature' => 0.7, 'max_tokens' => 2000];
        $result = self::httpPost($endpoint, $payload, $apiKey);
        
        if (!$result['ok']) return '';
        
        $data = $result['data'];
        if (isset($data['choices'][0]['message']['content'])) return trim($data['choices'][0]['message']['content']);
        if (isset($data['content'][0]['text'])) return trim($data['content'][0]['text']);
        
        return '';
    }
    
    public static function anonimizar(string $texto): string
    {
        $texto = preg_replace('/\b\d{7,8}\b/', '[DNI]', $texto);
        $texto = preg_replace('/\b(?:\+?54\s?)?(?:\(\d{2,4}\)\s?)?\d{6,8}\b/', '[TELÉFONO]', $texto);
        $texto = preg_replace('/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/', '[EMAIL]', $texto);
        $texto = preg_replace('/\b(?:Sr\.|Sra\.|Srta\.|Don|Doña)\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+/', '[PERSONA]', $texto);
        return $texto;
    }
    
    public static function getInfo(): string
    {
        $config = self::getConfig();
        $proveedor = $config['ia_proveedor'] ?? 'no configurado';
        $modelo = $config['ia_modelo'] ?? 'no configurado';
        return "Proveedor: $proveedor | Modelo: $modelo";
    }

    // ============================================================
    // MÉTODOS ESPECÍFICOS PARA InformesIaController
    // ============================================================

    public static function consultarDatos(string $prompt, array $datos = []): string
    {
        $textoDatos = !empty($datos) ? "\n\nDATOS DE CONTEXTO:\n" . json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) : '';
        $promptFinal = $prompt . $textoDatos;
        $systemPrompt = "Eres un asistente experto en seguridad pública. Responde en español, de forma clara, profesional y estructurada (usa Markdown).";
        return self::ask($promptFinal, $systemPrompt);
    }

    public static function consultar(string $prompt): string
    {
        return self::consultarDatos($prompt, []);
    }

    public static function analisisLocal(array $datos): string
    {
        $total = $datos['total'] ?? 0;
        $criticos = $datos['criticos'] ?? 0;
        $barrioTop = $datos['barrio_top'] ?? 'No determinado';
        
        $texto = "📊 **ANÁLISIS ESTADÍSTICO LOCAL** (Sin IA)\n\n";
        $texto .= "• **Total de incidentes registrados:** $total\n";
        $texto .= "• **Incidentes de prioridad crítica:** $criticos\n";
        $texto .= "• **Zona con mayor actividad:** $barrioTop\n\n";
        $texto .= "_Nota: Para obtener un análisis predictivo y recomendaciones detalladas, habilita la conexión con el motor de IA en la configuración del sistema._";
        return $texto;
    }

    public static function analizar(array $datos, string $tipo = 'general'): string
    {
        $prompt = "Realiza un análisis detallado de los siguientes datos de seguridad pública. ";
        $mapaTipos = [
            'general' => "Incluye resumen ejecutivo, hallazgos clave y recomendaciones generales.",
            'barrios' => "Enfócate en la distribución geográfica, barrios más críticos y patrones espaciales.",
            'temporal' => "Enfócate en la evolución temporal, picos de actividad y patrones horarios.",
            'categorias' => "Enfócate en la tipología de incidentes, categorías más frecuentes y su relación.",
        ];
        $prompt .= ($mapaTipos[$tipo] ?? $mapaTipos['general']) . "\n\nDATOS:\n" . json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        return self::consultarDatos($prompt, []);
    }

    public static function generarInforme(array $datosAnonimizados, string $tipo = 'ejecutivo'): string
    {
        return self::analizar($datosAnonimizados, $tipo);
    }

    public static function conversar(array $mensajes): string
    {
        $systemPrompt = "Eres un asistente virtual de la Guardia Local. Respondes preguntas sobre incidentes, estadísticas y operaciones. Responde en español, de forma profesional y clara. NUNCA reveles datos personales de ciudadanos.";
        return self::chat($mensajes, $systemPrompt);
    }
}