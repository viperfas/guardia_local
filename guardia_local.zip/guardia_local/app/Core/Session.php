<?php
declare(strict_types=1);
class Session {
    public static function start(): void {
        if (session_status() === PHP_SESSION_ACTIVE) return;
        ini_set("session.cookie_httponly","1");
        ini_set("session.cookie_samesite","Strict");
        ini_set("session.use_strict_mode","1");
        ini_set("session.gc_maxlifetime",(string)SESSION_LIFETIME);
        session_start();
        if (isset($_SESSION["last_activity"]) && (time()-$_SESSION["last_activity"])>SESSION_LIFETIME) {
            self::destroy();
            header("Location: ".APP_URL."login?expired=1"); exit;
        }
        $_SESSION["last_activity"] = time();
    }
    public static function destroy(): void {
        $_SESSION = [];
        if (ini_get("session.use_cookies")) {
            $p = session_get_cookie_params();
            setcookie(session_name(),"",time()-42000,$p["path"],$p["domain"],$p["secure"],$p["httponly"]);
        }
        session_destroy();
    }
    public static function regenerate(): void { session_regenerate_id(true); }
}
