<?php
declare(strict_types=1);
class PerfilController extends Controller {
    public function index(): void {
        $db = Database::connection();
        $stmt = $db->prepare("SELECT u.*, r.nombre AS rol FROM usuarios u
            LEFT JOIN roles r ON r.id = u.id_rol WHERE u.id=?");
        $stmt->execute([$_SESSION["user_id"]]);
        $usuario = $stmt->fetch();
        $permisos = Permission::allForUser((int)$_SESSION["user_id"]);
        $this->view("perfil/index", ["usuario"=>$usuario,"permisos"=>$permisos]);
    }
    public function changePass(): void {
        $this->requirePost();
        $db = Database::connection();
        $stmt = $db->prepare("SELECT password FROM usuarios WHERE id=?");
        $stmt->execute([$_SESSION["user_id"]]);
        $actual = $stmt->fetchColumn();
        $errors = [];
        if (!password_verify($_POST["actual"]??"", $actual)) $errors[] = "La contraseña actual es incorrecta";
        if (strlen($_POST["nueva"]??"") < 8) $errors[] = "La nueva contraseña debe tener al menos 8 caracteres";
        if (($_POST["nueva"]??"") !== ($_POST["confirmar"]??"")) $errors[] = "Las contraseñas nuevas no coinciden";
        if ($errors) {
            $_SESSION["perfil_error"] = implode("<br>", $errors);
            $this->redirect("perfil");
            return;
        }
        $hash = password_hash($_POST["nueva"], PASSWORD_BCRYPT);
        $db->prepare("UPDATE usuarios SET password=? WHERE id=?")->execute([$hash, $_SESSION["user_id"]]);
        Audit::log("cambio_password","perfil",(string)$_SESSION["user_id"]);
        $_SESSION["perfil_ok"] = "Contraseña actualizada correctamente";
        $this->redirect("perfil");
    }
}
