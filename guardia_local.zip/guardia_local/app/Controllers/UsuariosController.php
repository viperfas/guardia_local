<?php
declare(strict_types=1);
class UsuariosController extends Controller {
    public function index(): void {
        $db = Database::connection();
        $usuarios = $db->query("SELECT u.*, r.nombre AS rol FROM usuarios u
            LEFT JOIN roles r ON r.id = u.id_rol ORDER BY u.activo DESC, u.nombre_completo")->fetchAll();
        $this->view("usuarios/index", ["usuarios"=>$usuarios]);
    }
    public function create(): void {
        $db = Database::connection();
        $roles = $db->query("SELECT id, nombre FROM roles ORDER BY nombre")->fetchAll();
        $this->view("usuarios/form", ["roles"=>$roles,"usuario"=>null,"permisos"=>[]]);
    }
    public function store(): void {
        $this->requirePost();
        $d = $_POST;
        $errors = [];
        $db = Database::connection();
        if (strlen($d["password"]??"") < 8) $errors[] = "La contraseña debe tener al menos 8 caracteres";
        $exists = $db->prepare("SELECT id FROM usuarios WHERE usuario=?");
        $exists->execute([$d["usuario"]??""]);
        if ($exists->fetch()) $errors[] = "El nombre de usuario ya existe";
        if ($errors) {
            $roles = $db->query("SELECT id, nombre FROM roles ORDER BY nombre")->fetchAll();
            $this->view("usuarios/form", ["roles"=>$roles,"usuario"=>$d,"permisos"=>[],"errors"=>$errors]);
            return;
        }
        $hash = password_hash($d["password"], PASSWORD_BCRYPT);
        $stmt = $db->prepare("INSERT INTO usuarios (usuario, password, nombre_completo, id_rol, activo) VALUES (?,?,?,?,1)");
        $stmt->execute([$d["usuario"], $hash, $d["nombre_completo"], (int)$d["id_rol"]]);
        $newId = (int)$db->lastInsertId();
        
        // Si el usuario envió permisos específicos, usarlos; si no, heredar del rol
        if (!empty($d["permisos"])) {
            foreach ($d["permisos"] as $p) {
                $db->prepare("INSERT IGNORE INTO usuarios_permisos (id_usuario, id_permiso) VALUES (?,?)")->execute([$newId, (int)$p]);
            }
        } else {
            // Heredar permisos del rol
            self::heredarPermisosDeRol($db, $newId, (int)$d["id_rol"]);
        }
        
        Audit::log("alta_usuario","usuarios",(string)$newId);
        $this->redirect("usuarios");
    }
    public function edit(): void {
        $id = (int)($_GET["id"]??0);
        $db = Database::connection();
        $stmt = $db->prepare("SELECT * FROM usuarios WHERE id=?");
        $stmt->execute([$id]);
        $usuario = $stmt->fetch();
        if (!$usuario) { $this->redirect("usuarios"); return; }
        $roles = $db->query("SELECT id, nombre FROM roles ORDER BY nombre")->fetchAll();
        $permisos = Permission::allForUser($id);
        $this->view("usuarios/form", ["roles"=>$roles,"usuario"=>$usuario,"permisos"=>$permisos]);
    }
    public function update(): void {
        $this->requirePost();
        $d = $_POST;
        $id = (int)$d["id"];
        $db = Database::connection();
        
        // Obtener rol anterior para detectar si cambió
        $rolAnterior = $db->prepare("SELECT id_rol FROM usuarios WHERE id=?");
        $rolAnterior->execute([$id]);
        $rolAnterior = (int)$rolAnterior->fetchColumn();
        
        $stmt = $db->prepare("UPDATE usuarios SET nombre_completo=?, id_rol=?, activo=? WHERE id=?");
        $stmt->execute([$d["nombre_completo"], (int)$d["id_rol"], isset($d["activo"])?1:0, $id]);
        
        if (!empty($d["password"]) && strlen($d["password"]) >= 8) {
            $hash = password_hash($d["password"], PASSWORD_BCRYPT);
            $db->prepare("UPDATE usuarios SET password=? WHERE id=?")->execute([$hash, $id]);
        }
        
        // Si el usuario envió permisos específicos, usarlos
        $db->prepare("DELETE FROM usuarios_permisos WHERE id_usuario=?")->execute([$id]);
        if (!empty($d["permisos"])) {
            foreach ($d["permisos"] as $p) {
                $db->prepare("INSERT IGNORE INTO usuarios_permisos (id_usuario, id_permiso) VALUES (?,?)")->execute([$id, (int)$p]);
            }
        } else {
            // Si cambió de rol o no hay permisos específicos, heredar del rol actual
            self::heredarPermisosDeRol($db, $id, (int)$d["id_rol"]);
        }
        
        Permission::clearCache($id);
        Audit::log("edit_usuario","usuarios",(string)$id);
        $this->redirect("usuarios");
    }
    public function delete(): void {
        $this->requirePost();
        $id = (int)($_POST["id"]??0);
        if ($id == ($_SESSION["user_id"]??0)) {
            $this->redirect("usuarios"); return;
        }
        $db = Database::connection();
        $db->prepare("UPDATE usuarios SET activo=0 WHERE id=?")->execute([$id]);
        Audit::log("baja_usuario","usuarios",(string)$id);
        $this->redirect("usuarios");
    }
    
    /**
     * MATRIZ DE PERMISOS POR ROL
     * Asigna permisos a TODOS los usuarios de cada rol.
     * CORRECCIÓN: itera sobre TODOS los roles, no solo los del POST.
     */
    public function permisos(): void {
        $db = Database::connection();
        $permisos = $db->query("SELECT * FROM permisos ORDER BY codigo")->fetchAll();
        $roles = $db->query("SELECT id, nombre FROM roles ORDER BY nombre")->fetchAll();
        
        // Calcular qué permisos tiene cada rol (unión de permisos de sus usuarios)
        $matriz = [];
        foreach ($roles as $r) {
            $stmt = $db->prepare("SELECT DISTINCT up.id_permiso FROM usuarios_permisos up
                INNER JOIN usuarios u ON u.id = up.id_usuario 
                WHERE u.id_rol=? AND u.activo=1");
            $stmt->execute([$r["id"]]);
            $matriz[$r["id"]] = array_column($stmt->fetchAll(), "id");
        }
        
        $this->view("usuarios/permisos", ["permisos"=>$permisos,"roles"=>$roles,"matriz"=>$matriz]);
    }
    
    public function savePerms(): void {
        $this->requirePost();
        $db = Database::connection();
        
        // Obtener TODOS los roles (no solo los del POST)
        $todosLosRoles = $db->query("SELECT id FROM roles")->fetchAll(PDO::FETCH_COLUMN);
        $postPermisos = $_POST["permisos"] ?? [];
        
        foreach ($todosLosRoles as $rolId) {
            // Si el rol no está en el POST, significa que no tiene permisos marcados
            $permisosDelRol = $postPermisos[$rolId] ?? [];
            
            // Buscar todos los usuarios activos de este rol
            $stmt = $db->prepare("SELECT id FROM usuarios WHERE id_rol=? AND activo=1");
            $stmt->execute([$rolId]);
            $usuarios = $stmt->fetchAll();
            
            foreach ($usuarios as $u) {
                // Eliminar permisos anteriores del usuario
                $db->prepare("DELETE FROM usuarios_permisos WHERE id_usuario=?")->execute([$u["id"]]);
                
                // Insertar los nuevos permisos (puede estar vacío)
                foreach ($permisosDelRol as $p) {
                    $db->prepare("INSERT IGNORE INTO usuarios_permisos (id_usuario, id_permiso) VALUES (?,?)")
                        ->execute([$u["id"], (int)$p]);
                }
                
                Permission::clearCache((int)$u["id"]);
            }
        }
        
        Audit::log("edit_permisos_rol","usuarios","Matriz actualizada");
        $_SESSION["permisos_ok"] = "Permisos actualizados correctamente para todos los roles";
        $this->redirect("usuarios/permisos");
    }
    
    /**
     * Sincroniza los permisos de TODOS los usuarios según la matriz de roles
     */
    public function sincronizar(): void {
        $db = Database::connection();
        $roles = $db->query("SELECT id FROM roles")->fetchAll(PDO::FETCH_COLUMN);
        $actualizados = 0;
        
        foreach ($roles as $rolId) {
            // Obtener permisos del rol (unión de permisos de usuarios activos con ese rol)
            $stmt = $db->prepare("SELECT DISTINCT up.id_permiso FROM usuarios_permisos up
                INNER JOIN usuarios u ON u.id = up.id_usuario 
                WHERE u.id_rol=? AND u.activo=1");
            $stmt->execute([$rolId]);
            $permisos = array_column($stmt->fetchAll(), "id_permiso");
            
            // Aplicar a todos los usuarios del rol
            $usuarios = $db->prepare("SELECT id FROM usuarios WHERE id_rol=? AND activo=1");
            $usuarios->execute([$rolId]);
            foreach ($usuarios->fetchAll() as $u) {
                $db->prepare("DELETE FROM usuarios_permisos WHERE id_usuario=?")->execute([$u["id"]]);
                foreach ($permisos as $p) {
                    $db->prepare("INSERT IGNORE INTO usuarios_permisos (id_usuario, id_permiso) VALUES (?,?)")
                        ->execute([$u["id"], $p]);
                }
                Permission::clearCache((int)$u["id"]);
                $actualizados++;
            }
        }
        
        Audit::log("sincronizar_permisos","usuarios","$actualizados usuarios sincronizados");
        $_SESSION["permisos_ok"] = "Permisos sincronizados: $actualizados usuarios actualizados";
        $this->redirect("usuarios/permisos");
    }
    
    /**
     * Hereda los permisos del rol al usuario
     */
    private static function heredarPermisosDeRol(PDO $db, int $userId, int $rolId): void {
        // Buscar un usuario activo con ese rol que tenga permisos (como plantilla)
        $stmt = $db->prepare("SELECT DISTINCT up.id_permiso FROM usuarios_permisos up
            INNER JOIN usuarios u ON u.id = up.id_usuario 
            WHERE u.id_rol=? AND u.activo=1 AND u.id != ? LIMIT 100");
        $stmt->execute([$rolId, $userId]);
        $permisos = array_column($stmt->fetchAll(), "id_permiso");
        
        foreach ($permisos as $p) {
            $db->prepare("INSERT IGNORE INTO usuarios_permisos (id_usuario, id_permiso) VALUES (?,?)")
                ->execute([$userId, $p]);
        }
    }
}