<h3 class="mb-3">🗺️ Mapa territorial — Villa Giardino</h3>

<div class="alert alert-info">
  <strong>ℹ️ Nota:</strong> Solo se muestran barrios con límites GeoJSON oficiales cargados por el administrador.
  Los incidentes se visualizan por barrio, nunca por domicilio particular (requisito de privacidad).
</div>

<div id="debugMap" class="alert alert-warning" style="display:none"></div>

<div class="card bg-white p-3 mb-3">
  <h5>🔍 Filtros</h5>
  <form id="formFiltros" class="row g-2">
    <div class="col-md-3">
      <label>Desde</label>
      <input type="date" id="fDesde" class="form-control" value="<?= date("Y-m-01", strtotime("-1 month")) ?>">
    </div>
    <div class="col-md-3">
      <label>Hasta</label>
      <input type="date" id="fHasta" class="form-control" value="<?= date("Y-m-d") ?>">
    </div>
    <div class="col-md-3">
      <label>Categoría</label>
      <select id="fCategoria" class="form-select">
        <option value="0">Todas</option>
        <?php foreach ($categorias as $c): ?>
          <option value="<?= $c["id"] ?>"><?= View::e($c["nombre"]) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label>Prioridad</label>
      <select id="fPrioridad" class="form-select">
        <option value="">Todas</option>
        <option value="Crítica">Crítica</option>
        <option value="Alta">Alta</option>
        <option value="Media">Media</option>
        <option value="Baja">Baja</option>
      </select>
    </div>
  </form>
</div>

<div class="row g-3">
  <div class="col-md-9">
    <div class="card bg-white p-2">
      <div id="map" style="height:650px;width:100%;border:1px solid #ccc;background:#e8f0f8"></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="card bg-white p-3 mb-3">
      <h6>📊 Resumen</h6>
      <div id="resumen">Cargando...</div>
    </div>
    <div class="card bg-white p-3 mb-3">
      <h6>🏘️ Barrios</h6>
      <div id="listaBarrios" style="max-height:400px;overflow-y:auto"></div>
    </div>
    <div class="card bg-white p-3">
      <h6>🎨 Leyenda</h6>
      <small>
        <div><span style="display:inline-block;width:15px;height:15px;background:#dc3545"></span> Crítico</div>
        <div><span style="display:inline-block;width:15px;height:15px;background:#fd7e14"></span> Alto</div>
        <div><span style="display:inline-block;width:15px;height:15px;background:#ffc107"></span> Medio</div>
        <div><span style="display:inline-block;width:15px;height:15px;background:#198754"></span> Bajo</div>
        <hr>
        <div><em>Intensidad del color = cantidad de incidentes</em></div>
      </small>
    </div>
  </div>
</div>

<script>
// Diagnóstico
const debug = document.getElementById('debugMap');
function mostrarError(msg) {
  debug.style.display = 'block';
  debug.innerHTML = '⚠️ <strong>Error en el mapa:</strong> ' + msg;
}

// Verificar que Leaflet esté cargado
if (typeof L === 'undefined') {
  mostrarError('Leaflet no está cargado. Verificá la conexión a internet o que los archivos estén en /public/assets/vendor/leaflet/');
} else {
  try {
    const map = L.map('map').setView([-31.1470, -64.4010], 14);
    
    // Intentar cargar tiles de OSM
    const tiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
      maxZoom: 19
    }).addTo(map);
    
    tiles.on('tileerror', function(e) {
      console.warn('Error cargando tile OSM:', e.tile.src);
    });
    
    let capaBarrios = L.layerGroup().addTo(map);
    let capaIncidentes = L.layerGroup().addTo(map);
    
    function cargarDatos() {
      const desde = document.getElementById('fDesde').value;
      const hasta = document.getElementById('fHasta').value;
      const categoria = document.getElementById('fCategoria').value;
      const prioridad = document.getElementById('fPrioridad').value;
      
      const params = new URLSearchParams({desde, hasta, categoria, prioridad});
      
      fetch('<?= APP_URL ?>mapa/barrios?' + params)
        .then(r => r.json())
        .then(barrios => {
          capaBarrios.clearLayers();
          const lista = [];
          let total = 0;
          let maxTotal = 0;
          
          barrios.forEach(b => {
            if (!b.geojson) return;
            total += parseInt(b.total);
            if (parseInt(b.total) > maxTotal) maxTotal = parseInt(b.total);
            
            try {
              const geo = JSON.parse(b.geojson);
              const intensidad = maxTotal > 0 ? parseInt(b.total) / maxTotal : 0;
              const color = intensidad > 0.7 ? '#dc3545' : intensidad > 0.4 ? '#fd7e14' : intensidad > 0 ? '#ffc107' : '#6c757d';
              
              const layer = L.geoJSON(geo, {
                style: { color: color, weight: 2, fillOpacity: 0.15 + (intensidad * 0.4) }
              });
              
              layer.bindPopup(`
                <strong>${b.nombre}</strong><br>
                Total: <b>${b.total}</b><br>
                Críticos: <b style="color:#dc3545">${b.criticos}</b><br>
                Resueltos: <b style="color:#198754">${b.resueltos}</b><br>
                <a href="<?= APP_URL ?>barrios/ver?id=${b.id}" target="_blank">Ver detalle</a>
              `);
              
              layer.addTo(capaBarrios);
              lista.push({ nombre: b.nombre, total: parseInt(b.total), id: b.id });
            } catch(e) {
              console.warn('GeoJSON inválido en barrio', b.nombre, e);
            }
          });
          
          lista.sort((a,b) => b.total - a.total);
          
          let html = '<table class="table table-sm"><tbody>';
          lista.forEach(b => {
            html += `<tr>
              <td><a href="<?= APP_URL ?>barrios/ver?id=${b.id}" target="_blank">${b.nombre}</a></td>
              <td class="text-end"><strong>${b.total}</strong></td>
            </tr>`;
          });
          html += '</tbody></table>';
          
          document.getElementById('listaBarrios').innerHTML = lista.length ? html : '<p class="text-muted">Sin barrios con polígono cargado.<br><small>Andá a <a href="<?= APP_URL ?>barrios">🏘️ Barrios</a> para cargar GeoJSON.</small></p>';
          document.getElementById('resumen').innerHTML = `
            <div><strong>Total incidentes:</strong> ${total}</div>
            <div><strong>Barrios con datos:</strong> ${lista.length}</div>
            <div><strong>Período:</strong> ${desde} a ${hasta}</div>
          `;
        })
        .catch(err => {
          console.error('Error cargando barrios:', err);
          mostrarError('No se pudieron cargar los datos de barrios. Verificá la consola (F12).');
        });
      
      fetch('<?= APP_URL ?>mapa/incidentes?' + params)
        .then(r => r.json())
        .then(incidentes => {
          capaIncidentes.clearLayers();
          incidentes.forEach(i => {
            if (!i.latitud || !i.longitud) return;
            const color = i.categoria_color || '#6c757d';
            const marker = L.circleMarker([parseFloat(i.latitud), parseFloat(i.longitud)], {
              radius: 6, color: color, fillColor: color, fillOpacity: 0.7, weight: 2
            });
            marker.bindPopup(`
              <strong>#${i.id}</strong> - ${i.categoria || 'Sin categoría'}<br>
              Barrio: ${i.barrio || 'Sin asignar'}<br>
              Prioridad: <b>${i.prioridad}</b><br>
              Estado: ${i.estado}<br>
              ${i.fecha} ${i.hora}<br>
              <a href="<?= APP_URL ?>incidentes/editar?id=${i.id}" target="_blank">Ver incidente</a>
            `);
            marker.addTo(capaIncidentes);
          });
        })
        .catch(err => console.error('Error cargando incidentes:', err));
    }
    
    ['fDesde','fHasta','fCategoria','fPrioridad'].forEach(id => {
      document.getElementById(id).addEventListener('change', cargarDatos);
    });
    
    cargarDatos();
    
    // Forzar redibujado del mapa
    setTimeout(() => map.invalidateSize(), 100);
    
  } catch(e) {
    mostrarError('Error al inicializar el mapa: ' + e.message);
    console.error(e);
  }
}
</script>