<?php
return [
    'host' => 'localhost',
    'port' => '3306',
    'dbname' => 'guardia_local',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
];
